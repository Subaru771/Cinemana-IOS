# Cinemana iOS v1.6.11

## v1.6.11 — Full-screen logo and app-name polish

- Crisp, borderless red film-strip emblem and the original **Cinemana iOS** wordmark on a true black splash.
- No extra rounded tile around the in-app logo; app icon keeps the shape iOS requires.
- Home Screen and Settings display name now **Cinemana iOS**; compact header includes `iOS`.
- No playback or downloads changes compared with the v1.6.10 recovery release.

See [v1.6.11 release notes](docs/RELEASE-v1.6.11.md).

# Cinemana iOS v1.6.10

## v1.6.10 — Stability recovery

- Restores **concurrent** details, episode-list and recommendations fetching rather than waiting on series metadata in sequence.
- The Play button always uses the tapped title's original catalog identity and type, avoiding incorrect or partial metadata disabling playback.
- Tapping posters still opens the details screen; only Play/Resume and an explicit episode tap open the player.
- AVPlayer begins playback when ready, even if a previous resume seek fails or is cancelled.
- Adds regression checks for the details page and resume-seek behavior.
- This is a source fix with CI verification; physical iPhone / LiveContainer behavior still requires testing.

## v1.6.9 — Details first, autoplay only after Play

- Tapping a movie or series poster **opens its details page**. It never auto-opens the player.
- Tapping **Play/Resume** on that page, or selecting a specific episode row, opens the fullscreen player and the video **autostarts** when AVPlayer reports it ready.
- Series episodes populate the details screen without autoplay.
- Synopsis, related titles and metadata can load while viewing details.
- Continue Watching remains removed from Home; existing v1.6.8 performance and logo assets remain unchanged.



Native SwiftUI (iPhone/iPad) browsing and AVPlayer. Created from the v1.1 project with improved series playback, smarter quality fallback, faster concurrent details, search polish, local watchlist and Settings.

## v1.6.8 — previous direct-autoplay behavior (superseded in v1.6.9)

- Home no longer displays a **Continue Watching** carousel. Playback history remains under **My List**, so progress is not deleted.
- Selecting a **movie or individual episode** opens the custom fullscreen video player automatically, without waiting for details, recommendations, or episodes.
- Selecting a **series** fetches its episodes and automatically plays the next unfinished episode (or the first episode). If no episodes are available, the detail screen remains accessible.
- Details and related titles are retrieved only after closing playback, reducing competing API traffic while starting a video.
- Video stream discovery returns the **first compatible provider result immediately**, instead of waiting an extra 450 ms for another endpoint. Downloads still aggregate available quality sources.
- Startup splash lasts about **0.56 s plus a brief fade** and does not wait up to 2.8 s for the network. Cached catalog rows do not immediately launch four network refresh requests; pull-to-refresh remains available.
- The original 1254 px Cinemana PNG is bundled as a high-resolution asset, and startup refuses to enlarge an older 256 px fallback. The GitHub-built app uses a crisp vector placeholder until full-resolution binary artwork is committed there.
- Full source ZIP includes the original 1024 px RGB AppIcon and 1254 px master image. Install a **new IPA**: the existing app does not update itself when GitHub source changes.

See [v1.6.8 release notes](docs/RELEASE-v1.6.8.md) for checks and limitations.

## v1.6.7 icon and download-menu cleanup

- iOS app icon (1024 × 1024) is now built from the **original 1254 × 1254 red artwork**, not the low-resolution 256 × 256 embedded fallback.
- Full-resolution artwork is included in the source and pre-generated Xcode asset catalogs.
- Download menus show **only 480p, 720p, 1080p and 2160p**. No Default, Best Available, or Wi-Fi-only options.
- Rebuild and reinstall v1.6.7; an older installed IPA cannot change from updated source alone.

## v1.6.6 cinematic startup

- Fullscreen, native SwiftUI startup using the **original red filmstrip image**; animated reveal, soft red lighting, branded wordmark and a lightweight indeterminate activity indicator.
- The native iOS launch screen matches the dark background, avoiding a white flash before the SwiftUI screen appears.
- Home catalog load begins **underneath** the animation; the overlay stays for at least 1.05 seconds and leaves as soon as catalog cache/network returns, or after a 2.8-second maximum.
- The optional Cinema Hub invitation appears **after** the opening animation has disappeared.
- Reduce Motion is respected; the animation is skipped for users who request reduced motion.
- Full source and original high-resolution artwork are bundled in this ZIP.

See [v1.6.6 release notes](docs/RELEASE-v1.6.6.md).

## v1.6.5 reliability and branding fixes

- Download quality ceilings are enforced: missing lower renditions cause an explicit error instead of silently downloading higher resolution.
- HLS master playlists are inspected to select a concrete rendition at or below the chosen limit; the upstream provider must support the selected rendition.
- The download menu offers 480/720/1080/2160p.
- Stream discovery merges results from both endpoints with a short grace period rather than using only whichever endpoint replies first.
- Cinema Hub is shown on first launch only, with an explicit way to show it again in Settings.
- Full-resolution original Cinemana iOS artwork is bundled (1024px build source and 1254px PNG master), without a low-quality 256px fallback.
- Portable core tests cover requested limits, unknown quality and HLS master rendition selection.

## v1.6 player, diagnostics and branding

- Fullscreen custom player: bounded stall recovery, a precise scrub-time preview and copyable AVFoundation diagnostics.
- Download storage summary, low-space warning, and an option to delete completed videos without interrupting ongoing downloads.
- Network diagnostics from Settings, with ISP/server access errors reported honestly.
- Cinemana app icon generated by `swift scripts/make_app_icon.swift` before XcodeGen (automated in GitHub Actions).
- English and Arabic interface localization groundwork (some dynamic strings remain untranslated).
- The macOS GitHub workflow runs portable tests, builds the app, and uploads an unsigned IPA.

See [v1.6.5 release notes](docs/RELEASE-v1.6.5.md) and [previous release notes](docs/RELEASE-v1.6.md) for the manual iPhone test checklist and known limitations.

## Make Cinemana accessible to testers and users

A regular iPhone cannot install our unsigned GitHub Actions IPA by tapping a ZIP link.
The official no-sideload route is **TestFlight** (beta), followed by **App Store** (production).

- [Distribution instructions](DISTRIBUTION.md): Apple membership, content permissions, code signing, GitHub secrets and TestFlight approval.
- [Manual TestFlight upload workflow](.github/workflows/testflight.yml): only runs when explicitly requested and distribution rights are confirmed.
- [Public website template](landing/index.html): responsive release landing page with a **coming soon** placeholder, not a fake installation link.
- [Draft privacy policy](landing/privacy.html): must be checked, completed with support contact and publicly hosted before submission.

**Current state:** public release is not enabled. We still need the Apple Developer Program membership, valid signing materials, authorized provider/media rights and real-device QA. The unsigned build remains available for development checks.

## Build on GitHub's website (Windows-friendly)

In your existing **Cinemana-IOS** repository, use **Add file → Upload files** and upload the *extracted* project files and folders. Preserve the folder structure: `CinemanaMobile/`, `Tests/`, `project.yml`. Replace existing files when prompted. The included `.github/workflows/ios.yml` can be used for a standalone build workflow, but if your existing green workflow (`main.yml` or `ios.yml`) works, you may keep it: XcodeGen will pick up the new `PlaybackPlanner.swift` automatically.

Go to **Actions → Cinemana iOS Build → Run workflow**, or open the automatically triggered build. Download the **Cinemana iOS** unsigned artifact after it succeeds. Do not mistake a successful ZIP integrity check for a successful Xcode build.

The signed installation/distribution step is deliberately out of scope for this release.

## Build command (Mac or GitHub Actions)

```sh
brew install xcodegen
xcodegen generate
xcodebuild -project CinemanaMobile.xcodeproj -scheme CinemanaMobile -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```

## Offline portable Swift tests

```sh
swiftc -o /tmp/cinemana-core CinemanaMobile/Models.swift CinemanaMobile/CinemanaAPI.swift CinemanaMobile/PlaybackPlanner.swift CinemanaMobile/OfflineModels.swift CinemanaMobile/Subtitles.swift CinemanaMobile/HLSQuality.swift Tests/CoreSmokeTests.swift
/tmp/cinemana-core
```

## Supported playback

Native AVPlayer supports standard HLS and compatible progressive media. Not all streams or formats work on iOS. If the provider restricts a network, an app-side change cannot override the authorization requirement. All catalog URLs and streaming links remain provider-controlled.

See `docs/` (release notes) for features, known limitations, and verification status.


## iOS v1.3 — Cinema controls and offline downloads

- Native AVPlayer keeps AirPlay, supported captions/audio tracks and Picture-in-Picture controls.
- Playback controls also offer 10-second rewind, 30-second forward and speed selection.
- Download movies or individual episodes from their detail screens when the provider supplies a compatible MP4 or HLS stream.
- Downloads are managed under My List → Downloads; cancel, retry and delete are supported.
- Progress and download status are saved locally; the player prefers an existing offline copy before requesting a stream.
- Select a resolution from the download menu. Background download sessions resume under iOS-managed conditions.
- This does **not** bypass DRM, network authorization, ISP restrictions, or provide unauthorized content.
- Building an unsigned IPA does not install it; Apple signing is still necessary.

### GitHub web build
Open Actions → Cinemana iOS Build. The workflow builds the SwiftUI XcodeGen project on macOS and uploads an unsigned IPA artifact. The source is not considered device-tested until an actual iPhone test.
