# Cinemana iOS v1.6.11 — branding without the extra square

Built from v1.6.10 stability-hotfix source. This is a **branding-only** update: playback, catalog loading, episode selection, downloads and stored data are unchanged.

- Uses the provided full-resolution, glossy red `C` film-strip artwork on a black splash, without a second rounded-square tile.
- Displays the full **Cinemana iOS** wordmark as one image, rather than duplicating the app name with separate text and a badge.
- Home Screen / iOS Settings display name is now **Cinemana iOS**; the navigation header also includes the iOS suffix in both sizes.
- Updates the 1024×1024 opaque RGB iOS app icon to the matching emblem on black; the iOS system will still apply its required rounded icon shape.
- Includes the original full artwork assets and retains the v1.6.10 playback recovery checks.

**Testing scope:** Static branding checks, Swift source parsing, release CI validation where a macOS runner is available. The IPA must be rebuilt, signed and tested on-device; a source ZIP is not an installed app.
