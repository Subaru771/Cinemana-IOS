# Cinemana iOS v1.6.9 — Details first, video autostart on Play

This release corrects v1.6.8's unwanted automatic opening of the player whenever a movie or series poster was tapped.

- Movie/series posters open details as they did before.
- Tapping Play/Resume (or a specific episode) opens the fullscreen custom AVPlayer, which automatically begins when the stream is ready.
- Series lists load on the details page; series no longer auto-selects or plays an episode just from tapping the series poster.
- Movie synopsis, metadata and related videos load on the details page without competing with playback.
- Keeps the shorter startup, removed Home Continue Watching carousel, and high-resolution artwork from the packaged source.

Manual QA: Tap a movie poster (should open details and stay idle), tap Play (video should start), go Back (returns to details), tap a series poster (episode list, no auto-play), tap an episode (fullscreen playback starts), test slow network.
