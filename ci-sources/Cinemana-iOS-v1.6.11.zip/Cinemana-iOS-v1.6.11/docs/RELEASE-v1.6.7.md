# Cinemana iOS v1.6.7 — Clean icon and quality menu

- Full-resolution original Cinemana red glossy filmstrip artwork, 1254px, bundled under `Branding/CinemanaIOSIcon-Original.png`.
- Compiled app icon is an opaque 1024x1024 PNG (pre-generated and reproducible via `scripts/make_app_icon.swift`).
- In-app logo asset now uses the original full-resolution PNG, not a small compressed JPEG.
- Download quality menu everywhere shows only 480p, 720p, 1080p and 2160p. No default, best, or Wi-Fi-only menu items.
- Existing saved download quality choices and active transfers are not deleted; only the presented choices change.
- After installing the new IPA, iOS may briefly cache the old Home Screen icon; if so remove the old app/shortcut and reinstall after saving any local data that needs preserving.

Use of media/downloads still requires rights from the provider. Validate on a real iPhone.

## Reviewed-source stability patch

- Reports HLS resolution/manifest failures as failed downloads instead of leaving downloads indefinitely in progress.
- Generates an RGB PNG with no alpha channel for App Store icon compliance.
- Validates the generated app icon is a 1024 × 1024 opaque RGB PNG.
- Original full-resolution 1254 × 1254 red artwork remains unchanged.

**Verification:** portable Swift tests and syntax checks pass. Full macOS/Xcode build and on-device playback/download tests are not performed on this uploaded copy.
