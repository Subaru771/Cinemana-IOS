# Cinemana iOS v1.6.6 — Cinematic native startup

The welcome animation is now the first experience when the app starts. It uses the authentic red filmstrip icon in the project assets, a black-to-red ambient glow, angled light streaks, a sharp CINEMANA wordmark and a restrained iOS label.

### Performance and lifecycle

- The catalog starts loading in parallel with the splash instead of waiting for the animation to complete.
- The startup coordinator recognizes a restored catalog cache, successful catalog fetch, or initial fetch error.
- Minimum splash: 1.05 seconds. Maximum splash: 2.8 seconds (plus the fade). No indefinite waiting for slow provider endpoints.
- Reduce Motion disables entrance and looping animations.
- The optional Telegram sheet remains separate and opens only after the splash closes.
- The native iOS static launch screen background is color-matched to remove a bright flash.

### Validation

Run GitHub Actions to verify iOS compilation and IPA packaging. On device, verify cold start with fast/slow/offline connections, iPhone and iPad sizes, Arabic/RTL, Reduce Motion, and Cinema Hub first-launch behavior.

Existing video player and offline download behavior are intentionally unchanged.
