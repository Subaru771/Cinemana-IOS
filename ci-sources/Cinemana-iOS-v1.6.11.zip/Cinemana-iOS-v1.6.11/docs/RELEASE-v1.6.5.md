# Cinemana iOS v1.6.5 — Reliability and distribution hygiene

- Bounded download resolution: no unrequested upscale. Explicit error if provider offers no quality <= selected maximum.
- Master HLS variant selection reads provider playlist and selects highest declared rendition <= limit. Single-rendition playlists use the provider-provided quality label.
- Download menu offers only 480/720/1080/2160p. Default, Best available and Wi-Fi-only controls (menu, Downloads and Settings) were removed.
- Smoother UI: larger image cache with fade-in posters, throttled download progress updates, shorter splash.
- Source discovery waits briefly for the other provider endpoint to combine quality options.
- Cinema Hub welcome appears only on first launch by default; Settings can re-enable it. Checkbox remains respected.
- 1024px high quality brand asset plus original 1254px PNG; removed 256px blurry fallback.
- Core tests and docs updated.

## Verification
Portable Swift core tests and syntax parsing can be run on Linux. Xcode/iPhone-specific compile and media integration require macOS CI / a device; no actual remote streaming was tested.

## Important limitation
HLS video quality relies on provider-declared rendition metadata or a fixed playlist; servers may replace or block streams. This app does not override provider authorization or DRM.
