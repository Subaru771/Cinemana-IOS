# Library tab + smoothness changes

- My List tab now has a Continue Watching / Favorites segmented switcher, with its own empty state for each.
- Posters load through `PosterImageCache` (decoded off the main thread, downsampled, memory-cached) instead of `AsyncImage`, so rows no longer flicker or stutter while scrolling. Also used in Downloads.
- Continue Watching progress bars no longer use a GeometryReader per card.
- Library saves are encoded and written off the main thread.
- Download quality menu already shows only 480p / 720p / 1080p / 2160p (no default, preferred or Wi-Fi-only items) in this source.
