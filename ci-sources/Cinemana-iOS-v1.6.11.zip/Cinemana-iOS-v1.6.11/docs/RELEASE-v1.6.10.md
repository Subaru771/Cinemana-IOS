# Cinemana iOS v1.6.10 — playback regression recovery

**Issue:** v1.6.9 moved details and episodes to a sequence of awaited network requests and used asynchronously replaced video metadata to decide Play availability. A failed resume seek also kept the player paused.

**Changes:** restored concurrent details/episodes/related loading with incremental UI updates, kept the original selected video identifier and type for playback targeting, allowed only explicit Play/Resume/episode selection to launch the fullscreen player, and unconditionally started AVPlayer when ready even if resume seek fails.

**No changes** to saved library data, downloads, Arabic localization, startup visuals, or Home's removed Continue Watching section.

**Validation:** static source regression checks, portable Swift core tests, asset and locale checks, and GitHub Xcode compilation when available. These cannot prove runtime behavior with the user's actual network or LiveContainer; use a real iPhone test before wider distribution.

If the app still crashes before opening any title, or all videos show an error, capture the precise screen message, iOS version, and whether it is running in LiveContainer or a signed installation. App installation and provider/network restrictions are separate from navigation behavior.
