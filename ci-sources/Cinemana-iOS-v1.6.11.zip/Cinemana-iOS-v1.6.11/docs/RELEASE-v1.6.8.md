# Cinemana iOS v1.6.8 — Faster launch and immediate playback

## Behavior
- The Home screen **Continue Watching** strip is removed without deleting progress or the My List history tab.
- A movie or individual episode automatically opens the fullscreen player when selected.
- A series fetches its episode list and automatically starts the first available or next unfinished episode; if there is no available episode it stays on details.
- Extra detail/related fetches are deferred until after the player is dismissed.
- Startup overlay no longer waits for the catalog/network: approximately 560ms + 180ms fade.
- Cached Home catalogs show instantly without an automatic set of four provider calls. Pull-to-refresh is still available.
- Stream lookups use a first-compatible-response strategy for playback and cap the wait at 2.5 seconds; download resolution choices still perform full source aggregation.

## Image-quality behavior
- Complete source ZIP includes the original 1254px opaque PNG and 1024px RGB AppIcon.
- The startup view checks the actual pixel dimensions. If a GitHub build is missing that high-resolution asset, it shows a native resolution-independent red vector placeholder instead of enlarging a 256px JPEG.
- GitHub currently lacks the original binary in `Branding/`. Upload `Branding/CinemanaIOSIcon-Original.png` for identical branding in GitHub-built IPAs; until then the fallback vector will not match the exact glossy image.

## On-device test checklist
1. Reinstall/update the IPA; verify no Continue Watching strip on Home; progress remains under My List.
2. Tap a movie poster: the player appears without a second Play tap.
3. Tap a series poster: it loads episodes and starts the first playable or next unfinished episode.
4. Exit playback; check details and episode selection still work.
5. Test a slow or disconnected network: the splash dismisses promptly; provider failure is reported separately.
6. Confirm the opening logo is sharp and no blurred/upscaled icon appears.
7. Verify streaming resumes, manual quality switching, and downloads still function.

All remote playback depends on actual media-provider access. Performance improvements are not verified by a real iPhone benchmark.
