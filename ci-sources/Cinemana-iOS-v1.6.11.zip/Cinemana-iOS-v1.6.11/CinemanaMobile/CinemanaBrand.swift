import SwiftUI
import UIKit

/// Prefer the user's full-resolution original artwork. Older GitHub builds
/// bundled a 256px placeholder; that is never enlarged for the startup UI.
private enum CinemanaLogoSource {
    static let sharpArtworkAvailable: Bool = {
        guard let asset = UIImage(named: "CinemanaArtwork"), let image = asset.cgImage else {
            return false
        }
        return image.width >= 1024 && image.height >= 1024
    }()
}

struct CinemanaGlyph: View {
    var body: some View {
        Group {
            if CinemanaLogoSource.sharpArtworkAvailable {
                Image("CinemanaArtwork")
                    .resizable()
                    .interpolation(.high)
                    .aspectRatio(contentMode: .fit)
            } else {
                // Never upscale a compressed 256px JPEG: use resolution-
                // independent SwiftUI artwork until the master PNG is installed.
                CinemanaVectorFallbackGlyph()
            }
        }
        .aspectRatio(1, contentMode: .fit)
        .accessibilityLabel("Cinemana iOS")
    }
}

private struct CinemanaVectorFallbackGlyph: View {
    private let ruby = Color(red: 0.98, green: 0.08, blue: 0.16)

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            ZStack {
                // The fallback never draws a rounded icon tile.
                Text("C")
                    .font(.system(size: side * 0.90, weight: .black, design: .rounded))
                    .foregroundStyle(LinearGradient(colors: [Color(red: 1, green: 0.57, blue: 0.61),
                                                             ruby, Color(red: 0.63, green: 0.005, blue: 0.06)],
                                                    startPoint: .topLeading, endPoint: .bottomTrailing))
                    .shadow(color: ruby.opacity(0.43), radius: side * 0.04)
                Image(systemName: "play.fill")
                    .font(.system(size: side * 0.29, weight: .black))
                    .foregroundStyle(.white)
                    .offset(x: side * 0.10, y: -side * 0.015)
            }
            .frame(width: side, height: side)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
    }
}

/// Lets the opening animation end when the Home catalog has actually been
/// restored or fetched, rather than waiting an arbitrary number of seconds.
@MainActor
final class CinemanaStartupState: ObservableObject {
    @Published private(set) var catalogReady = false

    func finishInitialCatalogLoad() {
        catalogReady = true
    }
}

/// Launch branding uses the source artwork directly: sharp red C on black,
/// the complete Cinemana iOS wordmark, and no inner square icon tile.
/// This overlay runs above catalog loading and respects Reduce Motion.
struct CinemanaSplashView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var revealed = false
    @State private var lightSweep = false

    private let scarlet = Color(red: 1.0, green: 0.15, blue: 0.23)

    var body: some View {
        GeometryReader { geometry in
            let logoSize = min(292, max(176, min(geometry.size.width * 0.75,
                                                geometry.size.height * 0.34)))
            ZStack {
                Color.black

                VStack(spacing: 0) {
                    Spacer(minLength: 38)

                    VStack(spacing: 8) {
                        CinemanaGlyph()
                            .frame(width: logoSize, height: logoSize)
                        Image("CinemanaWordmark")
                            .resizable()
                            .interpolation(.high)
                            .scaledToFit()
                            .frame(width: min(360, geometry.size.width * 0.90))
                            .accessibilityHidden(true)
                    }
                    .scaleEffect(revealed ? 1 : 0.93)
                    .opacity(revealed ? 1 : 0)
                    .offset(y: revealed ? 0 : 12)

                    Spacer(minLength: 36)

                    VStack(spacing: 14) {
                        GeometryReader { track in
                            ZStack(alignment: .leading) {
                                Capsule().fill(.white.opacity(0.12))
                                Capsule()
                                    .fill(LinearGradient(colors: [scarlet.opacity(0.25),
                                                                  scarlet, Color(red: 1, green: 0.55, blue: 0.57)],
                                                         startPoint: .leading, endPoint: .trailing))
                                    .frame(width: track.size.width * 0.31)
                                    .offset(x: lightSweep ? track.size.width * 0.69 : 0)
                            }
                            .clipShape(Capsule())
                        }
                        .frame(width: min(175, geometry.size.width * 0.47), height: 3)
                        .accessibilityHidden(true)

                        Text("PREPARING YOUR EXPERIENCE")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(1.9)
                            .foregroundStyle(.white.opacity(0.55))
                    }
                    .padding(.bottom, max(30, geometry.safeAreaInsets.bottom + 16))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(.horizontal, 20)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .background(Color.black)
        .ignoresSafeArea()
        .preferredColorScheme(.dark)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Cinemana iOS is opening")
        .task {
            if reduceMotion {
                revealed = true
                lightSweep = true
            } else {
                withAnimation(.easeOut(duration: 0.26)) { revealed = true }
                withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) {
                    lightSweep = true
                }
            }
        }
    }
}
