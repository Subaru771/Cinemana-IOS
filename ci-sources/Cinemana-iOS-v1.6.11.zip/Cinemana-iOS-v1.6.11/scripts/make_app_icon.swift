import AppKit
import Foundation

// The release archive ships two master-backed PNGs. Validate and use the
// existing 1024px opaque AppIcon instead of recompressing or resizing the art.
// This avoids accidentally rebuilding the icon from a low-resolution fallback.
let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let artwork = root.appendingPathComponent("Branding/CinemanaIOSIcon-Original.png")
let iconURL = root.appendingPathComponent("CinemanaMobile/Assets.xcassets/AppIcon.appiconset/AppIcon.png")
let data = try Data(contentsOf: artwork)
guard let master = NSBitmapImageRep(data: data),
      master.pixelsWide >= 1024, master.pixelsHigh >= 1024 else {
    fatalError("Full-resolution original Cinemana PNG (1024px minimum) is required")
}

let assetRoot = root.appendingPathComponent("CinemanaMobile/Assets.xcassets")
let artworkDir = assetRoot.appendingPathComponent("CinemanaArtwork.imageset")
try FileManager.default.createDirectory(at: artworkDir, withIntermediateDirectories: true)
let copiedArt = artworkDir.appendingPathComponent("CinemanaArtwork.png")
let imageNeedsUpdate: Bool
if FileManager.default.fileExists(atPath: copiedArt.path) {
    imageNeedsUpdate = try Data(contentsOf: copiedArt) != data
} else {
    imageNeedsUpdate = true
}
if imageNeedsUpdate { try data.write(to: copiedArt, options: .atomic) }
let assetJSON = """
{
  "images": [{ "filename": "CinemanaArtwork.png", "idiom": "universal" }],
  "info": { "author": "xcode", "version": 1 }
}
"""
try assetJSON.write(to: artworkDir.appendingPathComponent("Contents.json"),
                    atomically: true, encoding: .utf8)

let icon = try Data(contentsOf: iconURL)
let pngSignature: [UInt8] = [137, 80, 78, 71, 13, 10, 26, 10]
guard icon.count > 26, Array(icon.prefix(8)) == pngSignature,
      icon[25] == 2,
      let bitmap = NSBitmapImageRep(data: icon),
      bitmap.pixelsWide == 1024, bitmap.pixelsHigh == 1024 else {
    fatalError("Provide the included 1024x1024 opaque RGB AppIcon.png. An alpha-channel or small icon is not acceptable.")
}
print("Verified original Cinemana \(master.pixelsWide)x\(master.pixelsHigh) artwork and opaque 1024px iOS AppIcon")
