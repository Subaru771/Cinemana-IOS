# Cinemana TV v1.5.3 — Focus and settings repair

- Explicit D-pad focus targets for each Settings category and the first choice in the right pane.
- Right opens the focused category; Left from its first option returns to the category.
- Brighter focus chevron alongside the existing TV focus border.
- Removed the manual timestamp editor and the community timestamp toggle from Settings.
- Community intro/credit lookups run automatically; previously saved mature ranges remain usable.
- Removed Up-to-open-Search interception in the top navigation bar.
- Preserved the player, movie/series discovery, existing mature skip rules and saved preferences.
- Android versionCode 48, versionName 1.5.3.

**Coverage:** The mature-scene feature still requires reliable segment timing for each video version. It cannot detect unmarked scenes.
