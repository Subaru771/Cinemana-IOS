# v1.5.6 — Mature skip status & Search filter

- Added four-state mature skip badge to posters, episode cards, and details.
- Added Search → Filters → Mature skip: Any / Has markers / No markers / Unknown.
- Bounded concurrent metadata checking (3) and memory TTLs. Filter checks every currently returned visible result progressively.
- Only trusted public source entries with source-reported runtimes and explicit mature-scene reasons count as listed; actual player runtime still governs seeking.
- No marker lookup runs for series at the title level: public mature skipping is movie-only for now. Preserved local episode markers remain visible.
- Failed metadata requests are `Unknown`, not `No markers`; no false family-safety promise.
- Added unit tests and bilingual UI labels.
- APK signing: debug-key test build, not a distribution-signed release.

Verification in development environment: pure Kotlin filter smoke PASS (with lightweight stubs). Full Android Gradle build / TV runtime NOT TESTED because SDK/Gradle are unavailable here.
