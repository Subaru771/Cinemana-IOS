# Mature scene skip verification (v1.5.6 fixed source)

This source contains the CleanStream runtime-null import fix. **An APK has not been compiled or tested here.**

## What the status means
- `✓ SKIP` / listed: an eligible mature-scene timestamp exists in a public source; this **does not** guarantee coverage or safety.
- `NO MARKERS`: checked available responses contain no eligible timestamps.
- `SKIP ?`: no IMDb ID, malformed response, network error, or the TV episode cannot be determined.
- The MovieHavenDB repository currently only contains `movies/tt0266543.json` (Finding Nemo), a mute-only record with no mature skip.

CleanStream imports with `runtime: null` / `releases: []` are accepted if their category is mature and their ranges fit the actual stream. A source that declares a runtime must match the stream within 5,000 ms. Entries with more down-votes than up-votes are ignored. This does not solve timestamps offset by edits, intros, content provider cuts, or encoding differences.

## On-device checklist
1. Choose **Mature content → Skip scenes** in Settings. Verify the app is not in **Hide mature titles** mode.
2. Open a movie with a known CleanStream record and IMDb id. Wait until playback has a known duration.
3. Run `adb logcat -c && adb logcat -s MatureSkip:D '*:S'` from a PC while the movie is playing.
4. Check that `imdb=...`, `streamDurationMs=...`, `CleanStream=ok accepted=N`, and `skipping ...` appear.
5. At each marker boundary confirm video seeks to the end of the marker, then test Undo.
6. Test a different cut and confirm out-of-range timestamps are rejected; test a series to ensure it stays unknown without episode-specific markers.
7. Check Search → Filters → Mature skip; statuses can appear only after the lookup completes.

## Distribution
`bash gradlew --no-daemon testDebugUnitTest assembleRelease` creates a locally debug-key-signed release APK when dependencies are available. It is **not** production-signed and may not update an app installed from a different signing key. Configure the `CINEMANA_CLIENTID` secret for GitHub Actions to support sign-in without embedding credentials in the repo.
