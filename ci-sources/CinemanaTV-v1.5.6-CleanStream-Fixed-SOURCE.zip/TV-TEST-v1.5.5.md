# Cinemana TV v1.5.5 — real-TV verification

No APK was built in this environment. Once built on Windows, test on the actual Android TV/Google TV using its remote.

1. On Home, highlight one of the top navigation destinations. Press **Up**. Search opens and the cursor is placed in the search field.
2. Close Search via the top-right Close button and confirm you return to the same destination (Home, Series, Movies, History, My List, Downloads, Settings).
3. From Settings, highlight **Mature content**, **Playback** and **Subtitles** by D-pad **Down** only: the active marker and right-hand options must change *without* pressing OK.
4. Press **Right** on a category. Its options must receive focus. Press **Left** to return to the category list. Verify the focus ring stays visible.
5. While in Playback Settings, open Search via the top bar, then close it. The previously selected Settings category must still be selected.
6. When Search is open, hold or rapidly press D-pad arrows. Only search controls/results should respond; hidden settings or playback/home content must never receive focus.
7. Search for `the mentalist`: the exact title should rank above loosely related suggestions. Select Show related results to reveal the rest.
8. Confirm Downloads, watch history, progress, and mature-content controls behave as before. Scene skipping works only where verified time-coded markers exist.

**Signing warning:** The supplied release build uses your machine's debug signing key, not a common release key. An APK signed by a different key may not install over your previous version. Do not uninstall without backing up app data.
