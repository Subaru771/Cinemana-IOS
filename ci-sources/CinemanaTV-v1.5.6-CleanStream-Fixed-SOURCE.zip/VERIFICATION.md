# Cinemana TV v1.5.6 — source verification

Verified on this container on 2026-11-09:
- Source ZIP integrity: PASS
- Two divergent project copies in user's ZIP identified and consolidated: PASS
- Original top-level copy retained for runtime fixes; nested copy used only for builder utilities.
- Kotlin search/mature-skip logic compiled against isolated stubs: PASS
- Five local mature-skip/search filter assertions: PASS
- Android APK build: NOT RUN — Android SDK and Gradle distribution unavailable
- APK signing/on-device functionality: NOT VERIFIED

The difference between mature skip marker availability and guaranteed content filtering
is intentional: the badge reports published markers only, not complete safety.
