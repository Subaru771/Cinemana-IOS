@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.ui

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent as AndroidKeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C as MediaC
import androidx.media3.common.PlaybackException
import app.cinemanatv.util.SmartQuality
import app.cinemanatv.util.preferredSubtitleLabel
import app.cinemanatv.util.NextEpisodePreloader
import app.cinemanatv.util.TvHomeIntegration
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.PlaySources
import app.cinemanatv.data.QualityOption
import app.cinemanatv.data.Video
import app.cinemanatv.data.MatureAction
import app.cinemanatv.data.SceneSkipping
import app.cinemanatv.data.SceneRange
import app.cinemanatv.data.ExternalSceneMarker
import app.cinemanatv.data.ExternalSceneMarkers
import app.cinemanatv.data.RemoteSceneMetadata
import app.cinemanatv.data.SkipOffer
import app.cinemanatv.data.SkipPlanner
import app.cinemanatv.util.Capabilities
import app.cinemanatv.util.Downloads
import app.cinemanatv.util.NetworkResilience
import app.cinemanatv.util.TimedCaption
import app.cinemanatv.util.parseTimedSubtitles
import app.cinemanatv.util.activeCaptions
import app.cinemanatv.data.userAgent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.URL
import app.cinemanatv.util.FailureType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withTimeoutOrNull
import java.text.DateFormat
import java.util.Locale

// All interaction goes through focusable TV surfaces, never touchscreen-only overlays.
private val Ink = Color(0xFF080C0C)
private val Glass = Color(0xEF111817)
private val Muted = Color(0xFFAAB8B2)
private val Accent = Color(0xFF83FFA4)
private val Focus = Color(0xFFF2FFF6)
private enum class PlayerSheet { ROOT, QUALITY, SUBTITLES, SUBSIZE, SUBSYNC, SUBSTYLE, SUBPOSITION, AUDIO, SPEED, ASPECT, DETAILS }
private enum class ScreenMode { FIT, FILL, ZOOM }

/** What "Undo skip" restores: where to seek back to and, for mature scenes, which range to exempt. */
private data class UndoInfo(val returnMs: Long, val range: SceneRange?)

private fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}

private fun playClock(ms: Long): String {
    val seconds = (ms / 1000L).coerceAtLeast(0L)
    return if (seconds >= 3600L) String.format(Locale.US, "%d:%02d:%02d", seconds / 3600, (seconds / 60) % 60, seconds % 60)
    else String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60)
}


/**
 * Night-style minimal video player OSD, adapted for TV D-pad and media key control.
 * The native Media3 PlayerView is video/subtitles only; it never steals remote focus.
 */
@Composable
fun PlayerScreen(
    queue: List<Video>,
    startIndex: Int,
    onExit: () -> Unit,
    onRegisterBack: ((() -> Unit)?) -> Unit,
) {
    if (queue.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            PlayerTile("Back to browsing", "‹", primary = true, onClick = onExit)
        }
        return
    }
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current
    val prefs = Services.prefs
    val engine = remember(context) { CinemaPlaybackEngine(context.applicationContext) }
    val player = engine.player
    var index by remember { mutableIntStateOf(startIndex.coerceIn(0, queue.lastIndex)) }
    val video = queue[index]
    var sources by remember(video.id) { mutableStateOf<PlaySources?>(null) }
    var subtitleOptions by remember(video.id) { mutableStateOf<List<app.cinemanatv.data.SubtitleOption>>(emptyList()) }
    var subtitleLoading by remember(video.id) { mutableStateOf(true) }
    var subtitleError by remember(video.id) { mutableStateOf(false) }
    var subtitleRetry by remember(video.id) { mutableIntStateOf(0) }
    var qualityIndex by remember(video.id) { mutableIntStateOf(0) }
    var selectedSubs by remember(video.id) { mutableStateOf(prefs.subtitleLabel.takeIf { it.isNotBlank() && prefs.preferredSubtitleLanguage == "auto" }) }
    var initialSubtitlePreferenceApplied by remember(video.id) { mutableStateOf(false) }
    var selectedAudio by remember(video.id) { mutableStateOf<String?>(null) }
    var fetchError by remember(video.id) { mutableStateOf<String?>(null) }
    var reload by remember(video.id) { mutableIntStateOf(0) }
    var retries by remember(video.id) { mutableIntStateOf(0) }
    var lastLink by remember { mutableStateOf(NetworkResilience.link(context.applicationContext)) }
    var finished by remember(video.id) { mutableStateOf(false) }
    var automaticNext by remember(video.id) { mutableStateOf(prefs.autoPlayNextEnabled) }
    var episodesSinceBreak by remember { mutableIntStateOf(1) }
    var countdown by remember(video.id) { mutableIntStateOf(8) }
    var buffering by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var playbackError by remember { mutableStateOf<PlaybackException?>(null) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var aspect by remember { mutableStateOf(ScreenMode.FIT) }
    var controlsVisible by remember { mutableStateOf(true) }
    var sheet by remember { mutableStateOf<PlayerSheet?>(null) }
    var timelineFocused by remember { mutableStateOf(false) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var showBuffering by remember { mutableStateOf(false) }
    var seekPreview by remember { mutableStateOf<Long?>(null) }
    // Quality: Auto adapts downward when the connection can't keep up; picking a quality by hand locks it.
    var qualityLocked by remember(video.id) { mutableStateOf(false) }
    // Global Preferred Quality picks the actual provider rendition at start; it is
    // distinct from Auto (bandwidth-aware). An in-player override lasts this title.
    var preferredActive by remember(video.id) { mutableStateOf(prefs.maxQuality > 0) }
    var autoIndex by remember(video.id) { mutableIntStateOf(0) }
    var subScale by remember { mutableFloatStateOf(prefs.subtitleScale) }
    var subDelay by remember { mutableLongStateOf(prefs.subtitleDelayMs) }
    var subStyle by remember { mutableIntStateOf(prefs.subtitleStyle) }
    var subPlacement by remember { mutableIntStateOf(prefs.subtitlePlacement) }
    var timedSubs by remember(video.id) { mutableStateOf<List<TimedCaption>?>(null) }
    var syncNote by remember(video.id) { mutableStateOf<String?>(null) }
    var introWindow by remember(video.id) { mutableStateOf(video.introWindow) }
    var externalMarkers by remember(video.id) { mutableStateOf<List<ExternalSceneMarker>>(emptyList()) }
    var markerStreamKey by remember(video.id) { mutableStateOf("") }
    var markerDurationMs by remember(video.id) { mutableLongStateOf(0L) }
    // Community lookups are always available: no hidden 'timestamp' setting to enable first.
    val communityMarkerOptIn = true
    val skipMarkedScenes = prefs.matureAction == MatureAction.SKIP_SCENES
    // Preserve previously saved scene ranges while removing the manual editor from the UI.
    val sceneRanges = remember(video.id) { prefs.sceneRanges(video.id) }
    // Undo only exempts the specifically restored scene for this playback session.
    var undoInfo by remember(video.id) { mutableStateOf<UndoInfo?>(null) }
    var exemptScenes by remember(video.id) { mutableStateOf<Set<SceneRange>>(emptySet()) }
    // Intro/recap/credits: the offer currently on screen, and segments already acted on this playback.
    var skipOffer by remember(video.id) { mutableStateOf<SkipOffer?>(null) }
    var detailInfo by remember(video.id) { mutableStateOf<Video?>(null) }
    var nearEnd by remember(video.id) { mutableStateOf(false) }
    val handledSkips = remember(video.id) { HashSet<String>() }
    val skipRequester = remember { FocusRequester() }
    var nextPromptDismissed by remember(video.id) { mutableStateOf(false) }
    var recoveryCount by remember(video.id) { mutableIntStateOf(0) }
    var pendingRestore by remember(video.id) { mutableLongStateOf(-1L) }
    // Not UI state: stall timestamps, and the time of the last seek/open (which also make the
    // player buffer, but are not "stalls").
    val recentStalls = remember { ArrayList<Long>() }
    val lastQualityShift = remember(video.id) { longArrayOf(SystemClock.elapsedRealtime()) }
    val watchNextSync = remember(video.id) { longArrayOf(0L) }
    val bufferGate = remember { LongArray(1) }
    val clock = remember { DateFormat.getTimeInstance(DateFormat.SHORT) }
    // A job handle isn't UI state; keeping it out of snapshots avoids extra
    // recompositions on every remote repeat.
    val seekCommit = remember { arrayOfNulls<Job>(1) }
    val scope = rememberCoroutineScope()
    val rootRequester = remember { FocusRequester() }
    val primaryRequester = remember { FocusRequester() }
    val sheetRequester = remember { FocusRequester() }
    val endRequester = remember { FocusRequester() }
    val timelineRequester = remember { FocusRequester() }

    fun trackHeightCap(stream: app.cinemanatv.data.QualityOption): Int = when {
        // A manual rendition choice takes priority over the global setting.
        qualityLocked && stream.height > 0 -> stream.height
        preferredActive && prefs.maxQuality > 0 -> prefs.maxQuality
        else -> Capabilities.autoHeight(context)
    }
    fun reveal() { controlsVisible = true; interactionTick++ }
    // Hiding the HUD must also clear the timeline-focus flag, or auto-hide stays suppressed.
    fun hideControls() { timelineFocused = false; controlsVisible = false }
    fun saveProgress() {
        val mediaId = player.currentMediaItem?.mediaId ?: return
        val length = player.duration
        if (length <= 0) return
        val current = player.currentPosition.coerceAtLeast(0L)
        val keep = current >= 10_000L && current < length - 30_000L
        prefs.setResume(mediaId, if (keep) current else 0L)
        val matched = queue.firstOrNull { it.id == mediaId }
        if (keep && matched != null) prefs.touchRecent(matched) else prefs.dropRecent(mediaId)
        if (matched != null) {
            if (!keep) TvHomeIntegration.enqueueRemove(context.applicationContext, mediaId)
            else if (prefs.tvHomeEnabled &&
                SystemClock.elapsedRealtime() - watchNextSync[0] >= 45_000L) {
                watchNextSync[0] = SystemClock.elapsedRealtime()
                TvHomeIntegration.enqueueUpdate(context.applicationContext, matched, current, length)
            }
        }
    }
    fun seekBy(ms: Long) {
        if (!player.isCurrentMediaItemSeekable || player.duration <= 0) return
        seekCommit[0]?.cancel()
        seekPreview = null
        engine.seek(ms)
        position = player.currentPosition.coerceAtLeast(0L)
        reveal()
        hint = (if (ms > 0) "+" else "−") + "${kotlin.math.abs(ms / 1000L)} sec"
    }
    // Holding a remote arrow must not send 15–30 decoder seeks per second.
    // Preview instantly, then coalesce repeated presses into one actual seek.
    fun scrubBy(ms: Long, repeatCount: Int = 0) {
        val length = player.duration
        if (!player.isCurrentMediaItemSeekable || length <= 0L) return
        val step = when {
            repeatCount >= 16 -> ms * 6
            repeatCount >= 6 -> ms * 3
            else -> ms
        }
        val next = ((seekPreview ?: player.currentPosition) + step).coerceIn(0L, length)
        seekPreview = next
        position = next // Immediate visible feedback, independent of stream latency.
        hint = "Seeking  ${playClock(next)} / ${playClock(length)}"
        reveal()
        seekCommit[0]?.cancel()
        seekCommit[0] = scope.launch {
            delay(if (repeatCount == 0) 100L else 170L)
            player.seekTo(next)
            seekPreview = null
            position = next
        }
    }
    fun togglePlayback() { if (player.isPlaying) player.pause() else player.play(); reveal() }
    fun jumpTo(targetIndex: Int) {
        if (targetIndex !in queue.indices || targetIndex == index) return
        episodesSinceBreak = if (targetIndex == index + 1) episodesSinceBreak + 1 else 1
        seekCommit[0]?.cancel()
        seekPreview = null
        saveProgress()
        player.stop()
        index = targetIndex
        finished = false
        sheet = null
        controlsVisible = true
        hint = null
        interactionTick++
    }
    fun performSkip(offer: SkipOffer) {
        if (!player.isCurrentMediaItemSeekable) return
        handledSkips.add(offer.key)
        val from = player.currentPosition
        // Credits that run to the end of the file: the natural next step is the next episode.
        if (offer.toEnd && index < queue.lastIndex) { jumpTo(index + 1); return }
        undoInfo = UndoInfo((from - 500L).coerceAtLeast(0L), null)
        engine.seekExact(offer.targetMs)
        position = offer.targetMs
        skipOffer = null
        hint = "Skipped · press ◀ to undo"
    }
    fun undoSkip() {
        val undo = undoInfo ?: return
        undo.range?.let { exemptScenes = exemptScenes + it }
        engine.seekExact(undo.returnMs)
        position = undo.returnMs
        undoInfo = null
        hint = "Skip undone"
    }
    fun openExternalPlayer() {
        val stream = sources?.qualities?.getOrNull(qualityIndex)
        val link = stream?.url.orEmpty()
        val scheme = runCatching { Uri.parse(link).scheme?.lowercase(Locale.US) }.getOrNull()
        if (scheme != "http" && scheme != "https") {
            hint = "External playback needs an online HTTP stream"
            sheet = null
            return
        }
        // No cookies or authentication headers are forwarded. This is explicit user action;
        // the external app only receives the currently selected playback URL.
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(link), "video/*")
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "Choose video player"))
            saveProgress()
            player.pause()
            sheet = null
        } catch (_: Exception) {
            hint = "No compatible video player installed"
            sheet = null
        }
    }

    fun goBack() {
        val level = when (sheet) {
            null -> 0
            PlayerSheet.ROOT -> 1
            else -> 2
        }
        when (app.cinemanatv.util.backDestination(2, 0, level)) {
            app.cinemanatv.util.BackDestination.CLOSE_SUBMENU -> sheet = PlayerSheet.ROOT
            app.cinemanatv.util.BackDestination.CLOSE_PANEL -> sheet = null
            else -> { saveProgress(); onExit() }
        }
    }

    // Two real mid-playback stalls within a minute means the link can't sustain this bitrate:
    // step down one quality (resuming at the same position) instead of stuttering forever.
    fun noteStall() {
        val now = SystemClock.elapsedRealtime()
        recentStalls.removeAll { now - it > 60_000L }
        recentStalls.add(now)
        val options = sources?.qualities ?: return
        if (recentStalls.size >= 2 && !qualityLocked && !preferredActive && qualityIndex < options.lastIndex &&
            !options[qualityIndex].adaptive) {
            recentStalls.clear()
            lastQualityShift[0] = now
            qualityIndex++
            hint = "Slow connection · switching to ${options[qualityIndex].label}"
        }
    }

    DisposableEffect(player) {
        var lastState = Player.STATE_IDLE
        val listener = object : Player.Listener {
            override fun onTracksChanged(newTracks: Tracks) { tracks = newTracks }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK ||
                    reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT) {
                    bufferGate[0] = SystemClock.elapsedRealtime()
                }
            }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING || state == Player.STATE_IDLE
                if (state == Player.STATE_BUFFERING && lastState != Player.STATE_BUFFERING) {
                    bufferGate[0] = SystemClock.elapsedRealtime()
                }
                if (state == Player.STATE_BUFFERING && lastState == Player.STATE_READY &&
                    player.playWhenReady && SystemClock.elapsedRealtime() - bufferGate[0] > 2_000L) {
                    noteStall()
                }
                lastState = state
                if (state == Player.STATE_ENDED) { finished = true; controlsVisible = true }
            }
            override fun onRenderedFirstFrame() { app.cinemanatv.util.PerformanceMetrics.firstFrame() }
            override fun onPlayerError(error: PlaybackException) { playbackError = error }
        }
        player.addListener(listener)
        onDispose {
            // A player teardown exception must not kill the entire Activity when
            // returning to the title details. Log each failure for diagnosis.
            seekCommit[0]?.cancel()
            runCatching { saveProgress() }
                .onFailure { Log.e("CinemanaBack", "Saving playback position during Back failed", it) }
            runCatching { player.removeListener(listener) }
                .onFailure { Log.e("CinemanaBack", "Removing player listener failed", it) }
            runCatching { engine.close() }
                .onFailure { Log.e("CinemanaBack", "Releasing player failed", it) }
        }
    }
    DisposableEffect(lifecycleOwner, player) {
        var resumeAfterPause = false
        val listener = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> {
                    resumeAfterPause = player.isPlaying
                    saveProgress()
                    player.pause()
                }
                Lifecycle.Event.ON_START -> {
                    if (resumeAfterPause) player.play()
                    resumeAfterPause = false
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(listener)
        onDispose { lifecycleOwner.lifecycle.removeObserver(listener) }
    }
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    // Title details give us the provider's own intro window and the IMDb id. Fetched once, shared
    // by both consumers (it used to be requested twice in parallel).
    LaunchedEffect(video.id) {
        val details = runCatching { Services.repo.info(video) }.getOrNull()
        detailInfo = details
        if (introWindow == null) introWindow = details?.introWindow
    }

    // Public timestamp lookups are bounded, cached and independent of playback startup.
    // They never send video bytes or watch history.
    LaunchedEffect(video.id, detailInfo, duration / 1000L, qualityIndex, reload, communityMarkerOptIn, skipMarkedScenes) {
        // Changing stream quality or reopening a stream invalidates old scene markers.
        // A different cut can have new offsets even when the IMDb title stays the same.
        val streamKey = "$qualityIndex|$reload"
        if (markerStreamKey != streamKey) {
            externalMarkers = emptyList()
            markerStreamKey = streamKey
            markerDurationMs = 0L
        }
        if (markerDurationMs > 0L && kotlin.math.abs(markerDurationMs - duration) > 5_000L)
            externalMarkers = emptyList()
        if (!communityMarkerOptIn && !skipMarkedScenes) {
            externalMarkers = emptyList()
            return@LaunchedEffect
        }
        // Keep what we have while the duration is briefly unknown (quality switch, reopen).
        if (duration < 60_000L) return@LaunchedEffect
        // The detail request may have failed (detailInfo == null). Playback metadata that already
        // carries an IMDb id must still be usable; only wait for details when we have no id yet.
        val details = detailInfo
        if (details == null && ExternalSceneMarkers.imdbID(video.imdbRef) == null &&
            ExternalSceneMarkers.imdbID(video.rootSeriesInfo?.imdbRef) == null) return@LaunchedEffect
        val rootDetails = if (video.rootSeriesInfo?.imdbRef.isNullOrBlank() && video.rootSeries != null &&
            ExternalSceneMarkers.imdbID(video.imdbRef) == null && ExternalSceneMarkers.imdbID(details?.imdbRef) == null)
            runCatching { Services.repo.info(video.copy(nb = video.rootSeries)) }.getOrNull()
            else null
        val imdb = ExternalSceneMarkers.imdbID(video.imdbRef)
            ?: ExternalSceneMarkers.imdbID(details?.imdbRef)
            ?: ExternalSceneMarkers.imdbID(video.rootSeriesInfo?.imdbRef)
            ?: ExternalSceneMarkers.imdbID(rootDetails?.imdbRef)
        if (imdb == null) {
            Log.d("MatureSkip", "title=${video.id} imdb=missing skipMode=$skipMarkedScenes")
            return@LaunchedEffect
        }
        Log.d("MatureSkip", "title=${video.id} imdb=$imdb streamDurationMs=$duration skipMode=$skipMarkedScenes")
        val marks = RemoteSceneMetadata.load(imdb, if (video.episodeNumber > 0) video.seasonNumber else 0,
            video.episodeNumber, duration, communityMarkerOptIn, skipMarkedScenes)
        // A network lookup might finish after Media3 has switched to another rendition/cut.
        if (kotlin.math.abs(player.duration.coerceAtLeast(0L) - duration) > 5_000L) return@LaunchedEffect
        markerDurationMs = duration
        externalMarkers = marks
        Log.d("MatureSkip", "imdb=$imdb acceptedMature=${marks.count { it.kind == "mature" }} otherMarkers=${marks.count { it.kind != "mature" }}")
        if (skipMarkedScenes && video.episodeNumber == 0 && sceneRanges.isEmpty() &&
            marks.none { it.kind == "mature" })
            hint = "No mature-scene markers match this stream's runtime"
    }

    // Optional subtitles load independently of media discovery. A failed subtitle request
    // can be retried from the drawer without interrupting the video.
    LaunchedEffect(video.id, subtitleRetry) {
        subtitleLoading = true
        subtitleError = false
        try {
            subtitleOptions = withTimeoutOrNull(12_000L) { Services.repo.loadSubtitles(video.id) }
                ?: throw java.io.IOException("Subtitle request timed out")
        } catch (c: CancellationException) { throw c }
          catch (_: Exception) { subtitleError = true }
        finally { subtitleLoading = false }
    }

    // Language preference applies once per title, never re-enables subtitles after the
    // viewer explicitly turns them off. Only tracks supplied by the provider are used.
    LaunchedEffect(video.id, subtitleOptions, subtitleLoading) {
        if (!initialSubtitlePreferenceApplied && !subtitleLoading) {
            initialSubtitlePreferenceApplied = true
            val preferred = prefs.preferredSubtitleLanguage
            if (preferred == "off") selectedSubs = null
            else if (preferred == "ar" || preferred == "en") {
                selectedSubs = preferredSubtitleLabel(preferred, subtitleOptions.map { it.label })
            }
        }
    }

    // Keep stream choice and saved position stable when switching episodes or qualities.
    // An adjustable cue timeline is available for external SRT/WebVTT subtitle files.
    // Native text tracks (including ASS/SSA) retain Media3's original rendering when no
    // adjusted timeline is active, preserving embedded graphics and styling.
    LaunchedEffect(video.id, selectedSubs, subtitleOptions, subDelay != 0L) {
        timedSubs = null
        syncNote = null
        val chosen = subtitleOptions.firstOrNull { it.label == selectedSubs }
        if (subDelay == 0L || chosen == null) return@LaunchedEffect
        if (!chosen.url.startsWith("https://") && !chosen.url.startsWith("http://")) {
            syncNote = "Subtitle URL is not downloadable."
            return@LaunchedEffect
        }
        if (chosen.mime != "text/vtt" && chosen.mime != "application/x-subrip") {
            syncNote = "Sync is available for external SRT/VTT tracks only."
            return@LaunchedEffect
        }
        try {
            val parsed = withContext(Dispatchers.IO) {
                val connection = URL(chosen.url).openConnection().apply {
                    connectTimeout = 10_000
                    readTimeout = 10_000
                    setRequestProperty("User-Agent", userAgent())
                }
                val bytes = connection.getInputStream().use { stream ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    while (true) {
                        val count = stream.read(buffer)
                        if (count <= 0) break
                        if (output.size() + count > 4_000_000) throw java.io.IOException("Subtitle file exceeds size limit")
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                parseTimedSubtitles(String(bytes, Charsets.UTF_8))
            }
            if (parsed.isNotEmpty()) timedSubs = parsed
            else syncNote = "Could not read timed captions; original track is unchanged."
        } catch (cancel: CancellationException) { throw cancel }
          catch (_: Exception) { syncNote = "Subtitle sync unavailable for this file; original track is unchanged." }
    }

    LaunchedEffect(video.id, reload) {
        sources = null
        fetchError = null
        playbackError = null
        finished = false
        tracks = Tracks.EMPTY
        buffering = true
        val downloaded = Downloads.local(context, video.id)
        val offline = Downloads.offlineMedia(context, video.id)
        // A fresh, single-use result from the Detail screen / previous episode makes Play instant.
        // Retries (reload > 0) always fetch brand-new URLs.
        val warm = if (downloaded == null && offline == null && reload == 0) Services.repo.takePrefetched(video.id) else null
        val result: PlaySources = warm ?: try {
            if (downloaded != null) {
                PlaySources(listOf(QualityOption(0, Uri.fromFile(downloaded).toString(), "Downloaded")), emptyList())
            } else if (offline != null) {
                PlaySources(listOf(QualityOption(0, "offline://${video.id}", "Downloaded")), emptyList())
            } else Services.repo.loadSources(video.id)
        } catch (cancel: CancellationException) { throw cancel }
          catch (error: Exception) {
              fetchError = NetworkResilience.diagnose(context, error).message
              buffering = false
              return@LaunchedEffect
          }
        if (result.qualities.isEmpty()) {
            fetchError = "No playable streams were returned for this title."
            buffering = false
            return@LaunchedEffect
        }
        retries = 0
        val choices = result.qualities.map { SmartQuality.Option(it.height, it.adaptive) }
        // Auto and Preferred are intentionally different: bandwidth should not
        // silently override the resolution chosen in Settings.
        autoIndex = SmartQuality.choose(
            choices, engine.bandwidthMbps(), Capabilities.autoHeight(context)
        ).coerceAtLeast(0)
        val preferredIndex = if (preferredActive)
            SmartQuality.preferredIndex(choices, prefs.maxQuality) else -1
        // A hand-picked in-player quality survives a retry. Otherwise honor the
        // global preference before considering connection-speed auto selection.
        qualityIndex = when {
            qualityLocked && qualityIndex in result.qualities.indices -> qualityIndex
            preferredIndex >= 0 -> preferredIndex
            else -> autoIndex
        }
        sources = result
    }
    LaunchedEffect(video.id, sources, qualityIndex, preferredActive, qualityLocked) {
        val stream = sources?.qualities?.getOrNull(qualityIndex) ?: return@LaunchedEffect
        val sameTitle = player.currentMediaItem?.mediaId == video.id
        val startingPosition = if (pendingRestore >= 0L) pendingRestore
            else if (sameTitle) player.currentPosition
            else prefs.resume(video.id).takeIf { it > 10_000L } ?: 0L
        val autoPlay = if (sameTitle) player.playWhenReady else true
        finished = false
        fetchError = null
        playbackError = null
        buffering = true
        bufferGate[0] = SystemClock.elapsedRealtime()
        engine.open(video.id, stream, subtitleOptions, startingPosition, autoPlay, trackHeightCap(stream))
        pendingRestore = -1L
        player.setPlaybackSpeed(playbackSpeed)
    }
    // Attaching an external subtitle after playback began may require a one-time media
    // item refresh; it happens ONLY when the viewer selects that track, not on metadata arrival.
    LaunchedEffect(video.id, selectedSubs, subtitleOptions, sources, qualityIndex) {
        val wanted = selectedSubs?.takeIf { label -> subtitleOptions.any { it.label == label } }
        if (wanted != null && player.currentMediaItem?.mediaId == video.id &&
            player.currentMediaItem?.localConfiguration?.subtitleConfigurations.orEmpty().none { it.label == wanted }) {
            val current = sources?.qualities?.getOrNull(qualityIndex)
            if (current != null) {
                val at = player.currentPosition.coerceAtLeast(0L)
                val shouldPlay = player.playWhenReady
                engine.open(video.id, current, subtitleOptions, at, shouldPlay, trackHeightCap(current))
            }
        }
    }
    LaunchedEffect(tracks, selectedSubs, timedSubs) {
        engine.subtitles(tracks, if (timedSubs == null) selectedSubs else null)
    }
    LaunchedEffect(tracks, selectedAudio) { engine.audio(tracks, selectedAudio) }
    // Temporary decoder/network failures get bounded re-prepare attempts before
    // lowering bitrate. Access-denied responses do not loop through every quality.
    LaunchedEffect(playbackError, video.id) {
        val failed = playbackError ?: return@LaunchedEffect
        // Do not clear the effect's key before delay: that would cancel retries.
        val issue = NetworkResilience.diagnose(context, failed)
        when {
            issue.type == FailureType.OFFLINE -> {
                fetchError = issue.message
                controlsVisible = true
                buffering = false
                playbackError = null
            }
            issue.recoverable && retries < 2 -> {
                retries++
                hint = "Connection interrupted · retry $retries/2"
                delay(if (retries == 1) 850L else 1_900L)
                engine.retry()
                playbackError = null
            }
            issue.recoverable && !qualityLocked && qualityIndex < (sources?.qualities?.lastIndex ?: -1) -> {
                retries = 0
                qualityIndex++
                hint = "Connection slow · trying a smaller stream"
                playbackError = null
            }
            else -> {
                buffering = false
                fetchError = issue.message
                controlsVisible = true
                playbackError = null
            }
        }
    }
    // A new network (for example Wi-Fi -> phone hotspot) can invalidate signed
    // media URLs and existing TCP connections. Fetch fresh URLs after an actual
    // route change if the player was stuck; never try to bypass an ISP refusal.
    LaunchedEffect(context, video.id) {
        NetworkResilience.watch(context.applicationContext).collect { next ->
            val previous = lastLink
            lastLink = next
            if (previous == next) return@collect
            if (!next.connected) {
                hint = "Network disconnected"
            } else if (previous.routeId != next.routeId && (fetchError != null || player.playerError != null)) {
                fetchError = null
                playbackError = null
                retries = 0
                hint = "Connection restored · refreshing stream"
                pendingRestore = player.currentPosition.coerceAtLeast(0L)
                player.stop()
                reload++
            }
        }
    }
    // Watchdog for a connection that buffers indefinitely without throwing an exception.
    // Recover at most three times per title. Manual pause/offline/provider denial never loops.
    LaunchedEffect(video.id, reload, sources, lastLink.connected) {
        while (true) {
            delay(2_000L)
            if (!lastLink.connected || sources == null || fetchError != null || finished ||
                !player.playWhenReady || player.currentMediaItem?.mediaId != video.id ||
                player.playbackState != Player.STATE_BUFFERING) continue
            if (SystemClock.elapsedRealtime() - bufferGate[0] < 15_000L) continue
            if (recoveryCount >= 3) {
                fetchError = "This stream keeps stalling. Try another quality or check the connection."
                controlsVisible = true
                continue
            }
            recoveryCount++
            bufferGate[0] = SystemClock.elapsedRealtime()
            when (recoveryCount) {
                1 -> { hint = "Playback stalled · reconnecting"; engine.retry() }
                2 -> {
                    pendingRestore = player.currentPosition.coerceAtLeast(0L)
                    hint = "Refreshing expired stream link"
                    reload++
                }
                else -> {
                    val lower = qualityIndex + 1
                    if (!qualityLocked && lower <= (sources?.qualities?.lastIndex ?: -1)) {
                        pendingRestore = player.currentPosition.coerceAtLeast(0L)
                        qualityIndex = lower
                        hint = "Using lower quality for a stable stream"
                    } else {
                        fetchError = "Stream stalled repeatedly. Try a different quality."
                        controlsVisible = true
                    }
                }
            }
        }
    }
    // Automatic quality for separate MP4 encodes. HLS/DASH uses Media3's own ABR.
    // Apply hysteresis and move one rung per evaluation to avoid repeated rebuffering.
    LaunchedEffect(video.id, sources, qualityLocked, preferredActive, playing) {
        if (qualityLocked || preferredActive || !playing) return@LaunchedEffect
        while (true) {
            delay(12_000L)
            val choices = sources?.qualities ?: continue
            val playingSource = choices.getOrNull(qualityIndex) ?: continue
            if (playingSource.adaptive || choices.size < 2 || !player.isPlaying ||
                player.currentMediaItem?.mediaId != video.id) continue
            val cap = prefs.maxQuality.takeIf { it > 0 } ?: Capabilities.autoHeight(context)
            val best = SmartQuality.choose(choices.map {
                SmartQuality.Option(it.height, it.adaptive)
            }, engine.bandwidthMbps(), cap)
            val now = SystemClock.elapsedRealtime()
            if (best == qualityIndex || best < 0) continue
            // Lower quality quickly on a weak connection; require a sustained good link
            // before upgrading a progressive source (changing encodes causes a reopen).
            val lowering = choices[best].height < playingSource.height
            val gap = if (lowering) 22_000L else 75_000L
            if (now - lastQualityShift[0] < gap || player.playbackState != Player.STATE_READY) continue
            val target = SmartQuality.nextIndex(qualityIndex, best, choices.map {
                SmartQuality.Option(it.height, it.adaptive)
            })
            if (target == qualityIndex) continue
            lastQualityShift[0] = now
            pendingRestore = player.currentPosition.coerceAtLeast(0L)
            autoIndex = target
            qualityIndex = target
            hint = if (lowering) "Auto quality · stabilizing" else "Auto quality · improving"
        }
    }

    LaunchedEffect(finished, automaticNext, video.id, episodesSinceBreak) {
        if (!finished || !automaticNext || index >= queue.lastIndex ||
            (prefs.bingeCheckEnabled && episodesSinceBreak >= 3)) return@LaunchedEffect
        for (i in 8 downTo 1) { countdown = i; delay(1_000L) }
        jumpTo(index + 1)
    }
    LaunchedEffect(player) {
        while (true) {
            if (seekPreview == null) {
                // Whole-second text need not recompose 3x/sec; smooth media frames
                // are rendered independently by the Android video surface.
                position = (player.currentPosition.coerceAtLeast(0L) / 500L) * 500L
            }
            duration = player.duration.coerceAtLeast(0L)
            buffered = player.bufferedPosition.coerceAtLeast(0L)
            // Derived here (not in the UI body) so the "Up next" card doesn't make the whole
            // player recompose on every tick while the controls are hidden.
            val remaining = duration - player.currentPosition
            val near = duration > 0L && remaining in 1L..45_000L
            if (nearEnd != near) nearEnd = near
            delay(if (controlsVisible && sheet == null) 500L else 1_000L)
        }
    }
    // Scene skipping requires exact start/end markers. Unmarked videos play unchanged.
    // This is a separate lightweight loop so skips still happen with controls hidden.
    val effectiveSceneRanges = remember(sceneRanges, externalMarkers) {
        SceneSkipping.normalize(sceneRanges + externalMarkers.filter { it.kind == "mature" }.map {
            SceneRange(it.startMs, it.endMs)
        })
    }
    LaunchedEffect(player, video.id, skipMarkedScenes, effectiveSceneRanges) {
        if (!skipMarkedScenes || effectiveSceneRanges.isEmpty()) return@LaunchedEffect
        while (true) {
            // Avoid 12.5 wake-ups/s throughout a whole movie. Poll quickly only
            // when approaching an actual scene; retain exact seeking and Undo.
            delay(SceneSkipping.pollDelayMs(player.currentPosition, player.isPlaying,
                effectiveSceneRanges, exemptScenes))
            if (!player.isPlaying || !player.isCurrentMediaItemSeekable ||
                player.currentMediaItem?.mediaId != video.id) continue
            val now = player.currentPosition
            val length = player.duration.coerceAtLeast(0L)
            val range = SceneSkipping.activeRange(now, effectiveSceneRanges, length)
            if (range == null || range in exemptScenes) continue
            val to = SceneSkipping.skipTarget(now, effectiveSceneRanges, length) ?: continue
            undoInfo = UndoInfo((range.startMs - 500L).coerceAtLeast(0L), range)
            Log.d("MatureSkip", "skipping title=${video.id} fromMs=$now toMs=$to range=${range.startMs}-${range.endMs}")
            engine.seekExact(to) // exact, so we can't land back inside the scene on an earlier keyframe
            position = to
            hint = "Skipped marked scene · press ◀ to undo"
        }
    }
    // Undo is offered for a short while after any skip.
    LaunchedEffect(undoInfo) {
        if (undoInfo != null) { delay(18_000L); undoInfo = null }
    }

    // Intro / recap / credits. Provider and community markers share one planner; the offer is
    // computed here (not during composition) so the remote handler and the button always agree.
    val skipMarkers = remember(introWindow, externalMarkers) {
        ExternalSceneMarkers.merge(
            listOfNotNull(SkipPlanner.fromProvider(introWindow)),
            externalMarkers.filter { it.kind != "mature" }
        )
    }
    val currentPerformSkip by rememberUpdatedState(newValue = { offer: SkipOffer -> performSkip(offer) })
    LaunchedEffect(player, video.id, skipMarkers) {
        if (skipMarkers.isEmpty()) { skipOffer = null; return@LaunchedEffect }
        while (true) {
            val length = player.duration
            val now = player.currentPosition
            val usable = player.currentMediaItem?.mediaId == video.id && length > 0L &&
                player.isCurrentMediaItemSeekable
            val next = if (usable) SkipPlanner.offer(now, length, skipMarkers) else null
            if (skipOffer != next) skipOffer = next
            if (next != null && player.isPlaying && prefs.autoSkipIntro &&
                SkipPlanner.shouldAutoSkip(next, now, handledSkips)) {
                currentPerformSkip(next)
            }
            delay(if (next != null) 250L else 500L)
        }
    }
    // With the controls up, put remote focus on the offered button so OK works immediately.
    LaunchedEffect(skipOffer?.key, controlsVisible, sheet) {
        if (skipOffer != null && controlsVisible && sheet == null && !finished && fetchError == null) {
            delay(130L) // after the generic focus effect below has settled
            runCatching { skipRequester.requestFocus() }
        }
    }
    LaunchedEffect(player, video.id) {
        while (true) {
            delay(20_000L)
            if (player.isPlaying) saveProgress()
        }
    }
    LaunchedEffect(video.id) {
        app.cinemanatv.util.PerformanceMetrics.playbackRequested(video.id)
        prefs.addHistory(video)
    }
    // Resolve the next episode's streams shortly before this one ends so the hand-over is instant.
    LaunchedEffect(video.id, index) {
        val next = queue.getOrNull(index + 1) ?: return@LaunchedEffect
        while (true) {
            delay(5_000L)
            val length = player.duration
            if (length > 0L && length - player.currentPosition < 150_000L) break
        }
        if (Downloads.local(context, next.id) != null || Downloads.offlineMedia(context, next.id) != null) return@LaunchedEffect
        Services.repo.prefetchSources(next.id)
        val nextSources = Services.repo.peekPrefetched(next.id) ?: return@LaunchedEffect
        val choices = nextSources.qualities.map { SmartQuality.Option(it.height, it.adaptive) }
        val choiceIndex = if (prefs.maxQuality > 0)
            SmartQuality.preferredIndex(choices, prefs.maxQuality)
        else SmartQuality.choose(choices, engine.bandwidthMbps(), Capabilities.autoHeight(context))
        val nextStream = nextSources.qualities.getOrNull(choiceIndex) ?: return@LaunchedEffect
        // Progressive HTTP video: prebuffer a bounded 512 KB into the SAME cache that
        // the player reads. HLS/DASH get stream URL prefetch, not segment prebuffering.
        kotlinx.coroutines.withTimeoutOrNull(9_000L) {
            NextEpisodePreloader.warm(context.applicationContext, nextStream)
        }
    }
    // A delayed indicator prevents a short buffer transition from flashing an
    // opaque loading card across the film.
    LaunchedEffect(buffering, fetchError, finished) {
        if (buffering && fetchError == null && !finished) {
            delay(350L)
            showBuffering = true
        } else {
            showBuffering = false
        }
    }
    LaunchedEffect(hint) { if (hint != null) { delay(1_200L); hint = null } }
    LaunchedEffect(controlsVisible, sheet, playing, timelineFocused, interactionTick, finished) {
        if (controlsVisible && sheet == null && playing && !timelineFocused && !finished) {
            delay(5_800L)
            controlsVisible = false
        }
    }
    LaunchedEffect(controlsVisible, sheet, fetchError, finished, video.id) {
        // Let the incoming sheet/control compose and attach before focusing it.
        delay(70L)
        runCatching {
            when {
                sheet != null -> sheetRequester.requestFocus()
                finished -> endRequester.requestFocus()
                fetchError != null || controlsVisible -> primaryRequester.requestFocus()
                else -> rootRequester.requestFocus()
            }
        }
    }
    // Bind the player's CURRENT Back behavior to the Activity-level dispatcher.
    // rememberUpdatedState means this callback always sees the latest sheet,
    // playback position and exit action without registering a second handler.
    val currentPlayerBack by rememberUpdatedState(newValue = { goBack() })
    DisposableEffect(Unit) {
        onRegisterBack { currentPlayerBack() }
        onDispose { onRegisterBack(null) }
    }

    val currentQuality = sources?.qualities?.getOrNull(qualityIndex)?.label
    // Explain whether the source is selected automatically or by global preference.
    val sourceLabel: String = when {
        currentQuality == null -> "Auto"
        qualityLocked || currentQuality == "Downloaded" -> currentQuality
        preferredActive && currentQuality == "Auto" ->
            "${t("Preferred")} · ${prefs.maxQuality}p ${t("maximum")}" // adaptive playlist
        preferredActive -> "${t("Preferred")} · $currentQuality"
        else -> "Auto · $currentQuality"
    }
    val subSizeName = when {
        subScale <= 0.85f -> "Small"
        subScale < 1.15f -> "Medium"
        subScale < 1.45f -> "Large"
        else -> "Extra large"
    }
    val kindLabel = if (queue.size > 1 || video.episodeNummer != null)
        "Season ${video.seasonNumber} · Episode ${video.episodeNumber}" else "Now playing"

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(rootRequester).focusable()
            // Touch / mouse: tap shows or hides the controls; double-tap the left or right
            // third to skip 10s, the middle to play or pause. D-pad users never hit this path.
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        if (sheet == null && fetchError == null && !finished) {
                            if (controlsVisible) hideControls() else reveal()
                        }
                    },
                    onDoubleTap = { offset ->
                        if (sheet == null && fetchError == null && !finished) {
                            val third = size.width / 3f
                            when {
                                offset.x < third -> seekBy(-10_000L)
                                offset.x > size.width - third -> seekBy(10_000L)
                                else -> togglePlayback()
                            }
                        }
                    }
                )
            }
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val code = e.nativeKeyEvent.keyCode
                when {
                    code == AndroidKeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlayback(); true }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_PLAY -> { player.play(); reveal(); true }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_PAUSE -> { player.pause(); reveal(); true }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_REWIND -> {
                        scrubBy(-10_000L, e.nativeKeyEvent.repeatCount); true
                    }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                        scrubBy(10_000L, e.nativeKeyEvent.repeatCount); true
                    }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_NEXT || code == AndroidKeyEvent.KEYCODE_CHANNEL_UP -> {
                        jumpTo(index + 1); true
                    }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_PREVIOUS || code == AndroidKeyEvent.KEYCODE_CHANNEL_DOWN -> {
                        jumpTo(index - 1); true
                    }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_SKIP_FORWARD -> {
                        scrubBy(10_000L, e.nativeKeyEvent.repeatCount); true
                    }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_SKIP_BACKWARD -> {
                        scrubBy(-10_000L, e.nativeKeyEvent.repeatCount); true
                    }
                    code == AndroidKeyEvent.KEYCODE_MEDIA_STOP -> { saveProgress(); onExit(); true }
                    code == AndroidKeyEvent.KEYCODE_MENU || code == AndroidKeyEvent.KEYCODE_SETTINGS -> {
                        sheet = if (sheet == null) PlayerSheet.ROOT else null; reveal(); true
                    }
                    code == AndroidKeyEvent.KEYCODE_INFO -> { sheet = PlayerSheet.DETAILS; reveal(); true }
                    code == AndroidKeyEvent.KEYCODE_CAPTIONS -> { sheet = PlayerSheet.SUBTITLES; reveal(); true }
                    // A skip offer owns OK while the controls are hidden (as on other TV players);
                    // the play/pause media key still pauses.
                    sheet == null && !controlsVisible && fetchError == null && !finished && skipOffer != null &&
                        (e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter) -> {
                        skipOffer?.let { performSkip(it) }; true
                    }
                    // Right after a skip, Left means "take me back" instead of a 10 s rewind.
                    sheet == null && !controlsVisible && undoInfo != null && e.key == Key.DirectionLeft -> {
                        undoSkip(); true
                    }
                    sheet == null && !controlsVisible && (e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter) -> {
                        togglePlayback(); true
                    }
                    sheet == null && !controlsVisible && e.key == Key.DirectionLeft -> {
                        scrubBy(-10_000L, e.nativeKeyEvent.repeatCount); true
                    }
                    sheet == null && !controlsVisible && e.key == Key.DirectionRight -> {
                        scrubBy(10_000L, e.nativeKeyEvent.repeatCount); true
                    }
                    sheet == null && !controlsVisible && (e.key == Key.DirectionUp || e.key == Key.DirectionDown) -> {
                        reveal(); true
                    }
                    else -> false // Let TV Surface focus navigation handle every visible control.
                }
            }
    ) {
        // Kept in its own composable: progress/clock updates never need to
        // re-run AndroidView's update callback or reconfigure the decoder.
        val manualCues = timedSubs?.let { cues ->
            activeCaptions(cues, position, subDelay).map { caption ->
                Cue.Builder().setText(caption.text).build()
            }
        }
        CinemaVideoSurface(player, aspect, subScale, manualCues, subStyle, subPlacement)

        if (showBuffering && buffering && fetchError == null && !finished) {
            Column(
                Modifier.align(Alignment.Center).clip(RoundedCornerShape(22.dp))
                    .background(Color(0xD9111520)).padding(horizontal = 34.dp, vertical = 27.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                CinemaSpinner()
                Text(t(if (sources == null) "Finding the best stream" else "Preparing your picture"), color = Color.White,
                    fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(sourceLabel, color = Muted, fontSize = 12.sp)
            }
        }

        if (fetchError != null) {
            Column(
                Modifier.align(Alignment.Center).widthIn(max = 550.dp)
                    .clip(RoundedCornerShape(24.dp)).background(Glass).padding(30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(t("Playback unavailable"), fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(fetchError.orEmpty(), color = Muted, fontSize = 15.sp)
                Text(t("Connection: ${lastLink.type}"), color = Accent, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PlayerTile("Try again", "↻", Modifier.focusRequester(primaryRequester), primary = true) {
                        fetchError = null; playbackError = null; player.stop(); retries = 0; reload++; reveal()
                    }
                    if (sources?.qualities?.getOrNull(qualityIndex)?.url?.let { it.startsWith("https://") || it.startsWith("http://") } == true) {
                        PlayerTile("Other player", "↗", onClick = { openExternalPlayer() })
                    }
                    PlayerTile("Exit player", "‹", onClick = { saveProgress(); onExit() })
                }
            }
        }

        AnimatedVisibility(
            visible = hint != null && fetchError == null && !finished,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 151.dp),
            enter = fadeIn(tween(90)), exit = fadeOut(tween(130))
        ) {
            Text(hint.orEmpty(),
                Modifier.clip(RoundedCornerShape(50.dp))
                    .background(Color(0xE9112119))
                    .border(1.dp, Color(0x8859B777), RoundedCornerShape(50.dp))
                    .padding(horizontal = 21.dp, vertical = 10.dp),
                fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        }

        // Clean Night-style playback HUD: video remains unobstructed until controls are requested.
        // Unlike phone-only players, each visible action is a real TV focus target.
        AnimatedVisibility(
            visible = (controlsVisible || finished) && fetchError == null,
            enter = fadeIn(tween(110)), exit = fadeOut(tween(150)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0f to Color(0xA5000000),
                        0.22f to Color.Transparent,
                        0.53f to Color.Transparent,
                        1f to Color(0xE9000907)
                    )
                )
            ) {
                Row(
                    Modifier.fillMaxWidth().align(Alignment.TopCenter)
                        .padding(start = 46.dp, end = 46.dp, top = 26.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(t(kindLabel), fontSize = 11.sp, color = Accent, fontWeight = FontWeight.Medium)
                        Text(video.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        PlayerPill(sourceLabel)
                        if (skipMarkedScenes && effectiveSceneRanges.isNotEmpty())
                            PlayerPill("✂ ${effectiveSceneRanges.size}")
                        if (playbackSpeed != 1f) PlayerPill("${playbackSpeed}×")
                    }
                }

                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .padding(start = 46.dp, end = 46.dp, bottom = 26.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(playClock(position), fontSize = 12.sp, color = Color.White,
                            fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        val remaining = (duration - position).coerceAtLeast(0L)
                        val endsAt = if (duration > 0L) clock.format(java.util.Date(
                            System.currentTimeMillis() + (remaining / playbackSpeed).toLong())) else ""
                        Text(if (duration > 0L) "−${playClock(remaining)}   ·   " +
                            (if (LocalInterfaceLanguage.current == "ar") "ينتهي $endsAt" else "ends $endsAt")
                            else "--:--",
                            fontSize = 12.sp, color = Muted)
                    }
                    CinemaTimeline(
                        progress = if (duration > 0) position.toFloat() / duration else 0f,
                        buffered = if (duration > 0) buffered.toFloat() / duration else 0f,
                        seekable = duration > 0 && player.isCurrentMediaItemSeekable,
                        instant = seekPreview != null,
                        requester = timelineRequester,
                        onFocus = { timelineFocused = it; if (it) reveal() },
                        onStep = { delta, repeats -> scrubBy(delta, repeats) },
                        onUp = { hideControls() },
                        onJump = { fraction ->
                            if (duration > 0) {
                                seekCommit[0]?.cancel()
                                seekPreview = null
                                player.seekTo((duration * fraction).toLong().coerceIn(0L, duration))
                                reveal()
                            }
                        }
                    )
                    Box(Modifier.fillMaxWidth().height(84.dp)) {
                        Text(
                            t("◀ ▶  Seek     •     OK  Select"),
                            modifier = Modifier.align(Alignment.CenterStart),
                            color = Color(0xFF82948A), fontSize = 11.sp
                        )
                        Row(Modifier.align(Alignment.Center),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                            if (index > 0) {
                                NightControl("Previous episode", NightGlyph.PREVIOUS, onFocused = { reveal() }) { jumpTo(index - 1) }
                            }
                            NightControl("Back 10 seconds", NightGlyph.REWIND, onFocused = { reveal() }) { seekBy(-10_000L) }
                            NightControl(if (playing) "Pause" else "Play", if (playing) NightGlyph.PAUSE else NightGlyph.PLAY,
                                modifier = Modifier.focusRequester(primaryRequester), primary = true, onFocused = { reveal() }) {
                                togglePlayback()
                            }
                            NightControl("Forward 10 seconds", NightGlyph.FORWARD, onFocused = { reveal() }) { seekBy(10_000L) }
                            if (index < queue.lastIndex) {
                                NightControl("Next episode", NightGlyph.NEXT, onFocused = { reveal() }) { jumpTo(index + 1) }
                            }
                        }
                        Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            NightControl("Subtitles", NightGlyph.CAPTIONS, onFocused = { reveal() }) {
                                sheet = PlayerSheet.SUBTITLES; reveal()
                            }
                            NightControl("Player settings", NightGlyph.SETTINGS, onFocused = { reveal() }) {
                                sheet = PlayerSheet.ROOT; reveal()
                            }
                        }
                    }
                }
            }
        }

        // Skip / undo / up-next live in one stack so they can never overlap each other or the
        // controls. Bottom-right, like other TV players; it rides above the HUD when that is up.
        val offer = skipOffer
        val undo = undoInfo
        val hasNext = index < queue.lastIndex
        val showUpNext = hasNext && !nextPromptDismissed && nearEnd
        if (!finished && fetchError == null && sheet == null && (offer != null || undo != null || showUpNext)) {
            Column(
                Modifier.align(Alignment.BottomEnd)
                    .padding(end = 40.dp, bottom = if (controlsVisible) 178.dp else 52.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (undo != null) {
                    SkipChip("Undo skip", hint = if (controlsVisible) null else "◀", primary = false,
                        onClick = { undoSkip(); reveal() })
                }
                if (offer != null) {
                    val label = when (offer.kind) {
                        "recap" -> "Skip Recap"
                        "outro" -> if (offer.toEnd && hasNext) "Next Episode" else "Skip Credits"
                        "preview" -> "Skip Preview"
                        else -> "Skip Intro"
                    }
                    SkipChip(label, hint = if (controlsVisible) null else "OK", primary = true,
                        modifier = Modifier.focusRequester(skipRequester),
                        onClick = { performSkip(offer) })
                }
                // The next-episode card yields to a "Next Episode" credits button (same action).
                if (showUpNext && !(offer != null && offer.toEnd)) {
                    Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Glass)
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(t("Up next"), color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp)
                        Text(queue[index + 1].title, color = Color.White, fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 280.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppButton("Next episode", primary = true) { jumpTo(index + 1) }
                            AppButton("Dismiss") { nextPromptDismissed = true }
                        }
                    }
                }
            }
        }

        if (finished && fetchError == null) {
            Column(
                Modifier.align(Alignment.Center).width(400.dp)
                    .clip(RoundedCornerShape(24.dp)).background(Color(0xF2101E17))
                    .border(1.dp, Color(0xFF365941), RoundedCornerShape(24.dp))
                    .padding(25.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Text(t(if (index < queue.lastIndex && prefs.bingeCheckEnabled && episodesSinceBreak >= 3)
                    "Still watching?" else if (index < queue.lastIndex) "UP NEXT" else "THE END"), color = Accent,
                    fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(t(if (index < queue.lastIndex) queue[index + 1].title else "Thanks for watching"),
                    fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                if (index < queue.lastIndex) {
                    Text(t(if (prefs.bingeCheckEnabled && episodesSinceBreak >= 3) "Auto-play paused until you confirm"
                        else if (automaticNext) "Starting in ${countdown}s" else "Auto-play cancelled"),
                        color = Muted, fontSize = 14.sp)
                    PlayerTile("Play next episode", "▶", Modifier.focusRequester(endRequester), primary = true, onClick = {
                        if (prefs.bingeCheckEnabled && episodesSinceBreak >= 3) episodesSinceBreak = 0
                        jumpTo(index + 1)
                    })
                    PlayerTile("Stay here", "×", onClick = { automaticNext = false })
                } else {
                    PlayerTile("Watch again", "↻", Modifier.focusRequester(endRequester), primary = true, onClick = {
                        finished = false; player.seekTo(0L); player.play(); reveal()
                    })
                    PlayerTile("Back to browsing", "‹", onClick = { saveProgress(); onExit() })
                }
            }
        }

        AnimatedVisibility(
            visible = sheet != null, modifier = Modifier.align(Alignment.CenterEnd),
            enter = fadeIn(tween(100)) + slideInHorizontally(tween(150)) { it / 4 },
            exit = fadeOut(tween(100)) + slideOutHorizontally(tween(140)) { it / 4 }
        ) {
            val currentSheet = sheet
            if (currentSheet != null) {
                Box(Modifier.fillMaxSize().background(Color(0x80000000))) {
                    Column(
                        Modifier.align(Alignment.CenterEnd).width(376.dp).fillMaxHeight()
                            .background(Brush.verticalGradient(listOf(Color(0xF515211C), Ink)))
                            .border(width = 1.dp, color = Color(0xFF314A39))
                            .padding(start = 25.dp, end = 26.dp, top = 35.dp, bottom = 28.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(Accent))
                            Column {
                                Text(t("PLAYER"), color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp)
                                Text(t(when (currentSheet) {
                                    PlayerSheet.ROOT -> "Settings"
                                    PlayerSheet.QUALITY -> "Video quality"
                                    PlayerSheet.SUBTITLES -> "Subtitles"
                                    PlayerSheet.SUBSIZE -> "Subtitle size"
                                    PlayerSheet.SUBSYNC -> "Subtitle sync"
                                    PlayerSheet.SUBSTYLE -> "Subtitle appearance"
                                    PlayerSheet.SUBPOSITION -> "Subtitle position"
                                    PlayerSheet.AUDIO -> "Audio tracks"
                                    PlayerSheet.SPEED -> "Playback speed"
                                    PlayerSheet.ASPECT -> "Picture size"
                                    PlayerSheet.DETAILS -> "Stream information"
                                }), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF243A30)))
                        Column(
                            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            when (currentSheet) {
                                PlayerSheet.ROOT -> {
                                    PlayerOption("Video quality", sourceLabel, "▣", Modifier.focusRequester(sheetRequester)) { sheet = PlayerSheet.QUALITY }
                                    PlayerOption("Subtitles", selectedSubs ?: "Off", "CC") { sheet = PlayerSheet.SUBTITLES }
                                    PlayerOption("Subtitle size", subSizeName, "Aa") { sheet = PlayerSheet.SUBSIZE }
                                    PlayerOption("Subtitle sync", if (subDelay == 0L) "0.0s" else String.format(Locale.US, "%+.1fs", subDelay / 1000.0), "↔") { sheet = PlayerSheet.SUBSYNC }
                                    PlayerOption("Subtitle appearance", listOf("White outline", "Yellow", "Black background")[subStyle], "Aa") { sheet = PlayerSheet.SUBSTYLE }
                                    PlayerOption("Subtitle position", listOf("Low", "Normal", "High")[subPlacement], "↕") { sheet = PlayerSheet.SUBPOSITION }
                                    PlayerOption("Audio", selectedAudio ?: "Auto", "♫") { sheet = PlayerSheet.AUDIO }
                                    PlayerOption("Playback speed", "${playbackSpeed}×", "⏩") { sheet = PlayerSheet.SPEED }
                                    PlayerOption("Picture size", aspect.name.lowercase().replaceFirstChar { it.uppercase() }, "▱") { sheet = PlayerSheet.ASPECT }
                                    if (!skipMarkedScenes) {
                                        PlayerOption("Open in external player", "", "↗") { openExternalPlayer() }
                                    }
                                    PlayerOption("Technical details", "Codec & resolution", "ⓘ") { sheet = PlayerSheet.DETAILS }
                                }
                                PlayerSheet.QUALITY -> {
                                    PlayerOption("Auto", "Bandwidth-aware streaming", "▣",
                                        Modifier.focusRequester(sheetRequester),
                                        selected = !qualityLocked && !preferredActive) {
                                        qualityLocked = false
                                        preferredActive = false
                                        recentStalls.clear()
                                        val choices = sources?.qualities?.map {
                                            SmartQuality.Option(it.height, it.adaptive)
                                        }.orEmpty()
                                        autoIndex = SmartQuality.choose(
                                            choices, engine.bandwidthMbps(), Capabilities.autoHeight(context)
                                        ).coerceAtLeast(0)
                                        if (qualityIndex != autoIndex) qualityIndex = autoIndex
                                        sheet = null; reveal()
                                    }
                                    if (prefs.maxQuality > 0) {
                                        PlayerOption("${t("Preferred")} · ${prefs.maxQuality}p",
                                            "${t("From Settings")}", "▣",
                                            selected = !qualityLocked && preferredActive) {
                                            qualityLocked = false
                                            preferredActive = true
                                            recentStalls.clear()
                                            val choices = sources?.qualities?.map {
                                                SmartQuality.Option(it.height, it.adaptive)
                                            }.orEmpty()
                                            val pick = SmartQuality.preferredIndex(choices, prefs.maxQuality)
                                            if (pick >= 0) qualityIndex = pick
                                            sheet = null; reveal()
                                        }
                                    }
                                    sources?.qualities?.forEachIndexed { i, item ->
                                        PlayerOption(item.label, if (qualityLocked && i == qualityIndex) "Selected" else "", "▣",
                                            selected = qualityLocked && i == qualityIndex) {
                                            qualityLocked = true
                                            preferredActive = false
                                            qualityIndex = i; sheet = null; reveal()
                                        }
                                    }
                                }
                                PlayerSheet.SUBTITLES -> {
                                    PlayerOption("Off", "Disable captions", "CC", Modifier.focusRequester(sheetRequester), selectedSubs == null) {
                                        selectedSubs = null; prefs.subtitleLabel = ""; sheet = null
                                    }
                                    subtitleOptions.forEach { option ->
                                        PlayerOption(option.label, "Subtitle track", "CC", selected = selectedSubs == option.label) {
                                            selectedSubs = option.label; prefs.subtitleLabel = option.label; sheet = null
                                        }
                                    }
                                    if (subtitleOptions.isEmpty()) {
                                        Text(t(when {
                                            subtitleLoading -> "Looking for subtitles… video continues playing."
                                            subtitleError -> "Subtitle server unavailable. Retry below."
                                            else -> "No external subtitles were supplied for this stream."
                                        }), color = Muted, fontSize = 13.sp)
                                        if (subtitleError) PlayerOption("Retry subtitles", "Try fetching tracks again", "↻") {
                                            subtitleRetry++
                                        }
                                    }
                                }
                                PlayerSheet.SUBSIZE -> {
                                    listOf("Small" to 0.8f, "Medium" to 1f, "Large" to 1.3f, "Extra large" to 1.6f)
                                        .forEachIndexed { i, (name, scale) ->
                                            PlayerOption(name, if (scale == 1f) "Default" else "", "Aa",
                                                if (i == 0) Modifier.focusRequester(sheetRequester) else Modifier,
                                                selected = subScale == scale) {
                                                subScale = scale; prefs.subtitleScale = scale; sheet = null
                                            }
                                        }
                                }
                                PlayerSheet.SUBSYNC -> {
                                    Text(t("External SRT/VTT timing only; embedded and ASS/SSA tracks remain unchanged."),
                                        color = Muted, fontSize = 12.sp)
                                    PlayerOption("Earlier −0.5s", "Shift captions earlier", "−", Modifier.focusRequester(sheetRequester)) {
                                        subDelay = (subDelay - 500L).coerceAtLeast(-10_000L)
                                        prefs.subtitleDelayMs = subDelay
                                    }
                                    PlayerOption("Later +0.5s", "Shift captions later", "+") {
                                        subDelay = (subDelay + 500L).coerceAtMost(10_000L)
                                        prefs.subtitleDelayMs = subDelay
                                    }
                                    PlayerOption("Reset sync", String.format(Locale.US, "Current: %+.1fs", subDelay / 1000.0), "↻") {
                                        subDelay = 0L; prefs.subtitleDelayMs = 0L
                                    }
                                    if (syncNote != null) Text(t(syncNote!!), color = Muted, fontSize = 12.sp)
                                }
                                PlayerSheet.SUBSTYLE -> {
                                    listOf("White outline", "Yellow", "Black background").forEachIndexed { i, label ->
                                        PlayerOption(label, "", "Aa", if (i == 0) Modifier.focusRequester(sheetRequester) else Modifier,
                                            selected = subStyle == i) { subStyle = i; prefs.subtitleStyle = i }
                                    }
                                }
                                PlayerSheet.SUBPOSITION -> {
                                    listOf("Low", "Normal", "High").forEachIndexed { i, label ->
                                        PlayerOption(label, "", "↕", if (i == 0) Modifier.focusRequester(sheetRequester) else Modifier,
                                            selected = subPlacement == i) { subPlacement = i; prefs.subtitlePlacement = i }
                                    }
                                }
                                PlayerSheet.AUDIO -> {
                                    PlayerOption("Automatic", "Use original track", "♫", Modifier.focusRequester(sheetRequester), selectedAudio == null) {
                                        selectedAudio = null; sheet = null
                                    }
                                    val labels = tracks.groups.filter { it.type == MediaC.TRACK_TYPE_AUDIO }
                                        .flatMap { group -> (0 until group.length).map { i -> group.getTrackFormat(i).let {
                                            format -> format.label ?: format.language ?: "Audio ${i + 1}"
                                        } } }.distinct()
                                    labels.forEach { label ->
                                        PlayerOption(label, "Audio track", "♫", selected = selectedAudio == label) {
                                            selectedAudio = label; sheet = null
                                        }
                                    }
                                    if (labels.isEmpty()) Text(t("No alternative audio tracks detected."), color = Muted, fontSize = 13.sp)
                                }
                                PlayerSheet.SPEED -> {
                                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f).forEachIndexed { i, option ->
                                        PlayerOption("${option}×", if (option == 1f) "Normal" else "", "⏩",
                                            if (i == 0) Modifier.focusRequester(sheetRequester) else Modifier,
                                            selected = playbackSpeed == option) {
                                            playbackSpeed = option; player.setPlaybackSpeed(option); sheet = null
                                        }
                                    }
                                }
                                PlayerSheet.ASPECT -> {
                                    ScreenMode.entries.forEachIndexed { i, mode ->
                                        PlayerOption(when (mode) {
                                            ScreenMode.FIT -> "Original aspect ratio"
                                            ScreenMode.FILL -> "Fill the entire screen"
                                            ScreenMode.ZOOM -> "Zoom and crop edges"
                                        }, when (mode) {
                                            ScreenMode.FIT -> "No cropping"
                                            ScreenMode.FILL -> "May stretch picture"
                                            ScreenMode.ZOOM -> "Preserves proportions"
                                        }, "▱", if (i == 0) Modifier.focusRequester(sheetRequester) else Modifier,
                                            selected = aspect == mode) { aspect = mode; sheet = null }
                                    }
                                }
                                PlayerSheet.DETAILS -> {
                                    val format = player.videoFormat
                                    Column(Modifier.focusRequester(sheetRequester).focusable(), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                                        DetailLine("SOURCE", sourceLabel)
                                        DetailLine("VIDEO", if (format != null) "${format.width} × ${format.height}" else "Not available")
                                        DetailLine("CODEC", format?.sampleMimeType ?: "Unknown")
                                        DetailLine("BUFFER AHEAD", playClock((buffered - position).coerceAtLeast(0L)))
                                        val mbps = engine.bandwidthMbps()
                                        DetailLine("NETWORK SPEED", if (mbps > 0.0) String.format(Locale.US, "%.1f Mbit/s", mbps) else "Measuring…")
                                        DetailLine("DROPPED FRAMES", engine.droppedFrames().toString())
                                        DetailLine("PLAYBACK", "${playbackSpeed}×")
                                        Text(t("Resolution describes the decoded stream, not a claimed 4K mode."), color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                        PlayerOption(if (currentSheet == PlayerSheet.ROOT) "Close settings" else "Back to settings",
                            "BACK on your remote", "‹") {
                            sheet = if (currentSheet == PlayerSheet.ROOT) null else PlayerSheet.ROOT
                        }
                    }
                }
            }
        }
    }
}

/** Compose state for clocks and menus must not re-bind the underlying video surface. */
@Composable
private fun CinemaVideoSurface(
    player: Player, mode: ScreenMode, subtitleScale: Float,
    manualCues: List<Cue>?, style: Int, placement: Int,
) {
    val currentManual by rememberUpdatedState(manualCues)
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply {
            useController = false
            setKeepContentOnPlayerReset(true)
            this.player = player
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            subtitleView?.apply {
                // Retain simultaneous cues and original subtitle timing/positioning.
                setApplyEmbeddedStyles(true)
                // Readable on any scene: white text, dark outline, and a size the viewer controls
                // (never the tiny font sizes some subtitle files embed).
                setApplyEmbeddedFontSizes(false)
                setStyle(CaptionStyleCompat(
                    android.graphics.Color.WHITE,
                    android.graphics.Color.TRANSPARENT,
                    android.graphics.Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                    android.graphics.Color.BLACK,
                    null
                ))
                setBottomPaddingFraction(0.06f)
            }
            // PlayerView already dispatches the full CueGroup. Register after its
            // listener so unpositioned simultaneous cues can be stacked instead
            // of painted on top of one another; do not drop the other cues.
            val boundView = this
            val cueListener = object : Player.Listener {
                override fun onCues(cueGroup: CueGroup) {
                    if (currentManual == null) {
                        boundView.subtitleView?.setCues(layoutSimultaneousSubtitleCues(cueGroup.cues))
                    }
                }
            }
            player.addListener(cueListener)
            setTag(app.cinemanatv.R.id.cinemana_multi_cue_listener, cueListener)
            subtitleView?.setCues(layoutSimultaneousSubtitleCues(player.currentCues.cues))
        } },
        update = { view ->
            val resize = when (mode) {
                ScreenMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                ScreenMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                ScreenMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            }
            if (view.resizeMode != resize) view.resizeMode = resize
            view.subtitleView?.apply {
                setFractionalTextSize(0.0533f * subtitleScale)
                setBottomPaddingFraction(when (placement) { 0 -> 0.025f; 2 -> 0.18f; else -> 0.06f })
                setStyle(when (style) {
                    1 -> CaptionStyleCompat(android.graphics.Color.YELLOW,
                        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null)
                    2 -> CaptionStyleCompat(android.graphics.Color.WHITE,
                        android.graphics.Color.BLACK, android.graphics.Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_NONE, android.graphics.Color.BLACK, null)
                    else -> CaptionStyleCompat(android.graphics.Color.WHITE,
                        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null)
                })
                setCues(layoutSimultaneousSubtitleCues(manualCues ?: player.currentCues.cues))
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { view ->
            (view.getTag(app.cinemanatv.R.id.cinemana_multi_cue_listener) as? Player.Listener)
                ?.let { player.removeListener(it) }
            view.setTag(app.cinemanatv.R.id.cinemana_multi_cue_listener, null)
            // Do not leave the ExoPlayer attached to a disposed AndroidView.
            view.player = null
        }
    )
}

private enum class NightGlyph { PREVIOUS, REWIND, PLAY, PAUSE, FORWARD, NEXT, CAPTIONS, SETTINGS }

/** All icons are vector-drawn, so they render consistently without icon-font dependencies. */
@Composable
private fun NightControl(
    label: String,
    glyph: NightGlyph,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    onFocused: () -> Unit = {},
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val translatedLabel = t(label)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.width(if (primary) 76.dp else 56.dp)
    ) {
        Surface(
            onClick = onClick,
            modifier = modifier.size(if (primary) 62.dp else 46.dp)
                .onFocusChanged {
                    if (focused != it.isFocused) {
                        focused = it.isFocused
                        if (it.isFocused) onFocused()
                    }
                }
                .semantics { contentDescription = translatedLabel },
            shape = ClickableSurfaceDefaults.shape(CircleShape),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.055f),
            border = ClickableSurfaceDefaults.border(
                focusedBorder = Border(
                    androidx.compose.foundation.BorderStroke(2.dp, if (primary) Focus else Accent),
                    shape = CircleShape
                )
            ),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = if (primary) Accent else Color(0x1AFFFFFF),
                contentColor = if (primary) Ink else Color.White,
                focusedContainerColor = if (primary) Focus else Color(0xFF204A33),
                focusedContentColor = if (primary) Ink else Accent
            )
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                NightVector(glyph, color = if (primary) Ink else if (focused) Accent else Color.White)
            }
        }
        // Reserve stable height so focus changes never cause the controls to jump.
        val helper = when (glyph) {
            NightGlyph.REWIND -> "−10"
            NightGlyph.FORWARD -> "+10"
            NightGlyph.PREVIOUS -> if (focused) "Previous" else " "
            NightGlyph.NEXT -> if (focused) "Next" else " "
            NightGlyph.PLAY -> if (focused) "Play" else " "
            NightGlyph.PAUSE -> if (focused) "Pause" else " "
            NightGlyph.CAPTIONS -> if (focused) "Captions" else " "
            NightGlyph.SETTINGS -> if (focused) "Settings" else " "
        }
        Text(t(helper), maxLines = 1,
            modifier = Modifier.padding(top = 5.dp),
            fontSize = 9.sp, color = if (focused) Accent else Muted)
    }
}

@Composable
private fun NightVector(glyph: NightGlyph, color: Color) {
    if (glyph == NightGlyph.CAPTIONS) {
        Text(t("CC"), fontSize = 13.sp, color = color, fontWeight = FontWeight.Bold)
        return
    }
    Canvas(Modifier.size(if (glyph == NightGlyph.PLAY || glyph == NightGlyph.PAUSE) 27.dp else 23.dp)) {
        val w = size.width
        val h = size.height
        val line = 2.3.dp.toPx()
        fun triangle(right: Boolean, left: Float, top: Float, width: Float, height: Float) {
            val p = Path().apply {
                if (right) {
                    moveTo(left, top); lineTo(left + width, top + height / 2f)
                    lineTo(left, top + height)
                } else {
                    moveTo(left + width, top); lineTo(left, top + height / 2f)
                    lineTo(left + width, top + height)
                }
                close()
            }
            drawPath(p, color)
        }
        when (glyph) {
            NightGlyph.PLAY -> triangle(true, w * .32f, h * .18f, w * .44f, h * .64f)
            NightGlyph.PAUSE -> {
                drawRoundRect(color, topLeft = Offset(w * .27f, h * .2f),
                    size = Size(w * .16f, h * .6f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(line / 2))
                drawRoundRect(color, topLeft = Offset(w * .57f, h * .2f),
                    size = Size(w * .16f, h * .6f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(line / 2))
            }
            NightGlyph.PREVIOUS, NightGlyph.REWIND -> {
                triangle(false, w * .15f, h * .25f, w * .35f, h * .5f)
                triangle(false, w * .5f, h * .25f, w * .35f, h * .5f)
                if (glyph == NightGlyph.PREVIOUS)
                    drawLine(color, Offset(w * .1f, h * .18f), Offset(w * .1f, h * .82f), strokeWidth = line)
            }
            NightGlyph.NEXT, NightGlyph.FORWARD -> {
                triangle(true, w * .15f, h * .25f, w * .35f, h * .5f)
                triangle(true, w * .5f, h * .25f, w * .35f, h * .5f)
                if (glyph == NightGlyph.NEXT)
                    drawLine(color, Offset(w * .90f, h * .18f), Offset(w * .90f, h * .82f), strokeWidth = line)
            }
            NightGlyph.SETTINGS -> {
                drawCircle(color, radius = w * .29f, style = Stroke(line))
                drawCircle(color, radius = w * .105f, style = Stroke(line))
                for (n in 0 until 8) {
                    val a = n * Math.PI / 4.0
                    val cx = w / 2f
                    val cy = h / 2f
                    drawLine(color,
                        Offset(cx + kotlin.math.cos(a).toFloat() * w * .35f,
                            cy + kotlin.math.sin(a).toFloat() * w * .35f),
                        Offset(cx + kotlin.math.cos(a).toFloat() * w * .46f,
                            cy + kotlin.math.sin(a).toFloat() * w * .46f),
                        strokeWidth = line, cap = StrokeCap.Round)
                }
            }
            NightGlyph.CAPTIONS -> Unit
        }
    }
}

/** The Skip Intro / Undo button: a compact pill that lights up clearly under the D-pad. */
@Composable
private fun SkipChip(
    label: String,
    hint: String?,
    primary: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(14.dp)
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
        border = ClickableSurfaceDefaults.border(
            border = Border(androidx.compose.foundation.BorderStroke(1.dp,
                if (primary) Accent else Color(0x66FFFFFF)), shape = shape),
            focusedBorder = Border(androidx.compose.foundation.BorderStroke(2.dp, Focus), shape = shape)
        ),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (primary) Color(0xEE0F2A1A) else Color(0xE6111817),
            contentColor = Color.White,
            focusedContainerColor = Focus,
            focusedContentColor = Ink
        )
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(t(label), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (hint != null) {
                Text(hint, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Accent,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0x33FFFFFF))
                        .padding(horizontal = 7.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun PlayerPill(label: String) {
    Text(t(label), modifier = Modifier.clip(RoundedCornerShape(16.dp))
        .background(Color(0xA51A2B20)).border(1.dp, Color(0x654A7E57), RoundedCornerShape(16.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp), color = Color(0xFFE6F7EA),
        fontSize = 11.sp, fontWeight = FontWeight.Medium)
}

/** Focusable TV tiles visibly illuminate when the D-pad lands on them. */
@Composable
private fun PlayerTile(
    label: String,
    symbol: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(13.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.055f),
        border = ClickableSurfaceDefaults.border(
            focusedBorder = Border(androidx.compose.foundation.BorderStroke(2.dp, Focus), shape = RoundedCornerShape(13.dp))
        ),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (primary) Accent else Color(0xD81A2920),
            contentColor = Color.White,
            focusedContainerColor = Focus,
            focusedContentColor = Ink
        )
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(symbol, fontSize = if (symbol == "CC") 14.sp else 20.sp, fontWeight = FontWeight.Bold)
            Text(t(label), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun PlayerOption(
    label: String,
    detail: String,
    symbol: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(13.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.012f),
        border = ClickableSurfaceDefaults.border(
            focusedBorder = Border(androidx.compose.foundation.BorderStroke(2.dp, Focus), shape = RoundedCornerShape(13.dp))
        ),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (selected) Color(0xFF183825) else Color(0xFF18221D),
            contentColor = Color.White,
            focusedContainerColor = Color.White,
            focusedContentColor = Ink
        )
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(symbol, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(27.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(t(label), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                if (detail.isNotEmpty()) Text(t(detail), fontSize = 11.sp, maxLines = 1)
            }
            if (selected) Text(t("✓"), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            else Text(t("›"), fontSize = 18.sp)
        }
    }
}

@Composable
private fun DetailLine(name: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(t(name), color = Accent, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Text(t(value), fontSize = 16.sp, color = Color.White)
    }
}

@Composable
private fun CinemaTimeline(
    progress: Float,
    buffered: Float,
    seekable: Boolean,
    instant: Boolean,
    requester: FocusRequester,
    onFocus: (Boolean) -> Unit,
    onStep: (Long, Int) -> Unit,
    onJump: (Float) -> Unit,
    onUp: () -> Unit = {}
) {
    var focused by remember { mutableStateOf(false) }
    var width by remember { mutableIntStateOf(1) }
    val target = progress.coerceIn(0f, 1f)
    // Position is sampled twice a second; gliding between samples makes the bar move
    // continuously. Big jumps (seeks) snap, small steps glide.
    val last = remember { FloatArray(1) { target } }
    val jumped = kotlin.math.abs(target - last[0]) > 0.01f
    SideEffect { last[0] = target }
    val fill = animateFloatAsState(
        targetValue = target,
        animationSpec = if (instant || jumped) snap() else tween(480, easing = LinearEasing),
        label = "timeline"
    )
    val bufferedFraction = buffered.coerceIn(0f, 1f)
    Box(
        Modifier.fillMaxWidth().height(18.dp)
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused; onFocus(it.isFocused) }
            .onSizeChanged { width = it.width.coerceAtLeast(1) }
            .pointerInput(seekable, width) { detectTapGestures { offset ->
                if (seekable) onJump((offset.x / width).coerceIn(0f, 1f))
            } }
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) false else when (event.key) {
                    Key.DirectionLeft -> {
                        if (seekable) onStep(-10_000L, event.nativeKeyEvent.repeatCount)
                        true
                    }
                    Key.DirectionRight -> {
                        if (seekable) onStep(10_000L, event.nativeKeyEvent.repeatCount)
                        true
                    }
                    // Nothing sits above the timeline: Up dismisses the HUD.
                    Key.DirectionUp -> { onUp(); true }
                    else -> false
                }
            }
            .focusable(),
        contentAlignment = Alignment.CenterStart
    ) {
        // One canvas: the animated value is read in the draw phase only, so the glide
        // costs a redraw per frame, not a recomposition per frame.
        Canvas(Modifier.fillMaxSize()) {
            val trackHeight = (if (focused) 7.dp else 3.dp).toPx()
            val cy = size.height / 2f
            val top = cy - trackHeight / 2f
            val corner = androidx.compose.ui.geometry.CornerRadius(trackHeight / 2f)
            drawRoundRect(Color(0xAA515B55), Offset(0f, top), Size(size.width, trackHeight), corner)
            if (bufferedFraction > 0f) {
                drawRoundRect(Color(0xFF899C90), Offset(0f, top), Size(size.width * bufferedFraction, trackHeight), corner)
            }
            val p = fill.value.coerceIn(0f, 1f)
            if (p > 0f) {
                drawRoundRect(Accent, Offset(0f, top), Size(size.width * p, trackHeight), corner)
            }
            val thumb = (if (focused) 8.dp else 6.dp).toPx()
            val cx = (size.width * p).coerceIn(thumb, (size.width - thumb).coerceAtLeast(thumb))
            drawCircle(Color(0xFFDEFBE5), thumb, Offset(cx, cy))
            drawCircle(Accent, thumb - 2.dp.toPx(), Offset(cx, cy))
        }
    }
}

@Composable
private fun CinemaSpinner() {
    val spin = rememberInfiniteTransition(label = "buffering")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(850, easing = LinearEasing)), label = "spin")
    Canvas(Modifier.size(34.dp)) {
        val stroke = 3.5.dp.toPx()
        drawArc(Color(0x665D6574), 0f, 360f, false, topLeft = Offset(stroke, stroke),
            size = Size(size.width - 2f * stroke, size.height - 2f * stroke),
            style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = StrokeCap.Round))
        drawArc(Accent, angle, 105f, false, topLeft = Offset(stroke, stroke),
            size = Size(size.width - 2f * stroke, size.height - 2f * stroke),
            style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = StrokeCap.Round))
    }
}
