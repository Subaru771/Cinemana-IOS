package app.cinemanatv.data

/** Local filters for the titles the search endpoint actually returned.
 * No additional network requests are made when a filter or sort changes.
 */
enum class SearchKind(val label: String) {
    ALL("All"), MOVIES("Movies"), SERIES("Series")
}

enum class SearchEra(val label: String, val first: Int, val last: Int) {
    ALL("Any year", 0, 9999),
    RECENT("2025+", 2025, 9999),
    TWENTIES("2020–2024", 2020, 2024),
    TENS("2010s", 2010, 2019),
    ZEROES("2000s", 2000, 2009),
    CLASSICS("Before 2000", 0, 1999);

    fun includes(year: Int?) = this == ALL || (year != null && year in first..last)
}

enum class SearchSort(val label: String) {
    RELEVANCE("Relevance"), NEWEST("Newest"), OLDEST("Oldest"),
    RATING("Top rated"), TITLE("A–Z")
}

data class SearchFilterState(
    val kind: SearchKind = SearchKind.ALL,
    val genre: String = "",
    val era: SearchEra = SearchEra.ALL,
    val minRating: Int = 0,
    val sort: SearchSort = SearchSort.RELEVANCE,
    val matureSkip: MatureSkipFilter = MatureSkipFilter.ANY,
) {
    val activeCount: Int get() =
        (if (kind != SearchKind.ALL) 1 else 0) +
        (if (genre.isNotBlank()) 1 else 0) +
        (if (era != SearchEra.ALL) 1 else 0) +
        (if (minRating > 0) 1 else 0) +
        (if (sort != SearchSort.RELEVANCE) 1 else 0) +
        (if (matureSkip != MatureSkipFilter.ANY) 1 else 0)
}

enum class SearchFacet { GENRE, YEAR, RATING, SORT, MATURE_SKIP }

object SearchFiltering {
    private val yearPattern = Regex("(?<!\\d)(?:18|19|20)\\d{2}(?!\\d)")
    fun year(value: String?): Int? = yearPattern.find(value.orEmpty())?.value?.toIntOrNull()
    fun stars(value: String?): Double? = value?.trim()?.replace(',', '.')
        ?.substringBefore('/')?.toDoubleOrNull()?.takeIf { it in 0.0..10.0 }

    fun genres(items: List<Video>): List<String> = items.asSequence()
        .flatMap { it.genres.asSequence() }
        .map(String::trim)
        .filter(String::isNotEmpty)
        .distinctBy { it.lowercase() }
        .sortedBy { it.lowercase() }
        .toList()

    fun apply(
        items: List<Video>, filters: SearchFilterState, query: String = "",
        skipStatus: (Video) -> MatureSkipStatus = { MatureSkipStatus.UNKNOWN },
    ): List<Video> {
        val selected = items.asSequence().filter { video ->
            (when (filters.kind) {
                SearchKind.ALL -> true
                SearchKind.MOVIES -> video.kind == "1"
                SearchKind.SERIES -> video.kind == "2"
            }) &&
                (filters.genre.isBlank() || video.genres.any { it.equals(filters.genre, ignoreCase = true) }) &&
                filters.era.includes(year(video.year)) &&
                (filters.minRating == 0 || (stars(video.stars)?.let { it >= filters.minRating } == true)) &&
                filters.matureSkip.matches(skipStatus(video))
        }.toList()
        return when (filters.sort) {
            SearchSort.RELEVANCE -> if (query.isBlank()) selected else selected.withIndex()
                .sortedWith(compareByDescending<IndexedValue<Video>> { TitleSearch.score(it.value.title, query) }
                    .thenBy { it.index })
                .map { it.value }
            // Null years and ratings go last, not first, for BOTH sort directions.
            SearchSort.NEWEST -> selected.sortedWith(compareByDescending<Video> { year(it.year) ?: Int.MIN_VALUE })
            SearchSort.OLDEST -> selected.sortedWith(compareBy<Video> { year(it.year) ?: Int.MAX_VALUE })
            SearchSort.RATING -> selected.sortedWith(compareByDescending<Video> { stars(it.stars) ?: -1.0 })
            SearchSort.TITLE -> selected.sortedBy { it.title.lowercase() }
        }
    }
}
