package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class ExternalSceneMarkersTest {
    private val duration = 2_700_000L

    @Test fun skipDbIntroAndCreditsRequireAccurateStreamMatch() {
        val json = JsonParser.parseString("""{
          "segments": {
            "intro":{"start_ms":27000,"end_ms":85000,"confidence":0.93,"match":"exact"},
            "outro":{"start_ms":2600000,"end_ms":2640000,"confidence":0.90,"match":"shifted"},
            "recap":{"start_ms":1000,"end_ms":11000,"confidence":0.99,"match":"agnostic"},
            "preview":null
          }
        }""")
        val found = ExternalSceneMarkers.skipDB(json, duration)
        assertEquals(setOf("intro", "outro"), found.map { it.kind }.toSet())
        assertEquals(85_000L, found[0].destination(30_000L, duration))
        assertNull(found[0].destination(90_000L, duration))
    }

    @Test fun introDbFallbackOnlyUsesConfidentMarkers() {
        val json = JsonParser.parseString("""{
          "intro":{"start_ms":1000,"end_ms":64000,"confidence":0.96},
          "recap":{"start_ms":4500,"end_ms":18000,"confidence":0.5},
          "post_credits":{"start_ms":2640000,"end_ms":2680000,"confidence":0.85}
        }""")
        // Post-credit scenes contain story content and must never become skip offers.
        assertEquals(setOf("intro"), ExternalSceneMarkers.introDB(json, duration).map { it.kind }.toSet())
    }

    @Test fun postCreditsAloneNeverProduceSkips() {
        val raw = JsonParser.parseString("""{
          "post_credits":{"start_ms":2620000,"end_ms":2680000,"confidence":0.99}
        }""")
        assertTrue(ExternalSceneMarkers.introDB(raw, duration).isEmpty())
    }

    @Test fun movieMatureScenesRequireMatchingEditionAndExplicitSkipFlag() {
        val json = JsonParser.parseString("""{
          "imdb_id":"tt0266543", "duration":2700,
          "scenes":[
            {"start":120.5,"end":154,"reason":"nudity","skip":true},
            {"start":180,"end":190,"reason":"frightening","skip":true},
            {"start":210,"end":225,"reason":"sexual","skip":false}
          ]
        }""")
        val result = ExternalSceneMarkers.movieHaven(json,"tt0266543",duration)
        assertEquals(1,result.size)
        // Authors round to whole seconds, so mature scenes are widened slightly (1.5 s before, 1 s after).
        assertEquals(119_000L,result.single().startMs)
        assertEquals(155_000L,result.single().endMs)
        assertTrue(ExternalSceneMarkers.movieHaven(json,"tt0266544",duration).isEmpty())
        assertTrue(ExternalSceneMarkers.movieHaven(json,"tt0266543",duration+30_000).isEmpty())
    }

    @Test fun episodeLookupsUseImdbAndSeasonNumber() {
        assertTrue(ExternalSceneMarkers.skipDBURL("https://imdb.com/title/tt0903747/",1,1,duration)!!.contains("episode=1"))
        assertTrue(ExternalSceneMarkers.introDBURL("tt0903747",1,2)!!.contains("season=1"))
        assertNull(ExternalSceneMarkers.skipDBURL("no imdb",1,1,duration))
    }

    @Test fun creditsThatRunToTheEndOfTheFileAreAccepted() {
        val json = JsonParser.parseString("""{
          "segments": { "outro":{"start_ms":2640000,"end_ms":2700400,"confidence":0.9,"match":"exact"} }
        }""")
        val outro = ExternalSceneMarkers.skipDB(json, duration).single()
        assertEquals(duration, outro.endMs) // clamped to the runtime
        assertEquals(duration, outro.destination(2_650_000L, duration))
    }

    @Test fun markersBeyondThisCutAreRejected() {
        val json = JsonParser.parseString("""{
          "segments": { "intro":{"start_ms":2800000,"end_ms":2850000,"confidence":0.9,"match":"exact"} }
        }""")
        assertTrue(ExternalSceneMarkers.skipDB(json, duration).isEmpty())
    }

    @Test fun theIntroDbV4SupportsMultipleRangesAndEndOfMedia() {
        val json = JsonParser.parseString("""{
            "kind":"media",
            "intro":[{"start_ms":null,"end_ms":30000},{"start_ms":120000,"end_ms":155000}],
            "credits":[{"start_ms":2660000,"end_ms":null}],
            "preview":[{"start_ms":2600000,"end_ms":2630000}]
        }""")
        val found = ExternalSceneMarkers.theIntroDB(json, duration)
        assertEquals(4, found.size)
        assertEquals(2, found.count { it.kind == "intro" })
        assertEquals(duration, found.single { it.kind == "outro" }.endMs)
        assertTrue(ExternalSceneMarkers.theIntroDB(JsonParser.parseString("""{"kind":"episodes"}"""), duration).isEmpty())
    }

    @Test fun cleanStreamRejectsWrongEditionsAndDownvotedMarkers() {
        val json = JsonParser.parseString("""{
          "imdbId":"tt0120338", "type":"movie",
          "releases":[{"name":"Theatrical","runtime":2700000}],
          "segments":[
            {"startMs":200000,"endMs":240000,"category":"nudity","votes":{"up":15,"down":1}},
            {"startMs":260000,"endMs":270000,"category":"sex","votes":{"up":0,"down":1}},
            {"startMs":300000,"endMs":330000,"category":"violence","votes":{"up":20,"down":1}}
          ]
        }""")
        val found = ExternalSceneMarkers.cleanStream(json, "tt0120338", duration)
        assertEquals(1, found.size)
        assertEquals("mature", found.single().kind)
        assertEquals(198500L, found.single().startMs)
        assertTrue(ExternalSceneMarkers.cleanStream(json, "tt0120338", duration + 10000).isEmpty())
        assertTrue(ExternalSceneMarkers.cleanStream(json, "tt0120339", duration).isEmpty())
    }

    @Test fun cleanStreamAcceptsRealLegacyResponseShapeWithNoRuntimeAndNoVotes() {
        // CleanStream's live VideoSkip import shape: runtime=null, releases=[],
        // all votes zero, verified=false; no invented edition length.
        val json = JsonParser.parseString("""{
          "imdbId":"tt0111161", "type":"movie", "runtime":null,
          "releases":[], "segments":[
            {"startMs":200000,"endMs":222000,"category":"nudity",
             "votes":{"up":0,"down":0}, "verified":false},
            {"startMs":300000,"endMs":325000,"category":"sex",
             "votes":{"up":0,"down":0}, "verified":false},
            {"startMs":410000,"endMs":442000,"category":"violence",
             "votes":{"up":0,"down":0}, "verified":false}
          ]
        }""")
        val markers = ExternalSceneMarkers.cleanStream(json, "tt0111161", duration)
        assertEquals(2, markers.size)
        assertEquals(198500L, markers.first().startMs)
        assertEquals(0.55, markers.first().confidence, 0.0001)
        assertTrue(ExternalSceneMarkers.hasCleanStreamMatureRanges(json, "tt0111161"))
    }

    @Test fun cleanStreamEnforcesActualDurationEvenWhenSourceRuntimeUnknown() {
        val json = JsonParser.parseString("""{
          "imdbId":"tt0111161","type":"movie","runtime":null,"releases":[],
          "segments":[
             {"startMs":2000000,"endMs":2060000,"category":"nudity","votes":{"up":0,"down":0}},
             {"startMs":100000,"endMs":123000,"category":"sex","votes":{"up":0,"down":0}}
          ]
        }""")
        val accepted = ExternalSceneMarkers.cleanStream(json, "tt0111161", duration / 2)
        assertEquals(1, accepted.size)
        assertEquals(98500L, accepted.single().startMs)
    }

    @Test fun fallbackPreservesMultipleNonOverlappingIntroSegments() {
        val introOne = ExternalSceneMarker("intro", 0, 30000, "TheIntroDB", 0.92)
        val introTwo = ExternalSceneMarker("intro", 120000, 150000, "TheIntroDB", 0.91)
        val credits = ExternalSceneMarker("outro", 2640000, duration, "SkipDB", 0.95)
        val result = ExternalSceneMarkers.merge(listOf(credits), listOf(introOne, introTwo, introOne))
        assertEquals(3, result.size)
        assertEquals(2, result.count { it.kind == "intro" })
        assertEquals(1, result.count { it.kind == "outro" })
    }

    @Test fun additionalSourcesRequireImdbId() {
        assertTrue(ExternalSceneMarkers.theIntroDBURL("tt0903747", 1, 1, duration)!!.contains("duration_ms=2700000"))
        assertTrue(ExternalSceneMarkers.cleanStreamURL("tt0120338")!!.contains("tt0120338"))
        assertNull(ExternalSceneMarkers.cleanStreamURL("undefined"))
    }

}
