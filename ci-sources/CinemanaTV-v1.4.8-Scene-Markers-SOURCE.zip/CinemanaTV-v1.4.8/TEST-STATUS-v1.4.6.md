# CinemanaTV v1.4.7 — verification status

| Check | Result |
|---|---|
| New scene-skip and mature-rating Kotlin logic (16 assertions) | PASS |
| Android XML parsing (13 documents) | PASS |
| Static source routing checks for Search, Settings, Player | PASS |
| Full Android Gradle `testDebugUnitTest` | NOT RUN (Gradle distribution / Android SDK unavailable) |
| Compose UI compilation | NOT VERIFIED |
| Real Android / Google TV installation | NOT TESTED |
| Real content streaming/scene markers | NOT TESTED |

**Scene skip limitation:** there is no per-scene metadata feed and no automatic visual recognition. Skip works only for locally saved start/end timestamp markers, entered in the in-player menu. The option never silently censors an unmarked video.

Existing app data is retained by source design, but device update needs matching Android signing certificates. Builds use local debug signing, not production signing.
