package app.cinemanatv.util

import java.util.Locale

/**
 * Match actual provider subtitle labels, never fabricate a track or language.
 * Provider metadata may use Arabic script, English names, or language tags
 * such as ar-IQ and en-US. Prefer a genuine exact language tag when offered.
 */
fun preferredSubtitleLabel(language: String, labels: List<String>): String? {
    if (language != "ar" && language != "en") return null
    fun score(label: String): Int {
        val normalized = label.trim().lowercase(Locale.ROOT)
        if (normalized.isBlank()) return 0
        val tokens = Regex("[a-z]+(?:[-_][a-z]+)*").findAll(normalized).map { it.value }.toList()
        // A leading explicit BCP-47-like tag is stronger than descriptive words.
        val tagged = tokens.firstOrNull()?.replace('_', '-')
        val isArabic = language == "ar"
        if (tagged == language || tagged?.startsWith("$language-") == true) return 3
        if (isArabic && (normalized.contains("عرب") || tokens.any { it == "arabic" || it == "arab" })) return 2
        if (!isArabic && (normalized.contains("انجلي") || normalized.contains("إنجلي") ||
                    tokens.any { it == "english" || it == "eng" })) return 2
        if (tokens.any { it == language || it.startsWith("$language-") }) return 1
        return 0
    }
    return labels.withIndex().map { it to score(it.value) }
        .filter { it.second > 0 }
        .maxWithOrNull(compareBy<Pair<IndexedValue<String>, Int>> { it.second }.thenBy { -it.first.index })
        ?.first?.value
}
