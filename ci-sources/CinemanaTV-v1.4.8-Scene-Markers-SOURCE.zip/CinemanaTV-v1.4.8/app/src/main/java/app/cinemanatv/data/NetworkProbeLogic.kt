package app.cinemanatv.data

/** Pure status classification shared by the TV diagnostic and its unit tests. */
object NetworkProbeLogic {
    fun response(code: Int, contentType: String?): String {
        return when {
            code in 200..299 && contentType.orEmpty().contains("text/html", ignoreCase = true) ->
                "Server returned a web page instead of media. A provider login or access page may be intercepting the stream."
            code in 200..299 -> "Media server accepted the test request (HTTP $code). Full playback is not guaranteed."
            code == 401 -> "Media server requires authorization (HTTP 401)."
            code == 403 || code == 451 -> "Media server denied access (HTTP $code). This may be an ISP or account restriction."
            code == 404 || code == 410 -> "Stream URL is missing or expired (HTTP $code). Try opening another title."
            code == 429 || code >= 500 -> "Media server is overloaded or temporarily unavailable (HTTP $code)."
            code in 300..399 -> "Media server redirected the request (HTTP $code); destination may be inaccessible."
            else -> "Media server refused the request (HTTP $code)."
        }
    }

    fun failure(type: String): String = when (type) {
        "UnknownHostException" -> "DNS could not resolve the stream host on this ISP."
        "SSLHandshakeException", "SSLException" -> "TLS connection failed; check your TV date/time and network."
        "SocketTimeoutException", "ConnectException", "InterruptedIOException" -> "Media server connection timed out or was interrupted."
        else -> "Media server connection failed ($type)."
    }
}
