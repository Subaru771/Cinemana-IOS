package app.cinemanatv.util

import android.os.SystemClock
import android.util.Log

/** Lightweight, local-only timing for comparing real TV builds. No analytics or telemetry. */
object PerformanceMetrics {
    @Volatile private var launchedAt = SystemClock.elapsedRealtime()
    fun appStarted() { launchedAt = SystemClock.elapsedRealtime() }
    @Volatile var catalogReadyMs: Long = -1L
        private set
    @Volatile var lastFirstFrameMs: Long = -1L
        private set
    @Volatile private var playerStartedAt = 0L
    @Volatile private var firstFramePending = false

    fun catalogReady() {
        if (catalogReadyMs >= 0L) return
        catalogReadyMs = SystemClock.elapsedRealtime() - launchedAt
        Log.i("CinemanaPerf", "Catalog ready after ${catalogReadyMs}ms")
    }

    fun playbackRequested(id: String) {
        playerStartedAt = SystemClock.elapsedRealtime()
        firstFramePending = true
        Log.i("CinemanaPerf", "Playback requested for ID: $id")
    }

    fun firstFrame() {
        if (!firstFramePending || playerStartedAt <= 0L) return
        lastFirstFrameMs = SystemClock.elapsedRealtime() - playerStartedAt
        firstFramePending = false
        Log.i("CinemanaPerf", "First frame after ${lastFirstFrameMs}ms")
    }
}
