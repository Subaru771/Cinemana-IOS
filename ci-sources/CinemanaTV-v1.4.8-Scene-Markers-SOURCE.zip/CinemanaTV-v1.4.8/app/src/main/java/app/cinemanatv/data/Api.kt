package app.cinemanatv.data

import android.os.Build
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.util.Base64
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import okhttp3.Cache
import okhttp3.CacheControl
import okhttp3.Dispatcher
import okhttp3.Authenticator
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

const val API_BASE = "https://cinemana.shabakaty.com/api/android/"
private const val API_HOST = "cinemana.shabakaty.com"

/** Raw JSON is intentional: different server generations wrap payloads differently. */
interface CinemanaApi {
    @GET("banner/level/1") suspend fun banner(): JsonElement
    @GET("featuredFilm") suspend fun featured(): JsonElement
    /** Forces a real server request rather than relying on a cached successful catalog response. */
    @GET("featuredFilm") suspend fun featuredFresh(@Header("Cache-Control") cacheControl: String = "no-cache"): JsonElement
    @GET("video/videoKind/{type}/categoryNb/{cat}/langNb/{lang}/sortParam/{sort}/itemsPerPage/{n}/searchTextValue/{q}/pageNumber/{page}")
    suspend fun videos(
        @Path("type") type: String,
        @Path("cat") cat: String,
        @Path("lang") lang: String,
        @Path("sort") sort: String,
        @Path("n") n: String,
        @Path("q") q: String,
        @Path("page") page: String,
    ): JsonElement
    @GET("video/V/2/videoKind/{type}/itemsPerPage/20/video_title_search/{query}")
    suspend fun search(@Path("query") query: String, @Path("type") type: String): JsonElement
    @GET("allVideoInfo/id/{id}") suspend fun info(@Path("id") id: String): JsonElement
    @GET("videoSeason/id/{id}") suspend fun episodes(@Path("id") id: String): JsonElement
    @GET("relatedVideos/id/{id}") suspend fun related(@Path("id") id: String): JsonElement
    @GET("transcoddedfiles/id/{id}") suspend fun files(@Path("id") id: String): JsonElement
    @GET("translationfiles/id/{id}") suspend fun subtitles(@Path("id") id: String): JsonElement
    @GET("continueWatching/level/1/itemPerPage/{n}/page/{p}")
    suspend fun continueWatching(@Path("n") n: Int, @Path("p") p: Int): JsonElement
}

/** Same encoding the original client used; Retrofit percent-escapes the result. */
fun encodeQuery(q: String): String =
    Base64.encodeToString(q.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.NO_PADDING)

fun userAgent(): String = "Android-TV ${Build.VERSION.RELEASE};40510;AB CBOX 3.0"

// Never cache anything that carries per-user state or stream links that may expire.
private val NO_CACHE = listOf("continueWatching", "transcoddedfiles", "translationfiles")

fun buildCinemanaApi(context: Context, cacheDir: File, prefs: Prefs, auth: AuthRepository): CinemanaApi {
    val client = OkHttpClient.Builder()
        .cache(Cache(File(cacheDir, "api"), 20L * 1024 * 1024))
        // Default is 5 per host; home (banner + 4 rows + continue) plus a prefetch would queue.
        .dispatcher(Dispatcher().apply { maxRequestsPerHost = 8 })
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .addInterceptor { chain ->
            val original = chain.request()
            val builder = original.newBuilder().header("User-Agent", userAgent())
            if (original.url.isHttps && original.url.host == API_HOST && auth.isLoggedIn) {
                // Token refresh is rare; never activate it for guest browsing.
                if (prefs.expiresAt < System.currentTimeMillis() + 60_000L && prefs.refreshToken.isNotBlank()) {
                    auth.refreshBlocking()
                }
                auth.bearer()?.let {
                    builder.header("Authorization", it)
                    // HTTP disk cache is shared with guests and prior accounts.
                    // Authenticated responses must not be read from/written to that cache.
                    builder.header("Cache-Control", "no-cache, no-store")
                }
            }
            val request = builder.build()
            try {
                chain.proceed(request)
            } catch (e: IOException) {
                // Offline? Fall back to anything we cached in the last week instead of showing an error.
                val stale = request.newBuilder()
                    .cacheControl(CacheControl.Builder().onlyIfCached().maxStale(7, TimeUnit.DAYS).build())
                    .build()
                val cached = chain.proceed(stale)
                if (cached.code == 504) { cached.close(); throw e } else cached
            }
        }
        .addNetworkInterceptor { chain ->
            val response = chain.proceed(chain.request())
            val path = chain.request().url.encodedPath
            if (chain.request().header("Authorization") != null) {
                response.newBuilder().header("Cache-Control", "private, no-store").build()
            } else if (response.isSuccessful && NO_CACHE.none { path.contains(it, ignoreCase = true) }) {
                response.newBuilder().removeHeader("Pragma").header("Cache-Control", "public, max-age=300").build()
            } else response
        }
        .authenticator(object : Authenticator {
            override fun authenticate(route: Route?, response: Response): Request? {
                if (!response.request.url.isHttps || response.request.url.host != API_HOST ||
                    responseCount(response) >= 2 || !auth.isLoggedIn) return null
                val sent = response.request.header("Authorization")
                val current = auth.bearer()
                if (current != null && current != sent) {
                    return response.request.newBuilder().header("Authorization", current).build()
                }
                if (!auth.refreshBlocking(force = true)) return null
                val token = auth.bearer() ?: return null
                return response.request.newBuilder().header("Authorization", token).build()
            }
        })
        .build()
    // On Wi-Fi/Ethernet/ISP changes, old idle TCP/TLS sockets may still point to the
    // previous network. Drop only idle connections; active requests complete normally.
    // New requests use Android's default routing and DNS for the current connection.
    runCatching {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        manager.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { client.connectionPool.evictAll() }
            override fun onLost(network: Network) { client.connectionPool.evictAll() }
        })
    }
    return Retrofit.Builder()
        .baseUrl(API_BASE)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create()))
        .build()
        .create(CinemanaApi::class.java)
}

private fun responseCount(response: Response): Int {
    var item: Response? = response
    var count = 0
    while (item != null) { count++; item = item.priorResponse }
    return count
}
