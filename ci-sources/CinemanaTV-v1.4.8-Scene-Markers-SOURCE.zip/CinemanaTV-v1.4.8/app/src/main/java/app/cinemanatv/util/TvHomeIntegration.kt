package app.cinemanatv.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import java.util.concurrent.Executors
import androidx.tvprovider.media.tv.TvContractCompat
import androidx.tvprovider.media.tv.WatchNextProgram
import app.cinemanatv.MainActivity
import app.cinemanatv.data.Video
import app.cinemanatv.data.MediaContentFilter

/** Android TV Watch Next; supported launchers may choose not to display third-party entries. */
object TvHomeIntegration {
    const val EXTRA_WATCH_VIDEO = "app.cinemanatv.watch_next_video_id"
    private const val TAG = "CinemanaWatchNext"
    private val programs = TvContractCompat.WatchNextPrograms.CONTENT_URI
    private val background = Executors.newSingleThreadExecutor { task ->
        Thread(task, "cinemana-watch-next").apply { isDaemon = true }
    }

    fun enqueueUpdate(context: Context, video: Video, atMs: Long, totalMs: Long) {
        background.execute { update(context.applicationContext, video, atMs, totalMs) }
    }

    fun enqueueRemove(context: Context, id: String) {
        background.execute { remove(context.applicationContext, id) }
    }

    fun enqueueRemoveAll(context: Context) {
        background.execute {
            val app = context.applicationContext
            val ids = app.getSharedPreferences("cinemana_watch_next", Context.MODE_PRIVATE)
                .all.keys.toList()
            ids.forEach { remove(app, it) }
        }
    }

    private fun itemUri(context: Context, id: String): Uri? = context
        .getSharedPreferences("cinemana_watch_next", Context.MODE_PRIVATE)
        .getString(id, null)?.let(Uri::parse)

    private fun setItemUri(context: Context, id: String, uri: Uri?) {
        context.getSharedPreferences("cinemana_watch_next", Context.MODE_PRIVATE)
            .edit().apply {
                if (uri == null) remove(id) else putString(id, uri.toString())
            }.apply()
    }

    /** Call from a background dispatcher; insert/update permissions vary by TV launcher. */
    fun update(context: Context, video: Video, atMs: Long, totalMs: Long) {
        if (Build.VERSION.SDK_INT < 26 || !app.cinemanatv.Services.prefs.tvHomeEnabled || video.id.isBlank()) return
        if (!MediaContentFilter.allowed(video, app.cinemanatv.Services.prefs.contentFilterMode)) {
            remove(context, video.id)
            return
        }
        if (atMs < 60_000L || totalMs <= 0L || atMs >= totalMs - 30_000L) {
            remove(context, video.id)
            return
        }
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_WATCH_VIDEO, video.id)
            }
            val builder = WatchNextProgram.Builder()
                .setWatchNextType(TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE)
                .setLastEngagementTimeUtcMillis(System.currentTimeMillis())
                .setTitle(video.title)
                .setType(if (video.episodeNummer != null)
                    TvContractCompat.PreviewPrograms.TYPE_TV_EPISODE
                    else TvContractCompat.PreviewPrograms.TYPE_MOVIE)
                .setInternalProviderId(video.id)
                .setIntentUri(Uri.parse(intent.toUri(Intent.URI_INTENT_SCHEME)))
                .setLastPlaybackPositionMillis(atMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                .setDurationMillis(totalMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            video.poster?.takeIf { it.startsWith("https://") || it.startsWith("http://") }
                ?.let { builder.setPosterArtUri(Uri.parse(it)) }
            val values = builder.build().toContentValues()
            val old = itemUri(context, video.id)
            val updated = old?.let {
                runCatching { context.contentResolver.update(it, values, null, null) }.getOrDefault(0)
            } ?: 0
            if (updated <= 0) {
                context.contentResolver.insert(programs, values)?.let { setItemUri(context, video.id, it) }
            }
        } catch (e: Exception) {
            // Lack of TV provider support must never interrupt video playback.
            Log.w(TAG, "Watch Next not available on this launcher", e)
        }
    }

    fun remove(context: Context, id: String) {
        if (Build.VERSION.SDK_INT < 26 || id.isBlank()) return
        runCatching { itemUri(context, id)?.let { context.contentResolver.delete(it, null, null) } }
        setItemUri(context, id, null)
    }
}
