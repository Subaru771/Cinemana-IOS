package app.cinemanatv.data

/** Scene-only skip preference. HIDE_TITLES is retained solely for migrating older saved values. */
enum class MatureAction {
    OFF,
    SKIP_SCENES,
    HIDE_TITLES
}
