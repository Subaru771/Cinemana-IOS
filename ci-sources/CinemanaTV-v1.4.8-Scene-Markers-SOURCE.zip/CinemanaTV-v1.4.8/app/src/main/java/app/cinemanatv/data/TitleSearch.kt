package app.cinemanatv.data

import java.text.Normalizer
import java.util.Locale

/** Deterministic, accent-insensitive title match. Search API relevance is not trusted. */
object TitleSearch {
    private val separators = Regex("""[^\p{L}\p{N}]+""")
    private val spaces = Regex("""\s+""")
    private val marks = Regex("""\p{M}+""")
    private val articles = setOf("the", "a", "an")

    fun normalize(text: String): String = Normalizer.normalize(text, Normalizer.Form.NFKD)
        .replace(marks, "")
        .lowercase(Locale.ROOT)
        .replace(separators, " ")
        .trim()
        .replace(spaces, " ")

    private fun withoutArticle(s: String): String = s.split(' ')
        .dropWhile { it in articles }.joinToString(" ")

    /** >= 650 is a strong title match: don't bury it under unrelated results. */
    fun score(title: String, rawQuery: String): Int {
        val name = normalize(title)
        val query = normalize(rawQuery)
        if (name.isBlank() || query.isBlank()) return 0
        if (name == query) return 1000
        if (withoutArticle(name) == withoutArticle(query)) return 970
        if (name.startsWith("$query ") || withoutArticle(name).startsWith("${withoutArticle(query)} ")) return 900
        if (" $name ".contains(" $query ")) return 840
        val words = query.split(' ').filter { it.length >= 2 && it !in articles }.distinct()
        if (words.isEmpty()) return if (name.contains(query)) 700 else 0
        val titleWords = name.split(' ').toSet()
        if (words.all { it in titleWords }) return 720
        val matched = words.count { it in titleWords }
        return if (matched > 0) 100 + 20 * matched else 0
    }
}
