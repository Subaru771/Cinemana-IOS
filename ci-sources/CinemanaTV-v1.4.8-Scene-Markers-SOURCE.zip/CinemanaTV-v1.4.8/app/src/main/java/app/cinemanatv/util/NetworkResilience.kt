@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/** No alternate endpoints or IP spoofing. Diagnoses the actual Android network and server responses. */
data class LinkState(val connected: Boolean, val type: String, val routeId: String)

enum class FailureType { OFFLINE, RESTRICTED, UNAUTHORIZED, NOT_FOUND, TRANSIENT, DNS, TLS, OTHER }

data class FailureInfo(val type: FailureType, val message: String, val recoverable: Boolean)

object NetworkResilience {
    fun link(context: Context): LinkState {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val active = manager.activeNetwork ?: return LinkState(false, "Disconnected", "offline")
        val cap = manager.getNetworkCapabilities(active)
        val type = when {
            cap?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            cap?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            cap?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile hotspot/data"
            cap?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true -> "VPN"
            else -> "Other network"
        }
        return LinkState(true, type, active.toString())
    }

    /** Reports route changes, not just Wi-Fi signal fluctuations. Does not override OS networking. */
    fun watch(context: Context): Flow<LinkState> = callbackFlow {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        fun publish() { trySend(link(context)) }
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = publish()
            override fun onLost(network: Network) = publish()
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = publish()
        }
        publish()
        manager.registerDefaultNetworkCallback(callback)
        publish()
        awaitClose { manager.unregisterNetworkCallback(callback) }
    }.distinctUntilChanged()

    private fun errors(cause: Throwable): Sequence<Throwable> = sequence {
        var current: Throwable? = cause
        var depth = 0
        while (current != null && depth++ < 8) { yield(current); current = current.cause }
    }

    fun diagnose(context: Context, error: Throwable): FailureInfo {
        if (!link(context).connected) return FailureInfo(
            FailureType.OFFLINE, "No active network. Reconnect Wi-Fi/Ethernet and playback will retry.", true
        )
        val chain = errors(error).toList()
        val httpCode = chain.firstNotNullOfOrNull {
            when (it) {
                is HttpException -> it.code()
                is HttpDataSource.InvalidResponseCodeException -> it.responseCode
                else -> null
            }
        }
        return when (httpCode) {
            401 -> FailureInfo(FailureType.UNAUTHORIZED, "Stream authorization was rejected (HTTP 401). Check your session or provider access.", false)
            403, 451 -> FailureInfo(FailureType.RESTRICTED, "The source refused this connection (HTTP $httpCode). Shabakaty may restrict your ISP; switching quality or DNS will not fix provider access.", false)
            404, 410 -> FailureInfo(FailureType.NOT_FOUND, "The provider's stream link is unavailable (HTTP $httpCode). Try refreshing the title.", false)
            408, 425, 429, 500, 502, 503, 504 -> FailureInfo(FailureType.TRANSIENT, "Server temporarily unavailable (HTTP $httpCode). Retrying the stream.", true)
            null -> when {
                chain.any { it is UnknownHostException } -> FailureInfo(FailureType.DNS, "The stream hostname cannot be resolved on this network. Check DNS or try another connection.", true)
                chain.any { it is SSLException } -> FailureInfo(FailureType.TLS, "Secure connection failed. Check TV date/time and network certificates.", false)
                chain.any { it is SocketTimeoutException || it is ConnectException } -> FailureInfo(FailureType.TRANSIENT, "Connection timed out or was interrupted. Retrying.", true)
                error is PlaybackException && error.errorCode in 2000..2099 -> FailureInfo(
                    FailureType.TRANSIENT, "Network read failed (${error.errorCodeName}). Retrying.", true
                )
                else -> FailureInfo(FailureType.OTHER, "The content server or player failed (${error.javaClass.simpleName}). Try again or check source availability.", false)
            }
            else -> FailureInfo(FailureType.OTHER, "Stream request rejected (HTTP $httpCode). Check availability on this network.", false)
        }
    }
}
