package app.cinemanatv.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.Alignment
import app.cinemanatv.data.SearchFilterState
import app.cinemanatv.data.SearchFiltering
import app.cinemanatv.data.SearchKind
import app.cinemanatv.data.SearchFacet
import app.cinemanatv.data.SearchEra
import app.cinemanatv.data.SearchSort
import app.cinemanatv.data.ContentFilterMode
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.util.Capabilities
import app.cinemanatv.util.Downloads
import app.cinemanatv.util.StorageDiagnostics
import app.cinemanatv.util.NextEpisodePreloader
import app.cinemanatv.util.TvHomeIntegration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SearchScreen(vm: AppViewModel) {
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(vm.searchQuery) {
        val query = vm.searchQuery.trim()
        if (query.length < 2) {
            vm.searchResults = null
            vm.searchDone = ""
            loading = false
            failed = false
            return@LaunchedEffect
        }
        if (query == vm.searchDone && vm.searchResults != null) {
            loading = false
            failed = false
            return@LaunchedEffect // returning from title details; no redundant request
        }
        loading = true
        failed = false
        delay(300) // typing debounce; filters never trigger a request
        try {
            vm.searchResults = Services.repo.search(query)
            vm.searchDone = query
        } catch (c: CancellationException) {
            throw c
        } catch (_: Exception) {
            failed = true
        } finally {
            loading = false
        }
    }

    val query = vm.searchQuery.trim()
    // Never display results for a previous search while a new query is loading.
    val results = vm.searchResults?.takeIf { query.length >= 2 && query == vm.searchDone }
    val filters = vm.searchFilters
    val mode = vm.contentFilterMode
    LaunchedEffect(results, mode) { results?.let { vm.resolveMaturity(it) } }
    val visibleResults = vm.visible(results.orEmpty())
    val genres = remember(visibleResults) { SearchFiltering.genres(visibleResults) }
    val ranked = remember(visibleResults, filters, query) {
        SearchFiltering.apply(visibleResults, filters, query)
    }
    var showRelated by remember(query) { mutableStateOf(false) }
    // A full title must outrank provider-side keyword matches. Let viewers reveal
    // broader suggestions explicitly instead of flooding the grid with them.
    val strong = remember(ranked, query) {
        if (query.length < 3) emptyList()
        else ranked.filter { app.cinemanatv.data.TitleSearch.score(it.title, query) >= 650 }
    }
    val shown = if (strong.isNotEmpty() && !showRelated) strong else ranked
    val relatedCount = (ranked.size - strong.size).coerceAtLeast(0)
    val inputFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { inputFocus.requestFocus() } } // panel opens ready to type

    LaunchedEffect(filters, vm.searchDone, vm.contentFilterMode, showRelated) {
        // A narrower filter must not leave the grid stranded at an old scroll index.
        vm.searchGrid.scrollToItem(0)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TvTextField(
                vm.searchQuery, { vm.searchQuery = it }, "Search movies and series",
                Modifier.weight(1f).focusRequester(inputFocus), imeAction = ImeAction.Search,
            )
            if (vm.searchQuery.isNotBlank()) AppButton("Clear") {
                vm.searchQuery = ""
                vm.searchResults = null
                vm.searchDone = ""
            }
            AppButton("Close ▴") { vm.tab = vm.lastTab }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(t("Type"), color = C.Dim, fontSize = 13.sp)
            SearchKind.entries.forEach { kind ->
                AppButton(kind.label, primary = filters.kind == kind) {
                    vm.searchFilters = vm.searchFilters.copy(kind = kind)
                }
            }
            Spacer(Modifier.width(8.dp))
            AppButton(if (vm.searchFiltersOpen) "Filters ▴" else "Filters ▾") {
                vm.searchFiltersOpen = !vm.searchFiltersOpen
                if (!vm.searchFiltersOpen) vm.searchFacet = null
            }
            if (filters.activeCount > 0) AppButton("Reset (${filters.activeCount})") {
                vm.searchFilters = SearchFilterState()
                vm.searchFacet = null
            }
        }

        if (vm.searchFiltersOpen) {
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SearchFacet.entries.forEach { facet ->
                    val selected = when (facet) {
                        SearchFacet.GENRE -> "Genre: ${filters.genre.ifBlank { "Any" }}"
                        SearchFacet.YEAR -> "Year: ${filters.era.label}"
                        SearchFacet.RATING -> "Rating: ${if (filters.minRating == 0) "Any" else "${filters.minRating}+"}"
                        SearchFacet.SORT -> "Sort: ${filters.sort.label}"
                    }
                    AppButton(selected, primary = vm.searchFacet == facet) {
                        vm.searchFacet = if (vm.searchFacet == facet) null else facet
                    }
                }
            }
            when (vm.searchFacet) {
                SearchFacet.GENRE -> Column {
                    SearchFilterChoices(
                        listOf("Any genre") + genres,
                        filters.genre.ifBlank { "Any genre" },
                    ) { selection -> vm.searchFilters = vm.searchFilters.copy(genre = if (selection == "Any genre") "" else selection) }
                    if (genres.isEmpty()) Text(t("No genre tags available in these search results."), color = C.Dim, fontSize = 12.sp)
                }
                SearchFacet.YEAR -> SearchFilterChoices(SearchEra.entries.map { it.label }, filters.era.label) { selection ->
                    vm.searchFilters = vm.searchFilters.copy(era = SearchEra.entries.first { it.label == selection })
                }
                SearchFacet.RATING -> SearchFilterChoices(listOf("Any rating", "6+", "7+", "8+", "9+"),
                    if (filters.minRating == 0) "Any rating" else "${filters.minRating}+") { selection ->
                    vm.searchFilters = vm.searchFilters.copy(minRating = selection.removeSuffix("+").toIntOrNull() ?: 0)
                }
                SearchFacet.SORT -> SearchFilterChoices(SearchSort.entries.map { it.label }, filters.sort.label) { selection ->
                    vm.searchFilters = vm.searchFilters.copy(sort = SearchSort.entries.first { it.label == selection })
                }
                null -> Unit
            }
        }

        Spacer(Modifier.height(10.dp))
        when {
            failed && results == null -> Text(t("Search failed. Check the connection or try again."), color = C.Dim)
            loading && results == null -> Text(t("Searching…"), color = C.Dim)
            query.length < 2 -> Text(t("Type at least 2 characters to search."), color = C.Dim)
            results == null -> Text(t("Searching…"), color = C.Dim)
            vm.maturityBusy && visibleResults.isEmpty() -> Text(t("Checking age ratings…"), color = C.Dim)
            else -> {
                val resultSummary = if (strong.isNotEmpty() && !showRelated)
                    "${shown.size} strong title match(es) · $relatedCount related hidden"
                    else "${shown.size} of ${visibleResults.size} results"
                Text(
                    t(resultSummary) +
                        if (filters.activeCount > 0) "  ·  " + t("${filters.activeCount} active filters") else "",
                    color = C.Dim, fontSize = 13.sp,
                )
                if (strong.isNotEmpty() && relatedCount > 0) {
                    Spacer(Modifier.height(7.dp))
                    AppButton(if (showRelated) "Hide loosely related results" else "Show $relatedCount related results") {
                        showRelated = !showRelated
                    }
                }
                Spacer(Modifier.height(4.dp))
                when {
                    results.isEmpty() -> Text(t("No results for “$query”."), color = C.Dim)
                    visibleResults.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(t("All results were hidden by content settings."), color = C.Dim)
                        AppButton("Content settings") { vm.tab = 7 }
                    }
                    shown.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(t("No titles match these filters."), color = C.Dim)
                        AppButton("Clear filters") { vm.searchFilters = SearchFilterState(); vm.searchFacet = null }
                    }
                    else -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(112.dp),
                        state = vm.searchGrid,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 12.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(shown, key = { it.id }) { v -> PosterCard(v, onClick = { vm.push(Screen.Detail(v)) }) }
                    }
                }
            }
        }
    }
}

/** Horizontally scrollable choices, with a visible selected state and D-pad focus. */
@Composable
private fun SearchFilterChoices(options: List<String>, selected: String, onPick: (String) -> Unit) {
    Spacer(Modifier.height(8.dp))
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        options.forEach { option ->
            AppButton(option, primary = selected == option) { onPick(option) }
        }
    }
}

@Composable
fun DownloadsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var refreshDownloads by remember { mutableIntStateOf(0) }
    // Query DownloadManager off the UI thread; cheap TV CPUs otherwise stutter during progress polls.
    val mode = vm.contentFilterMode
    // Fetch raw statuses off the main thread, but resolve and filter content on the
    // Compose thread. Otherwise downloads bypass the metadata lookup entirely.
    val allStatuses by produceState(emptyList<Pair<app.cinemanatv.data.Video, Downloads.Status>>(), ctx, refreshDownloads) {
        while (true) {
            value = withContext(Dispatchers.IO) {
                Services.prefs.downloads().map { it to Downloads.status(ctx, it.id) }
            }
            delay(1_500L)
        }
    }
    val allDownloads = allStatuses.map { it.first }
    val downloadIds = allDownloads.map { it.id }
    LaunchedEffect(downloadIds, mode) { vm.resolveMaturity(allDownloads) }
    val visibleIds = vm.visible(allDownloads).mapTo(hashSetOf<String>()) { it.id }
    val withStatus = allStatuses.filter { (v, _) -> v.id in visibleIds }
        .map { (v, status) -> vm.resolve(v) to status }
    val active = withStatus.filter { it.second.state != Downloads.State.DONE }
    val completed = withStatus.filter { it.second.state == Downloads.State.DONE }.map { it.first }
    val totalBytes = withStatus.filter { it.second.state == Downloads.State.DONE }
        .sumOf { (v, status) -> Downloads.local(ctx, v.id)?.length() ?: status.bytes }
    val occupied = if (totalBytes >= 1_073_741_824L)
        String.format(java.util.Locale.US, "%.1f GB", totalBytes / 1_073_741_824.0)
        else String.format(java.util.Locale.US, "%.0f MB", totalBytes / 1_048_576.0)
    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(t("Downloads"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("${completed.size} " + t("saved") + " · " + occupied,
                fontSize = 14.sp, color = C.Dim)
        }
        if (active.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(t("Download queue") + " (${active.size})", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                val failed = active.filter { it.second.state == Downloads.State.FAILED }
                if (failed.isNotEmpty()) {
                    AppButton("Clear failed") {
                        scope.launch {
                            withContext(Dispatchers.IO) { failed.forEach { (video, _) -> Downloads.remove(ctx, video.id) } }
                            refreshDownloads++
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                active.forEach { (v, st) ->
                    Column(Modifier.width(260.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(v.title, fontSize = 14.sp, maxLines = 1)
                        val stateLabel = when (st.state) {
                            Downloads.State.QUEUED -> t("Queued")
                            Downloads.State.RUNNING -> t("Downloading") + (if (st.total > 0L) " ${st.percent}%" else " · ${st.bytes / 1_048_576} MB")
                            Downloads.State.PAUSED -> t("Paused") + " ${st.percent}%"
                            Downloads.State.FAILED -> t("Failed")
                            else -> t("Waiting")
                        }
                        Text(stateLabel + " · " + Services.prefs.downloadQuality(v.id),
                            fontSize = 12.sp, color = C.Dim)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (st.state == Downloads.State.FAILED) {
                                AppButton("Retry") { vm.push(Screen.Detail(v)) }
                                AppButton("Remove") {
                                    scope.launch {
                                        withContext(Dispatchers.IO) { Downloads.remove(ctx, v.id) }
                                        refreshDownloads++
                                    }
                                }
                            } else {
                                AppButton("Cancel") {
                                    scope.launch {
                                        withContext(Dispatchers.IO) { Downloads.remove(ctx, v.id) }
                                        refreshDownloads++
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(t("Saved videos"), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (completed.isEmpty()) {
            if (vm.maturityBusy && mode != ContentFilterMode.OFF && allDownloads.isNotEmpty())
                Text(t("Checking age ratings…"), color = C.Dim)
            else if (allDownloads.isNotEmpty() && mode != ContentFilterMode.OFF)
                Text(t("Downloaded titles are hidden by content settings or awaiting rating checks. Files were not deleted."), color = C.Dim)
            else
                Text(t("No saved videos yet. Open a title and choose Download options."), color = C.Dim)
        } else {
            Text(t("Select to open. Hold OK to remove downloaded file."), color = C.Dim, fontSize = 13.sp)
            LazyVerticalGrid(
                columns = GridCells.Adaptive(112.dp),
                contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(completed, key = { it.id }) { v ->
                    PosterCard(v,
                        onLongClick = {
                            scope.launch {
                                withContext(Dispatchers.IO) { Downloads.remove(ctx, v.id) }
                                refreshDownloads++
                                Toast.makeText(ctx, if (vm.interfaceLanguage == "ar") "تم حذف التنزيل" else "Download removed", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onClick = { vm.push(Screen.Detail(v)) },
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel) {
    var tick by remember { mutableIntStateOf(0) }
    val stored = remember(tick) { Services.prefs.history() }
    LaunchedEffect(stored, vm.contentFilterMode) { vm.resolveMaturity(stored) }
    val items = vm.visible(stored)

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(t("History"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            if (items.isNotEmpty()) AppButton("Clear history") { Services.prefs.clearHistory(); tick++ }
        }
        if (items.isEmpty()) {
            Text(t(if (stored.isNotEmpty() && vm.contentFilterMode != ContentFilterMode.OFF)
                "Watched titles are hidden by content settings or awaiting rating checks."
                else "Nothing watched yet. Titles you play show up here."), color = C.Dim)
        } else {
            Text(t("Most recent first. Select a title to open it; hold OK to remove it from history."), color = C.Dim, fontSize = 13.sp)
            LazyVerticalGrid(
                columns = GridCells.Adaptive(112.dp),
                contentPadding = PaddingValues(vertical = 12.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(items, key = { it.id }) { v ->
                    PosterCard(
                        v,
                        onLongClick = { Services.prefs.removeHistory(v.id); tick++ },
                        onClick = { vm.push(Screen.Detail(v)) },
                    )
                }
            }
        }
    }
}

/** A durable, fully local watchlist; selecting an item opens its normal Cinemana detail page. */
@Composable
fun WatchlistScreen(vm: AppViewModel) {
    var refresh by remember { mutableIntStateOf(0) }
    val stored = remember(refresh) { Services.prefs.watchlist() }
    LaunchedEffect(stored, vm.contentFilterMode) { vm.resolveMaturity(stored) }
    val saved = vm.visible(stored)
    var listSort by remember { mutableIntStateOf(0) }
    val shownSaved = remember(saved.map { it.id }, listSort) {
        when (listSort) {
            1 -> saved.sortedBy { it.title.lowercase() }
            2 -> saved.sortedByDescending { SearchFiltering.stars(it.stars) ?: -1.0 }
            3 -> saved.sortedByDescending { SearchFiltering.year(it.year) ?: 0 }
            else -> saved
        }
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(t("My List"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("${saved.size}", color = C.Dim, fontSize = 14.sp)
        }
        if (saved.isEmpty()) {
            Text(t(if (stored.isNotEmpty() && vm.contentFilterMode != ContentFilterMode.OFF)
                "Saved titles are hidden by content settings or awaiting rating checks."
                else "No titles saved yet. Open a movie or series and choose Add to My List."), color = C.Dim)
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Recently saved", "A–Z", "Top rated", "Newest release").forEachIndexed { index, label ->
                    AppButton(t(label), primary = listSort == index) { listSort = index }
                }
            }
            Text(t("Select a title to see details. Hold OK to remove it from your list."), color = C.Dim, fontSize = 13.sp)
            LazyVerticalGrid(
                columns = GridCells.Adaptive(112.dp),
                contentPadding = PaddingValues(vertical = 12.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(shownSaved, key = { it.id }) { video ->
                    PosterCard(video,
                        onClick = { vm.push(Screen.Detail(video)) },
                        onLongClick = { Services.prefs.removeWatchlist(video.id); refresh++ },
                    )
                }
            }
        }
    }
}
