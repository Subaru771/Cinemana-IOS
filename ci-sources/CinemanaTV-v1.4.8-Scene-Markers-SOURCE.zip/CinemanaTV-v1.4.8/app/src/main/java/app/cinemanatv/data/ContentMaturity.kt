package app.cinemanatv.data

/**
 * Metadata-only filtering. An unrated title is UNKNOWN, never automatically "safe".
 * The catalog does not identify explicit moments within an otherwise allowed movie.
 * No external service or fuzzy title/description keyword matching is used.
 */
enum class ContentFilterMode(val label: String) {
    OFF("Off"),
    HIDE_MATURE("Hide mature (16+/R/TV-MA)"),
    FAMILY("Family only (PG/12 and below)")
}

object ContentMaturity {
    private enum class Level { CHILD, TEEN, MATURE, UNKNOWN }

    private fun level(rating: String?): Level {
        val raw = rating?.trim()?.uppercase(java.util.Locale.ROOT).orEmpty()
        if (raw.isEmpty()) return Level.UNKNOWN
        // Treat only a content CERTIFICATE as age, not an IMDb user score.
        val s = raw.replace('–', '-').replace('—', '-').replace('_', '-').replace(" ", "")
        if (s in setOf("NC-17", "NC17", "TV-MA", "TVMA", "R", "R18+", "18A", "X", "XXX", "AO", "ADULT", "ADULTS-ONLY", "MATURE", "MA15+", "MA15",
                "RATEDR", "R-RATED", "RRATED", "RESTRICTED", "TV-MA-L", "TV-MA-S", "TV-MA-V", "TV-MA-LSV", "18PLUS", "16PLUS", "+18", "+16", "ADULTSONLY") ||
            s.startsWith("RATEDR(") || s.startsWith("RATEDNC-17") || s.startsWith("R(") || s.startsWith("TV-MA") || s.startsWith("NC-17")) return Level.MATURE
        if (s in setOf("G", "PG", "U", "TV-Y", "TVY", "TV-Y7", "TVY7", "TV-G", "TVG", "TV-PG", "TVPG", "ALL", "GENERAL", "FAMILY", "0+", "6+", "7+", "12", "12+", "PG12")) return Level.CHILD
        if (s in setOf("PG-13", "PG13", "TV-14", "TV14", "13+", "14+", "15", "15+", "M", "UA", "UA13+")) return Level.TEEN
        val age = Regex("^(?:AGES?|AGE|RATED|\\+)?([0-9]{1,2})\\+?$", RegexOption.IGNORE_CASE)
            .matchEntire(s)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (age != null) return when {
            age >= 16 -> Level.MATURE
            age >= 13 -> Level.TEEN
            else -> Level.CHILD
        }
        return Level.UNKNOWN
    }

    private fun explicitTag(tag: String): Boolean {
        val s = tag.trim().lowercase(java.util.Locale.ROOT)
        return s in setOf(
            "adult", "adults", "adults only", "adult content", "erotic", "erotica", "porn", "pornography", "xxx",
            "18+", "+18", "sex", "sexual content", "softcore", "hentai", "nudity",
            "للكبار", "+١٨", "١٨+", "جنس", "جنسي", "اثارة", "إثارة",
            "إباحي", "إباحية", "للكبار فقط", "أفلام إباحية", "للبالغين فقط",
        )
    }

    /** Rating/genre checks can only block items with useful provider metadata. */
    fun allowed(
        rating: String?, genres: List<String>, explicitAdult: Boolean,
        mode: ContentFilterMode,
        parentRating: String? = null,
        parentGenres: List<String> = emptyList(),
        parentAdult: Boolean = false,
    ): Boolean {
        if (mode == ContentFilterMode.OFF) return true
        if (explicitAdult || parentAdult || (genres + parentGenres).any(::explicitTag)) return false
        val levels = listOfNotNull(rating, parentRating).map(::level)
        if (levels.any { it == Level.MATURE }) return false
        if (mode == ContentFilterMode.HIDE_MATURE) return true
        // Family mode fails closed when rating data is missing or unrecognised.
        // If a parent has a rating, a nested episode may inherit that certification.
        return levels.isNotEmpty() && levels.all { it == Level.CHILD }
    }
}
