package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.MatureAction
import app.cinemanatv.util.Capabilities
import app.cinemanatv.util.NextEpisodePreloader
import app.cinemanatv.util.StorageDiagnostics
import app.cinemanatv.util.TvHomeIntegration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Focusable two-pane TV settings. Every choice is a real persisted action, not decorative text. */
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val prefs = Services.prefs
    val scope = rememberCoroutineScope()
    val ar = vm.interfaceLanguage == "ar"
    fun label(en: String, arabic: String) = if (ar) arabic else en
    val sections = listOf(
        label("General", "عام"), label("Mature content", "المحتوى المخصص للكبار"),
        label("Playback", "التشغيل"), label("Subtitles", "الترجمة"),
        label("Home screen", "الرئيسية"), label("Downloads", "التنزيلات"),
        label("Storage", "التخزين"), label("Diagnostics", "فحص الاتصال"),
    )
    var selected by remember { mutableIntStateOf(0) }
    var quality by remember { mutableIntStateOf(prefs.maxQuality) }
    var subtitle by remember { mutableStateOf(prefs.preferredSubtitleLanguage) }
    var autoNext by remember { mutableStateOf(prefs.autoPlayNextEnabled) }
    var bingeCheck by remember { mutableStateOf(prefs.bingeCheckEnabled) }
    var unmetered by remember { mutableStateOf(prefs.downloadUnmeteredOnly) }
    var tvHome by remember { mutableStateOf(prefs.tvHomeEnabled) }
    var communityMarkers by remember { mutableStateOf(prefs.communitySceneMarkersEnabled) }
    var storageRefresh by remember { mutableIntStateOf(0) }
    var diagnostic by remember { mutableStateOf("") }
    var diagnosing by remember { mutableStateOf(false) }

    Row(
        Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0D111B), C.Bg))
        ).padding(22.dp),
        horizontalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        Column(
            Modifier.width(238.dp).fillMaxHeight()
                .background(C.Panel, RoundedCornerShape(19.dp)).padding(13.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(label("SETTINGS", "الإعدادات"), color = Color.White,
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 12.dp, top = 10.dp))
            Text("CinemanaTV · 1.4.8", color = C.Dim, fontSize = 12.sp,
                modifier = Modifier.padding(start = 12.dp))
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                itemsIndexed(sections) { i, name ->
                    AppButton(
                        if (i == selected) "▍  $name" else "   $name",
                        Modifier.fillMaxWidth(), primary = selected == i,
                        onFocused = { selected = i },
                    ) { selected = i }
                }
            }
        }

        Column(Modifier.weight(1f).fillMaxHeight()) {
            Text(sections[selected], fontSize = 30.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp, top = 7.dp, bottom = 14.dp))
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentPadding = PaddingValues(bottom = 32.dp, end = 14.dp),
                verticalArrangement = Arrangement.spacedBy(15.dp),
            ) {
                when (selected) {
                    0 -> {
                        item {
                            SettingsCard(label("Interface language", "لغة الواجهة"),
                                label("Applied immediately and saved on this TV.", "تتغير اللغة فوراً وتُحفظ على هذا التلفاز.")) {
                                SettingChoices(listOf("en" to "English", "ar" to "العربية"),
                                    vm.interfaceLanguage) { vm.changeInterfaceLanguage(it) }
                            }
                        }
                        item {
                            SettingsCard(label("No account required", "لا يحتاج حساب"),
                                label("Everything here is saved locally. Your lists and progress remain on your TV.",
                                    "كل الإعدادات محلية وتبقى قوائمك وتقدم المشاهدة محفوظة على التلفاز.")) {}
                        }
                    }
                    1 -> {
                        item {
                            SettingsCard(label("How should mature content be handled?", "شلون تتعامل ويه محتوى الكبار؟"),
                                label("Never hide movies or series. Only skip scenes with validated start/end timestamps.",
                                    "كل الأفلام والمسلسلات تبقى ظاهرة. التخطي فقط للمشاهد المحددة بتوقيت دقيق.")) {
                                SettingChoices(listOf(
                                    MatureAction.OFF.name to label("Off · no filtering", "إيقاف · بدون فلترة"),
                                    MatureAction.SKIP_SCENES.name to label("Skip marked scenes", "تخطي المشاهد المحددة"),
                                ), vm.matureAction.name) { vm.changeMatureAction(MatureAction.valueOf(it), ctx) }
                            }
                        }
                        item {
                            SettingsCard(label("Important: scene detection", "مهم: كشف المشاهد"),
                                label("Only timed scenes can be skipped. MovieHavenDB covers very few movies; no automatic mature-scene detection is available for most episodes. Unmarked scenes remain visible.",
                                    "ينتقل المشغل فقط فوق المشاهد المحددة بتوقيت. قاعدة بيانات المشاهد محدودة جداً، وباقي المشاهد تظهر بدون تغيير.")) {}
                        }
                    }
                    2 -> {
                        item {
                            SettingsCard(label("Community skip timestamps", "توقيتات تخطي المشاهد"),
                                label("Opt-in to SkipDB and IntroDB for intro, recap, outro and preview. Sends IMDb ID, season/episode and playback duration; not watch history.",
                                      "اختياري: استخدام SkipDB و IntroDB لتوقيتات المقدمة والملخص والنهاية. يرسل معرف العمل والحلقة والمدة فقط.")) {
                                SettingToggle(label("Use community scene markers", "استخدام توقيتات المجتمع"), communityMarkers) {
                                    communityMarkers = !communityMarkers
                                    prefs.communitySceneMarkersEnabled = communityMarkers
                                }
                                Text("SkipDB: ODbL 1.0 · IntroDB: API terms. Empty or mismatched markers never trigger a skip.",
                                    color = C.Dim, fontSize = 12.sp)
                            }
                        }
                        item {
                            SettingsCard(label("Playback quality", "دقة التشغيل"),
                                label("Choose a preferred maximum quality. Automatic follows network conditions.",
                                    "اختار الدقة المفضلة، أو تلقائي حتى يتكيف ويا سرعة الشبكة.")) {
                                SettingChoices(listOf("0" to label("Auto", "تلقائي"), "2160" to "4K",
                                    "1080" to "1080p", "720" to "720p", "480" to "480p"), quality.toString()) {
                                    quality = it.toInt(); prefs.maxQuality = quality
                                }
                                Text(label("Decoder: ${Capabilities.maxDecodableHeight()}p · Screen: ${Capabilities.maxDisplayHeight(ctx)}p",
                                    "قدرة فك الترميز: ${Capabilities.maxDecodableHeight()}p · دقة الشاشة: ${Capabilities.maxDisplayHeight(ctx)}p"),
                                    color = C.Dim, fontSize = 12.sp)
                            }
                        }
                        item {
                            SettingsCard(label("Episodes", "الحلقات"),
                                label("Control automatic playback between episodes.", "تحكم بالتشغيل التلقائي بين الحلقات.")) {
                                SettingToggle(label("Auto-play next episode", "تشغيل الحلقة التالية تلقائياً"), autoNext) {
                                    autoNext = !autoNext; prefs.autoPlayNextEnabled = autoNext
                                }
                                SettingToggle(label("Ask after three episodes", "اسأل بعد ثلاث حلقات"), bingeCheck) {
                                    bingeCheck = !bingeCheck; prefs.bingeCheckEnabled = bingeCheck
                                }
                            }
                        }
                    }
                    3 -> item {
                        SettingsCard(label("Preferred subtitle language", "لغة الترجمة المفضلة"),
                            label("Applied when a matching subtitle track is available.", "تستخدم إذا توفرت ترجمة مناسبة.")) {
                            SettingChoices(listOf("auto" to label("Automatic", "تلقائي"), "ar" to label("Arabic", "عربي"),
                                "en" to label("English", "إنكليزي"), "off" to label("Off", "إيقاف")), subtitle) {
                                subtitle = it; prefs.preferredSubtitleLanguage = it
                                if (it != "auto") prefs.subtitleLabel = ""
                            }
                        }
                    }
                    4 -> {
                        item {
                            SettingsCard(label("Home sections", "أقسام الصفحة الرئيسية"),
                                label("Hide sections without deleting your saved information.",
                                    "إخفاء الأقسام ما يحذف المعلومات المحفوظة.")) {
                                SettingToggle(label("Continue Watching row", "قسم متابعة المشاهدة"), vm.showContinueRow) {
                                    vm.updateHomeSections(continueRow = !vm.showContinueRow)
                                }
                                SettingToggle(label("My List row", "قسم قائمتي"), vm.showMyListRow) {
                                    vm.updateHomeSections(listRow = !vm.showMyListRow)
                                }
                                SettingToggle(label("Hide watched from discovery", "إخفاء المشاهد من الاستكشاف"), vm.hideWatchedDiscovery) {
                                    vm.updateHomeSections(hideWatched = !vm.hideWatchedDiscovery)
                                }
                            }
                        }
                        item {
                            SettingsCard(label("Android TV launcher", "واجهة Android TV"),
                                label("Show unfinished playback in the TV's Watch Next area where supported.",
                                    "إظهار متابعة المشاهدة على واجهة التلفاز إذا كانت مدعومة.")) {
                                SettingToggle(label("Show Watch Next", "إظهار متابعة المشاهدة"), tvHome) {
                                    tvHome = !tvHome; prefs.tvHomeEnabled = tvHome
                                    if (!tvHome) TvHomeIntegration.enqueueRemoveAll(ctx)
                                }
                            }
                        }
                    }
                    5 -> item {
                        SettingsCard(label("Download preferences", "تفضيلات التنزيل"),
                            label("Keep cellular or metered connections from starting downloads.",
                                "تمنع التحميل على الشبكات المدفوعة حسب الاستهلاك.")) {
                            SettingToggle(label("Unmetered networks only", "شبكات غير محدودة فقط"), unmetered) {
                                unmetered = !unmetered; prefs.downloadUnmeteredOnly = unmetered
                            }
                            Text(label("Download quality and storage are also chosen for each title.",
                                "تگدر تختار دقة ومكان الحفظ لكل عمل."), color = C.Dim, fontSize = 13.sp)
                        }
                    }
                    6 -> {
                        item {
                            val storage by produceState<StorageDiagnostics.Snapshot?>(null, ctx, storageRefresh) {
                                value = withContext(Dispatchers.IO) { StorageDiagnostics.snapshot(ctx) }
                            }
                            SettingsCard(label("Storage overview", "معلومات التخزين"),
                                label("Cleaning preloaded data does not remove your downloads or watch history.",
                                    "تنظيف الملفات المؤقتة ما يمسح التنزيلات أو سجل المشاهدة.")) {
                                if (storage == null) Text(label("Checking storage…", "جارٍ فحص التخزين…"), color = C.Dim)
                                else {
                                    val st = storage!!
                                    listOf(
                                        label("Available", "المساحة المتاحة") to StorageDiagnostics.readable(st.available),
                                        label("Artwork", "الصور المؤقتة") to StorageDiagnostics.readable(st.artwork),
                                        label("Preloaded videos", "الفيديو المؤقت") to StorageDiagnostics.readable(st.prebuffer),
                                        label("Catalog cache", "فهرس المحتوى") to StorageDiagnostics.readable(st.apiCache),
                                        label("Downloads", "التنزيلات") to st.downloadCount.toString(),
                                        label("Failed", "الفاشلة") to st.failedCount.toString(),
                                    ).forEach { (name, value) ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(name, color = C.Dim, fontSize = 14.sp)
                                            Text(value, color = Color.White, fontSize = 14.sp)
                                        }
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    AppButton(label("Refresh", "تحديث")) { storageRefresh++ }
                                    AppButton(label("Clear preloaded buffer", "مسح الفيديو المؤقت")) {
                                        scope.launch {
                                            withContext(Dispatchers.IO) { NextEpisodePreloader.clear(ctx) }
                                            storageRefresh++
                                        }
                                    }
                                }
                            }
                        }
                    }
                    7 -> item {
                        SettingsCard(label("Connection diagnostics", "فحص الاتصال"),
                            label("Check catalog access and the current video host independently.",
                                "افحص الوصول إلى الفهرس وخادم الفيديو بشكل منفصل.")) {
                            AppButton(if (diagnosing) label("Checking…", "جارٍ الفحص…")
                                else label("Run connection test", "افحص الاتصال")) {
                                if (!diagnosing) scope.launch {
                                    diagnosing = true
                                    diagnostic = label("Checking the available routes…", "جارٍ فحص الاتصال…")
                                    try {
                                        val id = prefs.recent().firstOrNull()?.id
                                            ?: vm.homeCache[0]?.rows.orEmpty().flatMap { it.items }
                                                .firstOrNull { it.kind == "1" && it.id.isNotBlank() }?.id
                                        diagnostic = Services.repo.networkReport(ctx, id)
                                    } catch (e: CancellationException) { throw e }
                                      catch (e: Exception) { diagnostic = "Error: ${e.javaClass.simpleName}" }
                                    finally { diagnosing = false }
                                }
                            }
                            if (diagnostic.isNotBlank()) Text(diagnostic, color = C.Dim, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, description: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(C.Panel, RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF2A3447), RoundedCornerShape(18.dp)).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        Text(description, fontSize = 14.sp, color = C.Dim)
        content()
    }
}

@Composable
private fun SettingChoices(options: List<Pair<String, String>>, value: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        options.chunked(3).forEach { group ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                group.forEach { (key, name) ->
                    AppButton((if (key == value) "✓  " else "") + name,
                        primary = key == value) { onSelect(key) }
                }
            }
        }
    }
}

@Composable
private fun SettingToggle(text: String, checked: Boolean, onToggle: () -> Unit) {
    AppButton((if (checked) "✓  " else "○  ") + text, primary = checked, onClick = onToggle)
}
