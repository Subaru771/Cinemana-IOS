package app.cinemanatv.util

import android.content.Context
import android.os.StatFs
import app.cinemanatv.Services
import java.io.File

/** Read-only storage stats; clearing never deletes offline HLS/DASH or MP4 downloads. */
object StorageDiagnostics {
    data class Snapshot(
        val available: Long,
        val total: Long,
        val prebuffer: Long,
        val artwork: Long,
        val apiCache: Long,
        val offlineSegments: Long,
        val savedDirect: Long,
        val downloadCount: Int,
        val failedCount: Int,
    )

    private fun directorySize(root: File): Long {
        if (!root.exists()) return 0
        var size = 0L
        val todo = ArrayDeque<File>()
        todo.add(root)
        var traversed = 0
        while (todo.isNotEmpty() && traversed++ < 12000) {
            val item = todo.removeFirst()
            if (item.isFile) size += item.length()
            else item.listFiles()?.forEach { todo.add(it) }
        }
        return size
    }

    fun snapshot(context: Context): Snapshot {
        val fs = StatFs(context.filesDir.absolutePath)
        val downloads = Services.prefs.downloads()
        return Snapshot(
            available = fs.availableBytes,
            total = fs.totalBytes,
            prebuffer = NextEpisodePreloader.bytes(context),
            artwork = directorySize(File(context.cacheDir, "artwork")),
            apiCache = directorySize(File(context.cacheDir, "api")),
            offlineSegments = directorySize(File(context.filesDir, "offline_segments")),
            savedDirect = downloads.sumOf { Downloads.local(context, it.id)?.length() ?: 0L },
            downloadCount = downloads.size,
            failedCount = downloads.count { Downloads.status(context, it.id).state == Downloads.State.FAILED },
        )
    }

    fun readable(bytes: Long): String = when {
        bytes >= (1024L * 1024 * 1024) -> "%.1f GB".format(java.util.Locale.US, bytes / (1024.0 * 1024 * 1024))
        bytes >= (1024L * 1024) -> "%.1f MB".format(java.util.Locale.US, bytes / (1024.0 * 1024))
        else -> "${bytes / 1024} KB"
    }
}
