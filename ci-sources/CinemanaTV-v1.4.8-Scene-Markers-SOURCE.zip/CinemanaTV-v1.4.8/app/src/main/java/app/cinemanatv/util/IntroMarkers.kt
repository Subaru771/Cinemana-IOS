package app.cinemanatv.util

/** Timestamps are provider-supplied only; unsupported/missing markers disable Skip Intro. */
fun parseIntroStamp(value: String?): Long? {
    if (value.isNullOrBlank()) return null
    val parts = value.trim().split(':')
    if (parts.size !in 1..3) return null
    val secs = parts.map { it.toDoubleOrNull() ?: return null }
    if (secs.any { it < 0.0 || !it.isFinite() }) return null
    val sum = if (parts.size == 1) secs[0]
        else if (parts.size == 2) secs[0] * 60 + secs[1]
        else secs[0] * 3600 + secs[1] * 60 + secs[2]
    // Single numeric fields are seconds. Explicit *_ms fields are always milliseconds.
    return (sum * 1000.0).toLong().takeIf { it in 0L..7_200_000L }
}

fun introWindow(startMs: Long?, endMs: Long?): LongRange? {
    if (startMs == null || endMs == null || startMs < 0L || endMs <= startMs ||
        endMs > 7_200_000L || endMs - startMs > 300_000L) return null
    return startMs until endMs
}
