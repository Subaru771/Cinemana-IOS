package app.cinemanatv.data

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.io.ByteArrayOutputStream

/** Shared semantics with Cinemana iOS. Times are milliseconds; no AI runs on the TV. */
data class ExternalSceneMarker(
    val kind: String, val startMs: Long, val endMs: Long,
    val source: String, val confidence: Double, val category: String = kind,
) {
    fun destination(positionMs: Long, durationMs: Long): Long? =
        endMs.takeIf { positionMs >= (startMs - 3000L).coerceAtLeast(0L) &&
            positionMs < endMs - 500L && endMs < durationMs - 1000L }
}

object ExternalSceneMarkers {
    private val imdbPattern = Regex("tt[0-9]{7,10}", RegexOption.IGNORE_CASE)
    private val types = listOf("intro", "recap", "outro", "preview")
    private val matureReasons = setOf("nudity", "sex", "sex_scene", "sexual", "sexual-content",
        "sexual_content", "explicit", "erotic", "intimacy", "sexuality")

    fun imdbID(raw: String?): String? = raw?.let { imdbPattern.find(it)?.value?.lowercase(Locale.US) }

    private fun JsonObject.objectOrNull(key: String): JsonObject? =
        get(key)?.takeIf { it.isJsonObject }?.asJsonObject
    private fun JsonObject.stringOrNull(key: String): String? =
        runCatching { get(key)?.takeIf { it.isJsonPrimitive }?.asString }.getOrNull()
    private fun JsonObject.numberOrNull(key: String): Double? =
        runCatching { get(key)?.takeIf { it.isJsonPrimitive }?.asDouble }.getOrNull()

    fun validated(marker: ExternalSceneMarker, durationMs: Long): Boolean {
        val length = marker.endMs - marker.startMs
        val maxMs = when(marker.kind) {
            "intro", "recap" -> 300_000L
            "mature" -> 1_200_000L
            else -> 900_000L
        }
        return durationMs >= 60_000L && marker.startMs >= 0 && length in 501L..maxMs &&
            marker.endMs < durationMs - 500L && marker.confidence in 0.0..1.0
    }

    fun skipDBURL(id: String?, season: Int, episode: Int, durationMs: Long): String? {
        val imdb = imdbID(id) ?: return null
        if (durationMs < 60_000L) return null
        return "https://api.skipdb.tv/api/segments?imdb_id=$imdb&duration=${(durationMs / 1000)}&adjust=conservative" +
            if (season > 0 && episode > 0) "&season=$season&episode=$episode" else ""
    }

    fun introDBURL(id: String?, season: Int, episode: Int): String? {
        val imdb = imdbID(id) ?: return null
        return "https://api.introdb.app/segments?imdb_id=$imdb" +
            if (season > 0 && episode > 0) "&season=$season&episode=$episode" else "&is_movie=true"
    }

    fun movieHavenURL(id: String?): String? {
        val imdb = imdbID(id) ?: return null
        return "https://raw.githubusercontent.com/arman-kh/MovieHavenDB/master/movies/$imdb.json"
    }

    fun skipDB(json: JsonElement?, durationMs: Long): List<ExternalSceneMarker> {
        val segments = runCatching { json?.asJsonObject?.objectOrNull("segments") }.getOrNull() ?: return emptyList()
        return types.mapNotNull { type ->
            val entry = segments.objectOrNull(type) ?: return@mapNotNull null
            val start = entry.numberOrNull("start_ms")?.toLong() ?: return@mapNotNull null
            val end = entry.numberOrNull("end_ms")?.toLong() ?: return@mapNotNull null
            val confidence = entry.numberOrNull("confidence") ?: return@mapNotNull null
            if (confidence < 0.70 || entry.stringOrNull("match") !in listOf("exact", "shifted")) return@mapNotNull null
            ExternalSceneMarker(type, start, end, "SkipDB (ODbL)", confidence)
                .takeIf { validated(it, durationMs) }
        }
    }

    fun introDB(json: JsonElement?, durationMs: Long): List<ExternalSceneMarker> {
        val data = runCatching { json?.asJsonObject }.getOrNull() ?: return emptyList()
        return listOf("intro", "recap", "outro", "post_credits").mapNotNull { type ->
            val entry = data.objectOrNull(type) ?: return@mapNotNull null
            val start = entry.numberOrNull("start_ms")?.toLong() ?: return@mapNotNull null
            val end = entry.numberOrNull("end_ms")?.toLong() ?: return@mapNotNull null
            val conf = entry.numberOrNull("confidence") ?: return@mapNotNull null
            if (conf < 0.80) return@mapNotNull null
            ExternalSceneMarker(if (type == "post_credits") "preview" else type,
                start, end, "IntroDB", conf).takeIf { validated(it, durationMs) }
        }
    }

    /** Only explicit sexual scene entries with skip=true and a matching runtime. */
    fun movieHaven(json: JsonElement?, id: String?, durationMs: Long): List<ExternalSceneMarker> {
        val data = runCatching { json?.asJsonObject }.getOrNull() ?: return emptyList()
        if (imdbID(id) == null || imdbID(data.stringOrNull("imdb_id")) != imdbID(id)) return emptyList()
        val stored = data.numberOrNull("duration") ?: return emptyList()
        if (kotlin.math.abs(stored * 1000 - durationMs.toDouble()) > 5000.0) return emptyList()
        val scenes = data.get("scenes")?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        return scenes.mapNotNull { value ->
            val row = value.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val reason = row.stringOrNull("reason")?.lowercase(Locale.US)?.replace(' ', '_') ?: return@mapNotNull null
            if (reason !in matureReasons || row.get("skip")?.takeIf { it.isJsonPrimitive }?.asBoolean != true)
                return@mapNotNull null
            val start = row.numberOrNull("start") ?: return@mapNotNull null
            val end = row.numberOrNull("end") ?: return@mapNotNull null
            ExternalSceneMarker("mature", (start * 1000).toLong(), (end * 1000).toLong(),
                "MovieHavenDB (CC BY 4.0)", 0.80, reason).takeIf { validated(it, durationMs) }
        }
    }

    fun merge(primary: List<ExternalSceneMarker>, fallback: List<ExternalSceneMarker>): List<ExternalSceneMarker> {
        val kinds = primary.mapTo(mutableSetOf()) { it.kind }
        return (primary + fallback.filter { kinds.add(it.kind) }).sortedBy { it.startMs }
    }
}

/** On-demand, bounded, cached and off-main-thread. No media bytes leave the device. */
object RemoteSceneMetadata {
    private data class Cached(val at: Long, val values: List<ExternalSceneMarker>)
    private val cache = LinkedHashMap<String, Cached>()

    private fun fetchJson(address: String): JsonElement? = try {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        connection.setRequestProperty("Accept", "application/json")
        try {
            if (connection.responseCode !in 200..299) null
            else connection.inputStream.use { input ->
                val buffer = ByteArray(8192)
                val output = ByteArrayOutputStream()
                var tooLarge = false
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (output.size() + read > 256000) { tooLarge = true; break }
                    output.write(buffer, 0, read)
                }
                if (tooLarge) null else JsonParser.parseString(String(output.toByteArray(), Charsets.UTF_8))
            }
        } finally { connection.disconnect() }
    } catch (_: Exception) { null }

    suspend fun load(imdbID: String?, season: Int, episode: Int, durationMs: Long,
                     community: Boolean, mature: Boolean): List<ExternalSceneMarker> = withContext(Dispatchers.IO) {
        val id = ExternalSceneMarkers.imdbID(imdbID) ?: return@withContext emptyList()
        if (durationMs < 60_000L) return@withContext emptyList()
        val isEpisode = season > 0 && episode > 0
        val key = "$id|$season|$episode|${durationMs/1000}|$community|$mature"
        synchronized(cache) {
            cache[key]?.takeIf { System.currentTimeMillis() - it.at < 3600_000L }?.values
        }?.let { return@withContext it }
        var found = emptyList<ExternalSceneMarker>()
        if (community) {
            ExternalSceneMarkers.skipDBURL(id, season, episode, durationMs)?.let { url ->
                found = ExternalSceneMarkers.skipDB(fetchJson(url), durationMs)
            }
            if (found.size < 4) ExternalSceneMarkers.introDBURL(id, season, episode)?.let { url ->
                found = ExternalSceneMarkers.merge(found, ExternalSceneMarkers.introDB(fetchJson(url), durationMs))
            }
        }
        if (mature && !isEpisode) ExternalSceneMarkers.movieHavenURL(id)?.let { url ->
            found = found + ExternalSceneMarkers.movieHaven(fetchJson(url), id, durationMs)
        }
        synchronized(cache) {
            cache[key] = Cached(System.currentTimeMillis(), found)
            while (cache.size > 30) cache.remove(cache.keys.first())
        }
        found
    }
}
