package app.cinemanatv.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EpisodeArtworkTest {
    @Test fun prefersFullResolutionToTinyThumbnail() {
        val v = Video(imgObjUrl="https://example.test/full.jpg", imgThumbObjUrl="https://example.test/low.jpg", imgMediumThumbObjUrl="https://example.test/medium.jpg")
        assertEquals("https://example.test/full.jpg", v.episodeArtwork)
        // Other UI surfaces preserve their prior image selector order.
        assertEquals("https://example.test/low.jpg", v.thumb)
    }

    @Test fun fallsBackToMediumAndNeverInventsArtwork() {
        assertEquals("https://example.test/medium.jpg", Video(imgMediumThumbObjUrl="https://example.test/medium.jpg").episodeArtwork)
        assertNull(Video().episodeArtwork)
    }
}
