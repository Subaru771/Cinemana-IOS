package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class SearchFiltersTest {
    private fun item(
        id: String, title: String, kind: String, year: String? = null,
        stars: String? = null, categories: String? = null,
    ) = Video(nb = id, enTitle = title, kind = kind, year = year, stars = stars,
        categories = categories?.let { JsonParser.parseString(it) })

    private val titles = listOf(
        item("1", "Omega", "1", "2026", "8.7", """["Action", "Drama"]"""),
        item("2", "Alpha", "2", "2018", "7.5", """["Drama"]"""),
        item("3", "Beta", "1", "2007", "6.1", """["Comedy"]"""),
        item("4", "No Metadata", "2"),
    )

    @Test fun filtersMoviesAndSeriesWithoutMixingThem() {
        assertEquals(listOf("1", "3"), SearchFiltering.apply(titles, SearchFilterState(kind = SearchKind.MOVIES)).map { it.id })
        assertEquals(listOf("2", "4"), SearchFiltering.apply(titles, SearchFilterState(kind = SearchKind.SERIES)).map { it.id })
    }

    @Test fun filtersByGenreAndYearAndRatingTogether() {
        val f = SearchFilterState(genre = "dRaMa", era = SearchEra.RECENT, minRating = 8)
        assertEquals(listOf("1"), SearchFiltering.apply(titles, f).map { it.id })
        assertEquals(listOf("Action", "Comedy", "Drama"), SearchFiltering.genres(titles))
    }

    @Test fun preservesUnknownMetadataUntilThatAttributeIsSelected() {
        assertEquals(4, SearchFiltering.apply(titles, SearchFilterState()).size)
        assertEquals(listOf("1", "2", "3"), SearchFiltering.apply(titles, SearchFilterState(minRating = 6)).map { it.id })
        assertFalse(SearchEra.TENS.includes(null))
        assertTrue(SearchEra.ALL.includes(null))
    }

    @Test fun sortModesPlaceMissingValuesAtEnd() {
        assertEquals(listOf("1", "2", "3", "4"), SearchFiltering.apply(titles, SearchFilterState(sort = SearchSort.NEWEST)).map { it.id })
        assertEquals(listOf("3", "2", "1", "4"), SearchFiltering.apply(titles, SearchFilterState(sort = SearchSort.OLDEST)).map { it.id })
        assertEquals(listOf("1", "2", "3", "4"), SearchFiltering.apply(titles, SearchFilterState(sort = SearchSort.RATING)).map { it.id })
        assertEquals(listOf("2", "3", "4", "1"), SearchFiltering.apply(titles, SearchFilterState(sort = SearchSort.TITLE)).map { it.id })
    }

    @Test fun handlesYearRangesAndRatingsWithComma() {
        assertEquals(2023, SearchFiltering.year("Released 2023 (US)"))
        assertNull(SearchFiltering.year("unknown"))
        assertEquals(7.9, SearchFiltering.stars("7,9/10") ?: 0.0, 0.001)
    }

    @Test fun exactTitleRanksFirstEvenWhenProviderReturnsItLast() {
        val noisy = listOf(
            item("1", "The Marine 5: Battleground", "1"),
            item("2", "The Mentalist: Behind the Scenes", "2"),
            item("3", "The Mentalist", "2"),
        )
        assertEquals("3", SearchFiltering.apply(noisy, SearchFilterState(), "the mentalist").first().id)
        assertTrue(TitleSearch.score("The Mentalist", "the mentalist") >
            TitleSearch.score("The Marine 5: Battleground", "the mentalist"))
    }

    @Test fun titleRankerHandlesPunctuationAndArticleVariants() {
        assertEquals(1000, TitleSearch.score("The Mentalist", "the MENTALIST"))
        assertTrue(TitleSearch.score("The Mentalist", "mentalist") >= 650)
        assertEquals(0, TitleSearch.score("The Marine", "the mentalist"))
        assertEquals(1000, TitleSearch.score("La.Cima", "la cima"))
    }

    @Test fun resetsAreFullyNeutral() {
        assertEquals(0, SearchFilterState().activeCount)
        assertEquals(5, SearchFilterState(SearchKind.SERIES, "Drama", SearchEra.TENS, 7, SearchSort.RATING).activeCount)
    }
}
