package app.cinemanatv.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class UiLanguageTest {
    @Test fun englishIsUnchanged() {
        assertEquals("Settings", translatedUi("Settings", "en"))
        assertEquals("Hello", translatedUi("Hello", "en"))
    }

    @Test fun arabicNavigationAndSelection() {
        assertEquals("الإعدادات", translatedUi("Settings", "ar"))
        assertEquals("Settings", translatedUi("Settings", "en"))
        assertEquals("✓ تلقائي", translatedUi("✓ Auto", "ar"))
        assertEquals("الرئيسية", translatedUi("Home", "ar"))
        assertEquals("إعادة ضبط (3)", translatedUi("Reset (3)", "ar"))
        assertEquals("الموسم 2", translatedUi("Season 2", "ar"))
    }

    @Test fun newWatchlistAndPlaybackLabelsTranslate() {
        assertEquals("قائمتي", translatedUi("My List", "ar"))
        assertEquals("أضف إلى قائمتي", translatedUi("Add to My List", "ar"))
        assertEquals("المشاهدة المتواصلة", translatedUi("Binge watching", "ar"))
        assertEquals("لغة الترجمة المفضلة", translatedUi("Preferred subtitle language", "ar"))
        assertEquals("My List", translatedUi("My List", "en"))
    }

    @Test fun filteredListMessagesAreTranslated() {
        val en = "Downloaded titles are hidden by content settings or awaiting rating checks. Files were not deleted."
        val ar = translatedUi(en, "ar")
        assertEquals(true, ar != en && "التنزيلات" in ar)
    }

    @Test fun dynamicLabelsAndServerContent() {
        assertEquals("5 من 20 نتائج", translatedUi("5 of 20 results", "ar"))
        assertEquals("التصنيف: جميع التصنيفات", translatedUi("Genre: Any genre", "ar"))
        assertEquals("Dune", translatedUi("Dune", "ar")) // don't alter provider titles
        assertEquals("يبدأ بعد 9 ثوانٍ", translatedUi("Starting in 9s", "ar"))
    }
}
