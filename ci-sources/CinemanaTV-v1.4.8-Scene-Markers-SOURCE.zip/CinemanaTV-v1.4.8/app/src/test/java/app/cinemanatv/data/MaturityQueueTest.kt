package app.cinemanatv.data

import org.junit.Assert.assertEquals
import org.junit.Test

class MaturityQueueTest {
    private data class Item(val id: String, val rated: Boolean = false)

    @Test fun processesEntireCatalogBeyondOldCap() {
        val items = (1..401).map { Item(it.toString()) }
        val pending = MaturityQueue.pending(items, { it.id }, { it.rated }) { false }
        assertEquals(401, pending.size)
        assertEquals("401", pending.last().id)
    }

    @Test fun skipsDuplicatesResolvedIdsAndKnownMetadata() {
        val items = listOf(Item(""), Item("a"), Item("a"), Item("b", true), Item("c"), Item("d"))
        val pending = MaturityQueue.pending(items, { it.id }, { it.rated }) { it == "d" }
        assertEquals(listOf("a", "c"), pending.map { it.id })
    }

    @Test fun neverMutatesOriginalQueue() {
        val items = listOf(Item("1"), Item("2"))
        MaturityQueue.pending(items, { it.id }, { it.rated }) { false }
        assertEquals(2, items.size)
    }
}
