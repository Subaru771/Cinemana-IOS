# CinemanaTV v1.4.7 verification report

## What changed
- Settings sidebar follows D-pad focus instead of waiting for OK; all AppButtons show a visible focus border.
- Search ranks full/exact titles before provider keyword matches, and hides weak matches behind an explicit Show related results control.
- Enter precise scene start/end timecodes before watching, or mark while watching; a HUD badge announces when **no** scene ranges are available.
- Slight pre-roll and 100 ms polling for *already saved* scene markers. External-player handoff is hidden during Skip Scenes mode.
- User records, local downloads and existing preferences remain in the same storage schema.

## Verified here
- TitleSearch and SceneSkipping Kotlin source compiled using kotlinc/JDK 21.
- 12 in-process logic assertions passed for title relevance and scene timecode parsing/skips.
- SearchFiltering (compiled using a minimal Video test stub) correctly ordered exact titles and excluded irrelevant suggestions.
- 13 Android XML documents parsed.
- Package archive integrity checked on ZIP creation.

## Not verified here
- Full Android Gradle build could not start: Gradle 8.14.3 download is unavailable to this container.
- Compose UI rendering/focus with real Google TV remote, API search results, and video playback have not been device-tested.
- Unit tests in the Android Gradle test suite have not been executed here.
- Skip Scenes cannot automatically identify mature scenes without externally provided, frame-accurate scene timestamp data. It skips only saved ranges; unmarked material remains visible.

## Test on TV
1. In Settings, press Down through the left categories without OK. Panel and selection must track focus.
2. Search for The Mentalist. Exact-title result must rank first; unrelated suggestions appear only after Show related results.
3. Enable Skip Scenes. For a title with no markers, the player must display an explicit unavailable/no timestamps status.
4. Player Settings → Scene markers. Save 00:30–00:40; play from 00:28 and verify seek skips the marked range.
5. Verify Hide Titles, Back/remote navigation, downloads, watch progress, and preference persistence.

To compile on Windows: `RUN-V1.4.7-FULL-TEST.cmd`; failure log at `output/CinemanaTV-v1.4.7-BUILD.log`.
