# CinemanaTV v1.4.7 — TV testing checklist

Build with `RUN-V1.4.7-FULL-TEST.cmd`, which captures errors in `output/CinemanaTV-v1.4.7-BUILD.log`. For detailed acceptance tests, see [TESTING.md](TESTING.md).

- [ ] Never uninstall an existing CinemanaTV installation to bypass a signature error without preserving its local data. A GitHub-runner debug key is not the same as your PC key.
- [ ] Startup, catalog refresh and Back work correctly on an actual Android/Google TV.
- [ ] All eight tabs and Search dropdown remain reachable with the D-pad, including in Arabic and 720p.
- [ ] Mature Off shows all titles. Hide Titles blocks recognized 16+/R/NC-17/TV-MA and adult-tagged titles; unrated content may still be visible. Skip Scenes does not hide any title and only skips verified locally saved ranges.
- [ ] Test Home, Movies, Series, search, My List, History, Downloads, Related, and episode/next-episode queues.
- [ ] A catalog with more than 160 titles eventually gets checked, barring provider outage; failed metadata requests don't silently show unclassified titles.
- [ ] Changing mature filters hides listings; it does not remove downloaded files or guarantee scene-level filtering.
- [ ] Test player startup, seeking, subtitles, 4K/1080p where available, audio, playback resume and next episode.
- [ ] Test offline behavior, slow Wi-Fi, download progress/cancel/remove and app relaunch.

These device-level checks have not been completed by this source package.

- [ ] TV Settings: D-pad can reach all sidebar categories and all setting controls. Changes survive app restart.
- [ ] Search is a standalone button, never a tab, and opens/closes with remote Back.
- [ ] Mark scene start/end in player, replay it, confirm only that exact range is skipped; remove marker and replay without skip.
