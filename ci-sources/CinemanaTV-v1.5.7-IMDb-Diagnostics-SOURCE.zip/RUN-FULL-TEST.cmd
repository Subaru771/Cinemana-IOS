@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CinemanaTV v1.5.7 - Verify and build
if not exist "output" mkdir "output"
set "LOG=%CD%\output\CinemanaTV-v1.5.7-BUILD.log"
echo =============================================================
echo        CinemanaTV v1.5.7 - Verify and build
 echo =============================================================
where java >nul 2>&1
if errorlevel 1 (
  echo ERROR: JDK 17 or newer is required.
  pause
  exit /b 1
)
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_SDK_ROOT if defined ANDROID_HOME set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist "gradlew.bat" (
  echo ERROR: gradlew.bat missing. Extract the whole ZIP.
  pause
  exit /b 1
)
echo Running full unit tests and assembling an optimized, locally debug-signed APK...
echo Output log: %LOG%
call gradlew.bat --no-daemon --stacktrace testDebugUnitTest assembleRelease > "%LOG%" 2>&1
if errorlevel 1 (
  echo BUILD FAILED: %LOG%
  powershell -NoProfile -Command "Get-Content -LiteralPath '%LOG%' -Tail 35" 2>nul
  pause
  exit /b 1
)
if not exist "app\build\outputs\apk\release\app-release.apk" (
  echo ERROR: Gradle finished but no APK exists. Read %LOG%
  pause
  exit /b 1
)
copy /y "app\build\outputs\apk\release\app-release.apk" "output\CinemanaTV-v1.5.7-test.apk" >nul
if errorlevel 1 (
  echo ERROR: Unable to copy APK into output folder.
  pause
  exit /b 1
)
echo SUCCESS: output\CinemanaTV-v1.5.7-test.apk
echo IMPORTANT: Only update an existing installation if the signing keys match.
echo Do not uninstall an existing app without backing up your local data.
pause
