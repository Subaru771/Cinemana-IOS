# Cinemana TV v1.5.7 — mature-skip diagnostics / IMDb identity

This release changes source code only until the Android CI build succeeds.

## What's new
- Reads IMDb IDs in explicit nested metadata envelopes; never guesses from title/year/description/related titles.
- Movie Details explains the *reason* for an unknown badge, identifies the IMDb ID and the per-source check result.
- Movie Details can retry the check and save a viewer-confirmed IMDb ID (`tt1234567`) if Cinemana omits one.
- The same persisted movie ID is used for badge checks and actual playback marker lookup.
- Retains the CleanStream runtime safeguards; unreviewed timestamps remain advisory and may differ across cuts.
- Added parser regression tests for nested IDs and false-positive prevention.

## How to verify
1. In TV Settings, enable Skip Scenes.
2. Open a movie. Note the new status explanation under its badge.
3. If IMDb ID is missing, use **Enter IMDb ID** with the exact title from imdb.com.
4. Press **Retry skip check**, play a supported movie and check logs via `adb logcat -s MatureSkip:D '*:S'`.
5. Confirm the player seeks correctly; published timestamps alone do not guarantee scene coverage.

## What cannot be claimed
- Cinemana's production API JSON field names have not been verified against a live response.
- No automatic matching based only on title/year, due to wrong-film skip risk.
- Full Android compile / TV playback test is required before publishing as a verified APK.
