# v1.5.7 build and validation

- `MAKE-APK.cmd` builds a Windows debug-key-signed release APK with tests.
- `./gradlew :app:testDebugUnitTest :app:assembleRelease` runs the Gradle build.
- Android SDK 35, JDK 17 and network access for Gradle are required for the first build.
- A GitHub Actions workflow is provided to make the APK artifact.
- Debug-key signing means it cannot update APKs signed with a different key; the user's old app data may be affected by uninstalling. Do not uninstall unless you've backed up app data.

## Mature-skip testing
1. Play a film whose IMDb ID is known (e.g. `tt0111161`).
2. Check the detail view for the IMDb ID and per-source result.
3. Toggle `Skip Scenes`; observe seek actions in `adb logcat -s MatureSkip:D '*:S'`.
4. If Cinemana supplies no IMDb ID, enter the one from the film's official IMDb page using the Detail screen editor. A wrong ID can trigger an incorrect skip.
5. Badges indicate **published community timestamps**, not verified coverage or a guarantee of safety.
