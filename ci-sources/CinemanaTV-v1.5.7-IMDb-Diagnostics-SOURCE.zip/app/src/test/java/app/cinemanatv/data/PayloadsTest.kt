package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class PayloadsTest {
    private fun json(s: String) = JsonParser.parseString(s)

    @Test fun parsesReferenceModelFieldNames() {
        val result = Payloads.videos(json("""
            {"result":{"items":[
              {"id":472,"englishTitle":"Arrival","arabicTitle":"وصول","imageThumbMediumUrl":"https://img.example/poster.jpg"},
              {"nb":"473","ar_title":"فيلم عربي","imgMediumThumbObjUrl":"https://img.example/ar.jpg"}
            ]}}
        """))
        assertEquals(2, result.size)
        assertEquals("472", result[0].id)
        assertEquals("Arrival", result[0].title)
        assertEquals("https://img.example/poster.jpg", result[0].poster)
        assertEquals("فيلم عربي", result[1].title)
    }

    @Test fun ignoresNonVideosAndDeduplicates() {
        val result = Payloads.videos(json("""
            {"data":[{"id":"4","title":"Real"},{"id":"4","title":"Duplicate"},{"irrelevant":"ignored"},{"id":"5"}]}
        """))
        assertEquals(1, result.size)
        assertEquals("Real", result.first().title)
    }

    @Test fun handlesNestedQualityLadderAnd4K() {
        val options = Payloads.sources(json("""
          {"videoFile":{"transcodedFiles":[
            {"resolution":"1920x1080","videoUrl":"https://cdn.example/1080.mp4"},
            {"name":"4K UHD","url":"https://cdn.example/2160.m3u8"},
            {"name":"720p","file":"https://cdn.example/720.mp4"}
          ]}}
        """))
        assertEquals(listOf(2160, 1080, 720), options.map { it.height })
        assertEquals("4K (2160p)", options[0].label)
    }

    @Test fun acceptsQualityMap() {
        val options = Payloads.sources(json("""{"qualities":{"2160p":"https://cdn.example/4k.m3u8", "1080p":"https://cdn.example/hd.mp4"}}"""))
        assertEquals(listOf(2160, 1080), options.map { it.height })
    }

    @Test fun unknownResolutionStillProducesPlayableSource() {
        val options = Payloads.sources(json("""[{"url":"https://cdn.example/video.mp4"}]"""))
        assertEquals(1, options.size)
        assertEquals(0, options[0].height)
        assertEquals("Auto", options[0].label)
    }

    @Test fun rejectsLocalFileUrlsAndParsesSubtitles() {
        assertEquals(0, Payloads.sources(json("""[{"name":"4K","url":"file:///etc/passwd"}]""")).size)
        val subs = Payloads.subtitles(json("""
            {"data":{"enTranslationFilePath":"https://cdn.example/en.vtt", "translations":[
               {"name":"العربية","file":"https://cdn.example/ar.srt"}
            ]}}
        """))
        assertEquals(2, subs.size)
        assertEquals("text/vtt", subs.first().mime)
        assertEquals("application/x-subrip", subs.last().mime)
    }

    @Test fun neverTreatsPostersAsStreams() {
        val options = Payloads.sources(json("""
            {"id":"9","title":"X","imgObjUrl":"https://img.example/p.jpg","imgThumbObjUrl":"https://img.example/t.png",
             "videoFile":{"transcodedFiles":[{"resolution":"720","videoUrl":"https://cdn.example/720.mp4"}]}}
        """))
        assertEquals(listOf("https://cdn.example/720.mp4"), options.map { it.url })
    }

    @Test fun progressiveFlagExcludesPlaylists() {
        assertTrue(QualityOption(720, "https://cdn.example/a.mp4?x=1").progressive)
        assertFalse(QualityOption(720, "https://cdn.example/a.m3u8").progressive)
    }

    @Test fun detailPicksUpCertificateAndAdultFlagFromRawRecord() {
        val fallback = Video(nb = "9", enTitle = "X")
        val d = Payloads.detail(json("""{"nb":"9","en_title":"X","mpaa_rating":"R","is_adult":"1"}"""), fallback)
        assertEquals("R", d.filmRating)
        assertTrue(d.adult?.asString == "1")
    }

    @Test fun nestedImdbReferenceIsResolvedFromProviderDetail() {
        val fallback = Video(nb = "25", enTitle = "Movie")
        val result = Payloads.detail(json("""{
          "data":{"video":{"nb":"25","en_title":"Movie",
            "external_ids":{"IMDb":{"url":"https://www.imdb.com/title/tt0111161/"}}}}
        }"""), fallback)
        assertEquals("tt0111161", result.imdbRef)
    }

    @Test fun imdbFromAnotherMovieOrDescriptionIsNotGuessed() {
        val fallback = Video(nb = "25", enTitle = "Movie")
        val result = Payloads.detail(json("""{
          "data":{"video":{"nb":"25","en_title":"Movie","description":"tt0111161"}},
          "related":[{"imdbId":"tt0266543"}]
        }"""), fallback)
        assertNull(result.imdbRef)
    }

    @Test fun simpleAndMalformedImdbIdentityAreSeparated() {
        assertEquals("tt0111161", Payloads.imdbReference(json("""{"data":{"imdb_id":"tt0111161"}}""")))
        assertNull(Payloads.imdbReference(json("""{"data":{"imdbRating":8.3,"url":"https://bad.example/tt0111161"}}""")))
    }

    @Test fun arabicOnlyGenreTagIsVisibleToTheFilter() {
        val v = Payloads.videos(json("""[{"nb":"1","en_title":"T","categories":[{"id":"5","ar_title":"للكبار فقط"}]}]""")).first()
        assertTrue(v.allTags.contains("للكبار فقط"))
        assertFalse(MediaContentFilter.allowed(v, ContentFilterMode.HIDE_MATURE))
    }
}
