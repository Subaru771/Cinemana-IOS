package app.cinemanatv.ui

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import android.os.SystemClock
import android.content.Context
import kotlinx.coroutines.delay
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import app.cinemanatv.Services
import app.cinemanatv.data.HomeData
import app.cinemanatv.data.Video
import app.cinemanatv.data.ContentFilterMode
import app.cinemanatv.data.MediaContentFilter
import app.cinemanatv.data.MaturityQueue
import app.cinemanatv.data.SearchFilterState
import app.cinemanatv.data.SearchFacet
import app.cinemanatv.data.MatureSkipAvailability
import app.cinemanatv.data.MatureSkipStatus
import app.cinemanatv.data.ExternalSceneMarkers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.runtime.mutableStateMapOf
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed interface Screen {
    data object Main : Screen
    /** [queue]/[index] are set when the title is one episode picked from a series page. */
    data class Detail(val video: Video, val queue: List<Video>? = null, val index: Int = 0) : Screen
    data class Play(val queue: List<Video>, val index: Int) : Screen
}

class AppViewModel : ViewModel() {
    /** Startup loads the same real HomeData consumed by HomeScreen; no fake assets. */
    var initialCatalogReady by mutableStateOf(false)
        private set

    // Splash has a ~0.65-second minimum and a 1.9-second maximum. Catalog loading
    // continues on the Home screen if the source is slow or unavailable.
    var splashFinished by mutableStateOf(false)
        private set

    var interfaceLanguage by mutableStateOf(Services.prefs.interfaceLanguage)
        private set

    fun changeInterfaceLanguage(language: String) {
        val normalized = if (language == "ar") "ar" else "en"
        Services.prefs.interfaceLanguage = normalized
        interfaceLanguage = normalized
    }

    var contentFilterMode by mutableStateOf(ContentFilterMode.OFF)
        private set
    var matureAction by mutableStateOf(Services.prefs.matureAction)
        private set

    fun changeMatureAction(value: app.cinemanatv.data.MatureAction, context: Context) {
        if (matureAction == value) return
        matureAction = value
        Services.prefs.matureAction = value
        contentFilterMode = Services.prefs.contentFilterMode
        // Clear launcher recommendations previously published under a different filter.
        app.cinemanatv.util.TvHomeIntegration.enqueueRemoveAll(context.applicationContext)
        if (stack.size > 1) { stack.clear(); stack.add(Screen.Main) }
    }

    fun changeContentFilterMode(value: ContentFilterMode, context: Context) {
        if (contentFilterMode == value) return
        contentFilterMode = value
        Services.prefs.contentFilterMode = value
        // External launcher cards may contain old restricted titles. Remove stale cards.
        app.cinemanatv.util.TvHomeIntegration.enqueueRemoveAll(context.applicationContext)
        if (stack.size > 1) { stack.clear(); stack.add(Screen.Main) }
    }

    var showContinueRow by mutableStateOf(Services.prefs.showContinueRow)
    var showMyListRow by mutableStateOf(Services.prefs.showMyListRow)
    var hideWatchedDiscovery by mutableStateOf(Services.prefs.hideWatchedDiscovery)
    fun updateHomeSections(continueRow: Boolean = showContinueRow, listRow: Boolean = showMyListRow,
                           hideWatched: Boolean = hideWatchedDiscovery) {
        showContinueRow = continueRow; showMyListRow = listRow; hideWatchedDiscovery = hideWatched
        Services.prefs.showContinueRow = continueRow
        Services.prefs.showMyListRow = listRow
        Services.prefs.hideWatchedDiscovery = hideWatched
    }

    // Preserve the Settings category across search opens and page transitions.
    var settingsCategory by androidx.compose.runtime.mutableIntStateOf(0)

    var tab by mutableStateOf(0)
    /** The tab that was showing before the search panel dropped down over it. */
    var lastTab = 0

    // ---- Optional mature-scene marker BADGES (distinct from age/content restrictions) ----
    // These are catalogue indications only. Playback revalidates the stream runtime before skip.
    private val matureSkipStates = mutableStateMapOf<String, MatureSkipStatus>()
    private val matureSkipExpires = mutableMapOf<String, Long>()
    private val matureSkipReports = mutableStateMapOf<String, app.cinemanatv.data.MatureSkipReport>()
    private val matureSkipIssues = mutableStateMapOf<String, String>()
    private val matureSkipLookedUpImdb = mutableMapOf<String, String?>()

    fun imdbId(video: Video): String? =
        ExternalSceneMarkers.imdbID(Services.prefs.imdbOverride(video.id))
            ?: ExternalSceneMarkers.imdbID(video.imdbRef)

    fun skipExplanation(video: Video): String {
        if (Services.prefs.hasSceneRanges(video.id)) return "Saved local scene markers · check against this video edition"
        matureSkipIssues[video.id]?.let { return it }
        val report = matureSkipReports[video.id]
        if (report != null) {
            fun label(status: MatureSkipStatus) = when(status) {
                MatureSkipStatus.LISTED -> "timestamps published"
                MatureSkipStatus.NOT_LISTED -> "no eligible markers"
                else -> "could not check"
            }
            return "IMDb ${report.imdbId} · CleanStream: ${label(report.cleanStream)} · MovieHavenDB: ${label(report.movieHaven)}"
        }
        return when (skipStatus(video)) {
            MatureSkipStatus.CHECKING -> "Checking Cinemana IMDb ID and skip databases…"
            MatureSkipStatus.UNKNOWN -> "Not checked · or IMDb ID / skip database unavailable"
            MatureSkipStatus.NOT_LISTED -> "No published mature skip markers found"
            MatureSkipStatus.LISTED -> "Community timestamps published · stream runtime checked at playback"
        }
    }

    fun resetMatureSkip(videoId: String) {
        matureSkipExpires.remove(videoId)
        matureSkipReports.remove(videoId)
        matureSkipIssues.remove(videoId)
        matureSkipLookedUpImdb.remove(videoId)
        matureSkipStates.remove(videoId)
    }

    private val skipLookupSlots = Semaphore(3) // Never flood third-party databases on a TV.
    var skipSearchBusy by mutableStateOf(false)
    /** Identifies the newest search scan so a cancelled older scan can't clear the busy flag. */
    var skipScanToken = 0

    fun skipStatus(video: Video): MatureSkipStatus {
        if (Services.prefs.hasSceneRanges(video.id))
            return MatureSkipStatus.LISTED
        return matureSkipStates[video.id] ?: MatureSkipStatus.UNKNOWN
    }

    suspend fun ensureMatureSkip(video: Video) {
        val id = video.id
        if (id.isBlank()) return
        if (Services.prefs.hasSceneRanges(id)) {
            matureSkipStates[id] = MatureSkipStatus.LISTED
            return
        }
        val knownImdb = imdbId(video)
        val changedImdb = knownImdb != null && knownImdb != matureSkipLookedUpImdb[id]
        val now = SystemClock.elapsedRealtime()
        if (!changedImdb && ((matureSkipExpires[id] ?: 0L) > now || matureSkipStates[id] == MatureSkipStatus.CHECKING)) return
        skipLookupSlots.withPermit {
            val freshImdb = imdbId(video)
            val newIdentity = freshImdb != null && freshImdb != matureSkipLookedUpImdb[id]
            if (!newIdentity && ((matureSkipExpires[id] ?: 0L) > SystemClock.elapsedRealtime() ||
                matureSkipStates[id] == MatureSkipStatus.CHECKING)) return@withPermit
            // The existing mature marker sources are movie-only. Treat series/episode results
            // as unknown instead of inferring a status from the parent title.
            if (video.kind == "2" || video.episodeNumber > 0 || video.rootSeries != null) {
                matureSkipStates[id] = MatureSkipStatus.UNKNOWN
                matureSkipIssues[id] = "Episode-specific mature skip coverage is not verified"
                matureSkipExpires[id] = SystemClock.elapsedRealtime() + 30 * 60_000L
                return@withPermit
            }
            matureSkipStates[id] = MatureSkipStatus.CHECKING
            try {
                val directId = imdbId(video)
                val detailed = if (directId == null) withTimeoutOrNull(7_000L) { Services.repo.infoOrNull(video) } else null
                val imdb = directId ?: detailed?.let(::imdbId)
                matureSkipLookedUpImdb[id] = imdb
                if (imdb == null) {
                    matureSkipReports.remove(id)
                    matureSkipIssues[id] = if (detailed == null) "No IMDb ID found (Cinemana details unavailable or missing)"
                        else "No IMDb ID supplied by Cinemana for this title"
                } else {
                    matureSkipIssues.remove(id)
                }
                val report = if (imdb == null) null else withTimeoutOrNull(10_000L) { MatureSkipAvailability.checkReport(imdb) }
                if (report != null) matureSkipReports[id] = report
                else matureSkipReports.remove(id)
                if (imdb != null && report == null) matureSkipIssues[id] = "Could not reach skip databases; retry later"
                val status = report?.status ?: MatureSkipStatus.UNKNOWN
                matureSkipStates[id] = status
                matureSkipExpires[id] = SystemClock.elapsedRealtime() + when (status) {
                    MatureSkipStatus.LISTED -> 45 * 60_000L
                    MatureSkipStatus.NOT_LISTED -> 10 * 60_000L
                    else -> 2 * 60_000L
                }
            } catch (c: CancellationException) {
                matureSkipStates.remove(id)
                throw c
            } catch (_: Exception) {
                matureSkipStates[id] = MatureSkipStatus.UNKNOWN
                matureSkipIssues[id] = "Skip check failed; try again"
                matureSkipExpires[id] = SystemClock.elapsedRealtime() + 2 * 60_000L
            }
        }
    }

    suspend fun checkSearchMatureSkip(items: List<Video>) = coroutineScope {
        // The Search filter checks the FULL returned list. Unchecked rows must not be
        // misrepresented as negative results while this progressive scan runs.
        for (group in items.distinctBy { it.id }.chunked(3)) {
            coroutineScope { group.map { video -> async { ensureMatureSkip(video) } }.awaitAll() }
        }
    }

    // ---- Mature-content filter -------------------------------------------------------------
    // Catalog list payloads usually carry no age certificate or genre tags, so a filter that
    // only looks at list items lets everything through. Titles are therefore resolved once via
    // their detail record (cached on disk) and hidden until that check finishes.
    private val maturityMeta = mutableStateMapOf<String, Video>()
    private val gson = Gson()

    private fun hasMeta(v: Video) = v.filmRating != null || v.categories != null || v.adult != null

    private fun loadStoredMeta(id: String): Video? = runCatching {
        val o = JsonParser.parseString(Services.prefs.maturityCached(id) ?: return null).asJsonObject
        Video(
            nb = id,
            filmRating = o.get("r")?.takeIf { it.isJsonPrimitive }?.asString,
            categories = o.get("c")?.takeIf { !it.isJsonNull },
            adult = o.get("a")?.takeIf { !it.isJsonNull },
        )
    }.getOrNull()

    private fun storeMeta(v: Video) {
        val o = com.google.gson.JsonObject()
        v.filmRating?.let { o.addProperty("r", it) }
        v.categories?.let { o.add("c", it) }
        v.adult?.let { o.add("a", it) }
        Services.prefs.maturityStore(v.id, gson.toJson(o))
    }

    /** The video with any resolved certificate / genre / adult metadata merged in. */
    fun resolve(v: Video): Video {
        val m = maturityMeta[v.id] ?: return v
        return v.copy(
            filmRating = v.filmRating ?: m.filmRating,
            categories = v.categories ?: m.categories,
            adult = v.adult ?: m.adult,
        )
    }

    /** Applies the content setting. Unchecked titles stay hidden until resolveMaturity() has run. */
    fun visible(items: List<Video>, parent: Video? = null): List<Video> {
        if (contentFilterMode == ContentFilterMode.OFF) return items
        return items.map(::resolve).filter { isVerifiedAllowed(it, parent) }
    }

    private fun isVerifiedAllowed(video: Video, parent: Video? = null): Boolean {
        if (contentFilterMode == ContentFilterMode.OFF) return true
        val resolved = resolve(video)
        val inherited = parent ?: resolved.rootSeriesInfo
        val hasCertificateOrTags = hasMeta(resolved) ||
            maturityMeta.containsKey(resolved.id) || (inherited != null && hasMeta(inherited))
        return hasCertificateOrTags && MediaContentFilter.allowed(resolved, contentFilterMode, parent)
    }

    var maturityBusy by mutableStateOf(false)
        private set

    // Search, Home and Downloads can ask for ratings at the same time.
    // Serialize lookups and skip IDs resolved by earlier callers.
    private val maturityLookupMutex = Mutex()

    suspend fun resolveMaturity(items: List<Video>) {
        if (contentFilterMode == ContentFilterMode.OFF || items.isEmpty()) return
        maturityLookupMutex.withLock {
            if (contentFilterMode == ContentFilterMode.OFF) return@withLock
            // No 160-title cap. Keep the user's complete currently loaded list eligible for
            // classification; process in small batches so TV UIs stay responsive.
            val todo = MaturityQueue.pending(items, { it.id }, { hasMeta(it) }) {
                maturityMeta.containsKey(it)
            }
            if (todo.isEmpty()) return@withLock
            maturityBusy = true
            try {
                val missing = ArrayList<Video>()
                todo.forEach { v ->
                    val cached = loadStoredMeta(v.id)
                    if (cached != null) maturityMeta[v.id] = cached else missing.add(v)
                }
                var consecutiveFailedBatches = 0
                for (chunk in missing.chunked(4)) {
                    if (contentFilterMode == ContentFilterMode.OFF) break
                    val resolved = coroutineScope {
                        chunk.map { v -> async {
                            // infoOrNull distinguishes a failed network request from a valid
                            // detail response with no certificate. Cancellation is propagated.
                            v to withTimeoutOrNull(9_000L) { Services.repo.infoOrNull(v) }
                        } }.awaitAll()
                    }
                    var successes = 0
                    resolved.forEach { (v, info) ->
                        if (info == null) return@forEach // fail closed; retry on a future visit
                        successes++
                        val meta = Video(nb = v.id, filmRating = info.filmRating,
                            categories = info.categories, adult = info.adult)
                        if (hasMeta(meta)) storeMeta(meta)
                        maturityMeta[v.id] = meta
                    }
                    // Don't hammer the provider through a large catalog if it has gone down.
                    // Unresolved titles remain hidden and can be retried later.
                    consecutiveFailedBatches = if (successes == 0) consecutiveFailedBatches + 1 else 0
                    if (consecutiveFailedBatches >= 2) break
                }
            } finally {
                maturityBusy = false
            }
        }
    }
    val stack = mutableStateListOf<Screen>(Screen.Main)
    val homeCache = mutableMapOf<Int, HomeData>() // key: 0 = all, 1 = movies, 2 = series
    /** When each cached catalog was last confirmed by the network (elapsed ms), by key. */
    val homeFreshAt = mutableMapOf<Int, Long>()
    fun isHomeFresh(key: Int): Boolean =
        homeFreshAt[key]?.let { android.os.SystemClock.elapsedRealtime() - it < 10 * 60_000L } == true
    fun markHomeFresh(key: Int) { homeFreshAt[key] = android.os.SystemClock.elapsedRealtime() }

    init {
        viewModelScope.launch {
            val startedAt = SystemClock.elapsedRealtime()
            delay(650L) // just long enough for the logo to register; the catalog usually is on disk already
            while (!initialCatalogReady && SystemClock.elapsedRealtime() - startedAt < 1_900L) {
                delay(50L)
            }
            splashFinished = true
        }
        viewModelScope.launch {
            try {
                // 1) Last session's catalog is on disk: show it immediately. HomeScreen then
                //    refreshes it in the background (stale-while-revalidate).
                val cached = Services.repo.cachedHome(null)
                if (cached != null) {
                    homeCache[0] = cached
                    initialCatalogReady = true
                } else {
                    // 2) First run: try to warm data, but never hold the splash over 2 seconds.
                    withTimeoutOrNull(1_900L) {
                        val result = Services.repo.loadHome(null)
                        if (result.rows.isNotEmpty()) { homeCache[0] = result; markHomeFresh(0) }
                    }
                }
            } catch (c: CancellationException) { throw c }
              catch (_: Exception) { /* Home screen owns retry and diagnostics */ }
            finally {
                initialCatalogReady = true
                app.cinemanatv.util.PerformanceMetrics.catalogReady()
            }
        }
    }


    // UI state that must survive opening a title and coming back (scroll position, focus, search).
    val homeFocus = mutableMapOf<Int, Pair<String, Int>>() // key -> (row title, column)
    private val colStates = mutableMapOf<Int, LazyListState>()
    private val rowStates = mutableMapOf<String, LazyListState>()
    fun colState(key: Int) = colStates.getOrPut(key) { LazyListState() }
    fun rowState(key: Int, row: String) = rowStates.getOrPut("$key:$row") { LazyListState() }
    var searchQuery by mutableStateOf("")
    var searchDone by mutableStateOf("")           // the query `searchResults` belongs to
    var searchResults by mutableStateOf<List<Video>?>(null)
    val searchGrid = LazyGridState()
    // Kept in ViewModel so filters survive opening a title and pressing Back.
    var searchFilters by mutableStateOf(SearchFilterState())
    var searchFiltersOpen by mutableStateOf(false)
    var searchFacet by mutableStateOf<SearchFacet?>(null)

    fun push(s: Screen) {
        when (s) {
            Screen.Main -> stack.add(s)
            is Screen.Detail -> if (isVerifiedAllowed(s.video)) stack.add(s)
            is Screen.Play -> {
                val selected = s.queue.getOrNull(s.index) ?: return
                if (!isVerifiedAllowed(selected)) return
                val allowedQueue = s.queue.map(::resolve).filter { isVerifiedAllowed(it) }
                val nextIndex = allowedQueue.indexOfFirst { it.id == selected.id }
                if (nextIndex >= 0) stack.add(Screen.Play(allowedQueue, nextIndex))
            }
        }
    }
    fun pop(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.lastIndex); return true
    }
}
