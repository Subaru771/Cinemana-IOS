package app.cinemanatv.data

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import java.net.URI

/** Pure parsing helpers; do not silently mistake an unknown response envelope for an empty catalog. */
object Payloads {
    private val gson = Gson()
    private val listKeys = listOf("data", "result", "results", "items", "videos", "video", "movies", "films", "banner", "banners", "rows", "content", "list", "episodes", "season", "files", "qualities", "transcodedFiles", "transcoddedFiles")
    private fun text(o: JsonObject, vararg keys: String): String? = keys.firstNotNullOfOrNull { key ->
        o.get(key)?.takeIf { it.isJsonPrimitive }?.asString?.trim()?.takeIf(String::isNotEmpty)
    }
    private fun validUrl(raw: String?): String? = raw?.takeIf { input ->
        runCatching { val u = URI(input); (u.scheme == "https" || u.scheme == "http") && !u.host.isNullOrBlank() }.getOrDefault(false)
    }
    private val imageExt = Regex("\\.(jpe?g|png|webp|gif|bmp|svg)$", RegexOption.IGNORE_CASE)
    private val qualityKey = Regex("^(\\d{3,4}p?|\\d{3,4}x\\d{3,4}|[24]k|uhd|fhd|hd|sd)$", RegexOption.IGNORE_CASE)
    /** A playable URL: valid http(s) and not a poster/thumbnail. */
    private fun videoUrl(raw: String?): String? = validUrl(raw)?.takeIf { !imageExt.containsMatchIn(it.substringBefore('?').substringBefore('#')) }
    private fun parseVideo(element: JsonElement): Video? = runCatching {
        if (!element.isJsonObject) return@runCatching null
        val video = gson.fromJson(element, Video::class.java)
        video.takeIf { it.id.isNotBlank() && it.title.isNotBlank() }
    }.getOrNull()

    /** Bound depth prevents accidental recursive traversal of large or cyclic-looking envelopes. */
    fun videos(root: JsonElement?, maxItems: Int = 120): List<Video> {
        if (root == null || root.isJsonNull) return emptyList()
        val results = LinkedHashMap<String, Video>()
        fun visit(e: JsonElement, depth: Int) {
            if (depth > 5 || results.size >= maxItems) return
            when {
                e.isJsonArray -> e.asJsonArray.forEach { visit(it, depth + 1) }
                e.isJsonObject -> {
                    val o = e.asJsonObject
                    parseVideo(e)?.let { results.putIfAbsent(it.id, it) }
                    listKeys.forEach { k -> o.get(k)?.let { visit(it, depth + 1) } }
                }
            }
        }
        visit(root, 0)
        return results.values.toList()
    }

    private val certKey = Regex("(?i)^(film_?rating|content_?rating|age_?rating|certification|certificate|parental_?rating|mpaa(_?rating)?|age_?limit|min_?age|minimum_?age|age_?restriction|restriction)$")
    private val adultKey = Regex("(?i)^(is_?adult|adult|adult_?content|explicit|is_?explicit|mature|is_?mature|isForAdults|for_?adults)$")
    private val truthy = setOf("true", "1", "yes", "y")

    /** Certificate / adult flag found anywhere in the raw detail record (bounded depth). */
    internal fun maturitySignals(root: JsonElement?): Pair<String?, JsonElement?> {
        var cert: String? = null
        var adult: JsonElement? = null
        fun visit(e: JsonElement, depth: Int) {
            if (depth > 3) return
            when {
                e.isJsonArray -> e.asJsonArray.take(4).forEach { visit(it, depth + 1) }
                e.isJsonObject -> e.asJsonObject.entrySet().forEach { (k, v) ->
                    if (v.isJsonPrimitive) {
                        val text = v.asString.trim()
                        if (cert == null && certKey.matches(k) && text.isNotEmpty()) cert = text
                        if (adultKey.matches(k) && text.lowercase() in truthy) adult = v
                    } else if (k != "categories" && k != "genres") visit(v, depth + 1)
                }
            }
        }
        root?.let { visit(it, 0) }
        return cert to adult
    }

    /** Extract IDs only from explicitly IMDb-labelled metadata, including nested envelopes.
     * Never infer identity from a title/year or another movie's related-card metadata. */
    internal fun imdbReference(root: JsonElement?): String? {
        val pattern = Regex("(?i)(?<![A-Za-z0-9])tt[0-9]{7,10}(?![0-9])")
        val keyName = Regex("[^a-z0-9]")
        val envelopes = setOf("data", "result", "results", "info", "details", "detail", "video", "movie", "film", "metadata", "externalids", "external", "ids", "links", "imdb")
        var visits = 0
        fun scan(node: JsonElement?, depth: Int, imdbContext: Boolean): String? {
            if (node == null || node.isJsonNull || depth > 5 || ++visits > 150) return null
            return when {
                node.isJsonObject -> {
                    val obj = node.asJsonObject
                    // Prioritize explicit IMDb fields before descending into wrappers.
                    obj.entrySet().firstNotNullOfOrNull { (rawKey, value) ->
                        val key = rawKey.lowercase().replace(keyName, "")
                        val recognized = key in setOf("imdb", "imdbid", "imdburlref", "imdburl", "imdblink", "imdbidentifier", "imdbref")
                        if (recognized) scan(value, depth + 1, true) else if (imdbContext && key in setOf("url", "link", "id", "value", "ref")) scan(value, depth + 1, true) else null
                    } ?: obj.entrySet().firstNotNullOfOrNull { (rawKey, value) ->
                        val key = rawKey.lowercase().replace(keyName, "")
                        if (key in envelopes) scan(value, depth + 1, imdbContext || key == "imdb") else null
                    }
                }
                node.isJsonArray -> node.asJsonArray.take(5).firstNotNullOfOrNull { scan(it, depth + 1, imdbContext) }
                imdbContext && node.isJsonPrimitive && node.asJsonPrimitive.isString ->
                    pattern.find(node.asString)?.value?.lowercase()
                else -> null
            }
        }
        return scan(root, 0, false)
    }

    fun detail(root: JsonElement?, fallback: Video): Video {
        val found = videos(root, 1).firstOrNull() ?: fallback
        val (cert, adult) = maturitySignals(root)
        // Some provider detail endpoints omit certification present in the catalog card.
        // Preserve it for consistent filtering when the user opens a title.
        return found.copy(
            filmRating = found.filmRating ?: cert ?: fallback.filmRating,
            categories = found.categories ?: fallback.categories,
            adult = found.adult ?: adult ?: fallback.adult,
            imdbRef = app.cinemanatv.data.ExternalSceneMarkers.imdbID(found.imdbRef)
                ?: imdbReference(root)
                ?: app.cinemanatv.data.ExternalSceneMarkers.imdbID(fallback.imdbRef),
        )
    }

    private fun qualityHeight(label: String): Int {
        val s = label.lowercase()
        return when {
            "2160" in s || "4k" in s || "uhd" in s -> 2160
            "1440" in s || "2k" in s -> 1440
            "1080" in s || "fhd" in s -> 1080
            "720" in s || s.trim() == "hd" -> 720
            "480" in s || s.trim() == "sd" -> 480
            else -> Regex("(\\d{3,4})").find(s)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        }
    }

    fun sources(root: JsonElement?): List<QualityOption> {
        val found = LinkedHashMap<String, QualityOption>()
        fun visit(e: JsonElement, depth: Int, inherited: String = "") {
            if (depth > 5 || found.size >= 35) return
            when {
                e.isJsonArray -> e.asJsonArray.forEach { visit(it, depth + 1, inherited) }
                e.isJsonObject -> {
                    val o = e.asJsonObject
                    val name = text(o, "resolution", "quality", "height", "name", "label", "videoQuality") ?: inherited
                    val url = videoUrl(text(o, "videoUrl", "videoURL", "url", "file", "path", "src", "link", "videoFileUrl"))
                    if (url != null) found.putIfAbsent(url, QualityOption(qualityHeight(name), url))
                    // Supports maps such as { "2160p": "https://...", "1080p": "https://..." }.
                    o.entrySet().forEach { (key, value) ->
                        if (value.isJsonPrimitive && value.asJsonPrimitive.isString && qualityKey.matches(key.trim())) {
                            videoUrl(value.asString)?.let { found.putIfAbsent(it, QualityOption(qualityHeight(key), it)) }
                        }
                    }
                    // Nested objects in the reference app include videoFile/transcodedFiles.
                    listOf("data", "results", "items", "files", "qualities", "videoFile", "videoFiles", "transcodedFiles", "transcoddedFiles", "video", "sources", "streams").forEach {
                        key -> o.get(key)?.let { visit(it, depth + 1, name) }
                    }
                }
                e.isJsonPrimitive && e.asJsonPrimitive.isString -> {
                    videoUrl(e.asString)?.let { found.putIfAbsent(it, QualityOption(qualityHeight(inherited), it)) }
                }
            }
        }
        root?.let { visit(it, 0) }
        return found.values.sortedByDescending { it.height }
    }

    fun subtitles(root: JsonElement?): List<SubtitleOption> {
        val found = LinkedHashMap<String, SubtitleOption>()
        fun add(label: String, url: String?) {
            val safe = validUrl(url) ?: return
            val mime = if (safe.substringBefore('?').lowercase().endsWith(".vtt")) "text/vtt" else "application/x-subrip"
            found.putIfAbsent(safe, SubtitleOption(label, safe, mime))
        }
        fun visit(e: JsonElement, depth: Int) {
            if (depth > 4) return
            when {
                e.isJsonArray -> e.asJsonArray.forEach { visit(it, depth + 1) }
                e.isJsonObject -> {
                    val o = e.asJsonObject
                    add("English", text(o, "enTranslationFilePath", "englishSubtitle"))
                    add("العربية", text(o, "arTranslationFilePath", "arabicSubtitle"))
                    add(text(o, "name", "lang", "language", "label") ?: "Subtitle", text(o, "file", "url", "path"))
                    listOf("data", "result", "translations", "translationFiles", "subtitles", "items", "files").forEach { k -> o.get(k)?.let { visit(it, depth + 1) } }
                }
            }
        }
        root?.let { visit(it, 0) }
        val used = mutableMapOf<String, Int>()
        return found.values.map { item ->
            val occurrence = (used[item.label] ?: 0) + 1
            used[item.label] = occurrence
            if (occurrence == 1) item else item.copy(label = "${item.label} $occurrence")
        }
    }
}
