@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CinemanaTV v1.5.7 - Optimized Test APK Builder

echo =============================================================
echo       CinemanaTV v1.5.7 - OPTIMIZED TEST APK
echo =============================================================
where java >nul 2>&1
if errorlevel 1 (
  echo ERROR: JDK 17 or newer is required.
  pause
  exit /b 1
)
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_SDK_ROOT if defined ANDROID_HOME set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist "gradlew.bat" (
  echo ERROR: gradlew.bat is missing. Extract the whole ZIP first.
  pause
  exit /b 1
)
echo.
echo Building the optimized (R8-minified, non-debuggable) APK...
echo This is the build you want for daily use: it is much faster than a debug build.
call gradlew.bat --no-daemon assembleRelease
if errorlevel 1 (
  echo.
  echo BUILD FAILED - read the compiler messages above.
  echo If it only fails in the release step, try BUILD-DEBUG-APK.cmd to confirm the source itself compiles.
  pause
  exit /b 1
)
if not exist "app\build\outputs\apk\release\app-release.apk" (
  echo ERROR: No release APK was produced.
  pause
  exit /b 1
)
if not exist "output" mkdir "output"
copy /y "app\build\outputs\apk\release\app-release.apk" "output\CinemanaTV-Cinema-v1.5.7.apk" >nul
if errorlevel 1 (
  echo ERROR: Could not copy the APK.
  pause
  exit /b 1
)
echo.
echo SUCCESS: output\CinemanaTV-Cinema-v1.5.7.apk
echo This is TEST-SIGNED using the local debug key; do not publish as a release.
echo It only updates existing apps signed with the exact same key.
echo.
pause
