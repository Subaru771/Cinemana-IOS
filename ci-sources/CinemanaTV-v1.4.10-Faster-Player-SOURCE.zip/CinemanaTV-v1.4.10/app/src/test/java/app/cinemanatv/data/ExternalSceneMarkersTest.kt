package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class ExternalSceneMarkersTest {
    private val duration = 2_700_000L

    @Test fun skipDbIntroAndCreditsRequireAccurateStreamMatch() {
        val json = JsonParser.parseString("""{
          "segments": {
            "intro":{"start_ms":27000,"end_ms":85000,"confidence":0.93,"match":"exact"},
            "outro":{"start_ms":2600000,"end_ms":2640000,"confidence":0.90,"match":"shifted"},
            "recap":{"start_ms":1000,"end_ms":11000,"confidence":0.99,"match":"agnostic"},
            "preview":null
          }
        }""")
        val found = ExternalSceneMarkers.skipDB(json, duration)
        assertEquals(setOf("intro", "outro"), found.map { it.kind }.toSet())
        assertEquals(85_000L, found[0].destination(30_000L, duration))
        assertNull(found[0].destination(90_000L, duration))
    }

    @Test fun introDbFallbackOnlyUsesConfidentMarkers() {
        val json = JsonParser.parseString("""{
          "intro":{"start_ms":1000,"end_ms":64000,"confidence":0.96},
          "recap":{"start_ms":4500,"end_ms":18000,"confidence":0.5},
          "post_credits":{"start_ms":2640000,"end_ms":2680000,"confidence":0.85}
        }""")
        assertEquals(setOf("intro"), ExternalSceneMarkers.introDB(json, duration).map { it.kind }.toSet())
    }

    @Test fun movieMatureScenesRequireMatchingEditionAndExplicitSkipFlag() {
        val json = JsonParser.parseString("""{
          "imdb_id":"tt0266543", "duration":2700,
          "scenes":[
            {"start":120.5,"end":154,"reason":"nudity","skip":true},
            {"start":180,"end":190,"reason":"frightening","skip":true},
            {"start":210,"end":225,"reason":"sexual","skip":false}
          ]
        }""")
        val result = ExternalSceneMarkers.movieHaven(json,"tt0266543",duration)
        assertEquals(1,result.size)
        assertEquals(154_000L,result.single().endMs)
        assertTrue(ExternalSceneMarkers.movieHaven(json,"tt0266544",duration).isEmpty())
        assertTrue(ExternalSceneMarkers.movieHaven(json,"tt0266543",duration+30_000).isEmpty())
    }

    @Test fun episodeLookupsUseImdbAndSeasonNumber() {
        assertTrue(ExternalSceneMarkers.skipDBURL("https://imdb.com/title/tt0903747/",1,1,duration)!!.contains("episode=1"))
        assertTrue(ExternalSceneMarkers.introDBURL("tt0903747",1,2)!!.contains("season=1"))
        assertNull(ExternalSceneMarkers.skipDBURL("no imdb",1,1,duration))
    }
    @Test fun skipDbCreditsCanEndExactlyAtStreamDuration() {
        val json = JsonParser.parseString("""{
          "segments": {"outro": {"start_ms": 2770000, "end_ms": 2820000,
            "match": "exact", "confidence": 0.95}}
        }""")
        val credits = ExternalSceneMarkers.skipDB(json, 2_820_000L)
        assertEquals(1, credits.size)
        assertEquals(2_819_750L, credits[0].destination(2_785_000L, 2_820_000L))
    }

    @Test fun neverSkipPostCreditScenesAsPreviews() {
        val json = JsonParser.parseString("""{
          "post_credits": {"start_ms": 150000, "end_ms": 200000, "confidence": 0.95}
        }""")
        assertTrue(ExternalSceneMarkers.introDB(json, 2_820_000L).isEmpty())
    }
}
