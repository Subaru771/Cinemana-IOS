## v1.4.10 — Faster playback and accurate skip controls (beta)
- Community intro/recap/outro/preview lookup enabled by default for new installs; configurable in Settings.
- Parallel SkipDB, IntroDB and eligible movie marker requests, off the media/playback thread.
- Accept correct end-credit markers at exact stream end; never auto-skip post-credit content.
- Adaptive mature-scene loop: 120ms near marked scenes, 800ms when far away, 1000ms paused; no polling if no scenes.
- Short negative cache (90 seconds) and positive cache (six hours), with bounded memory.
- Safer provider intro seeking near end of stream; no fixed-time guessing.
- No claims of scene filtering where timecoded mature data is missing.

## v1.4.9 — Player refinement (beta)
- Added an 18-second remote-accessible Undo Scene Skip control.
- Undo exempts only the restored range during the current playback session, preventing immediate re-skips.
- Preserved manually marked ranges, source attribution, existing settings, and provider behavior.
- Mature scenes without exact timing are still not automatically detected.

## 1.4.8-beta.1 — shared timestamp sources
- Optional SkipDB intro, recap, outro and preview markers with IntroDB fallback.
- Per-episode IMDb ID + season/episode matching and conservative time windows; no guessed skips.
- Mature-scene skipping uses only explicit time-coded ranges; MovieHavenDB lookup is movie-only and sparse.
- Movie/series catalog remains visible; no heavy AI or video frame processing.
- External requests are bounded, cached, source-attributed; unknown markers do not skip.

## v1.4.7 — Search ranking and TV focus repair
- Settings sidebar follows remote-control focus immediately; adds visible focus outlines.
- Search prioritizes exact/full-title matches and lets users reveal broad provider suggestions.
- Scene range entry supports typed timestamps ahead of playback and warns when skip data is missing.
- Marked scene checker runs every 100ms and seeks slightly before start; no automatic mature-scene detection is claimed.
- Added title-ranking and timestamp regression tests. Account features remain out of scope.

# Changelog

## 1.4.7 — TV Settings redesign and explicit scene-marking controls
- Added a separate search action outside the navigation tabs.
- Replaced Settings UI with a TV-focused, two-pane focusable interface.
- Added separate Mature Content actions: Off, Skip marked scenes, Hide mature titles.
- Added persisted per-title scene start/end markers and an exact-range automatic skip loop.
- No automatic scene recognition: metadata must be supplied or user-marked.
- Preserved existing files, history, player and downloads. Added tests for scene range logic.
- Android compilation/device testing still required.


## 1.4.5 — Stability consolidation (source only)

- Bumped Android versionCode to 40, versionName to 1.4.5.
- Retained the uploaded 1.4.4 search dropdown, D-pad focus changes, expanded categories,
  embedded Arabic maturity labels, raw-detail certificate parsing and network-failure behavior.
- Restored the uncapped deduplicated maturity lookup queue (4 items per request batch),
  with serialized fetches, bounded timeouts, and outage back-off.
- Restored maturity metadata resolution for local Home/Continue Watching/My List items.
- Restored downloads through the unified maturity checks; hidden items are not deleted.
- Enforced verified metadata at detail/play navigation in non-Off modes.
- Updated Windows build names, verification log and GitHub Actions artifact naming.
- Kept all existing local data, players, downloads and app ID intact; no account features.

**Not verified:** Full Android compilation, installer signature compatibility and actual
TV playback. The included APK builder makes a local debug-signed *test* APK.

## v1.4.4
- Mature filter: a failed age-rating lookup no longer counts as "checked and fine" (titles stay hidden until the lookup succeeds); "More like this" on a title page is now filtered too; certificates are also read from extra fields (mpaa, age limit, is_adult…) and Arabic-only genre tags are recognised.
- Search: pressing Up on the top menu drops the search panel down; the page underneath no longer takes focus while it is open.
- Not yet built or tested on a TV.

## v1.4.3
- Search is now a panel that drops down from the top over the current page (Back or Close ▴ puts it away); the field is focused on open.
- Mature filter now actually filters: each title's age certificate and genre tags are looked up once, remembered on disk, and titles are hidden until checked. Applies to Home, Movies, Series, Search, History, My List and Downloads.
- Movies and Series tabs have more sections: Trending, New, Top Rated, Classic, Latest Releases and up to six genre rows built from the catalog.
- Removed: Cinema Hub promo popup, Telegram/QR code and its library, startup performance readout, historical docs, competitor audits and test-kit scripts.
- versionCode 38. Not yet built or tested on a TV.

## v1.4.2
- Mature content modes (Off, Hide mature, Family only), home row switches, list sorting, autoplay-next preference.
