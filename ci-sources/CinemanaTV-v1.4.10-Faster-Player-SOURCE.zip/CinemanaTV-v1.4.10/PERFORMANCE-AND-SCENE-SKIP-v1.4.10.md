## v1.4.10 — Faster playback and accurate skip controls (beta)
- Community intro/recap/outro/preview lookup enabled by default for new installs; configurable in Settings.
- Parallel SkipDB, IntroDB and eligible movie marker requests, off the media/playback thread.
- Accept correct end-credit markers at exact stream end; never auto-skip post-credit content.
- Adaptive mature-scene loop: 120ms near marked scenes, 800ms when far away, 1000ms paused; no polling if no scenes.
- Short negative cache (90 seconds) and positive cache (six hours), with bounded memory.
- Safer provider intro seeking near end of stream; no fixed-time guessing.
- No claims of scene filtering where timecoded mature data is missing.

Installation: source APK is a debug/testing build. If signing differs from installed app, back up data before any uninstall. See license information above.
