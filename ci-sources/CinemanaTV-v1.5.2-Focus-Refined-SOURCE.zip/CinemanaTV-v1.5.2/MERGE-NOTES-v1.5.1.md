# Cinemana TV v1.5.1 merge decision record

## Kept from v1.5.0
- Home list caching and fewer recompositions while using the remote.
- Compact episode cards, focusable Skip and Undo controls, auto intro/recap option, video prefetch.
- Playback exact seeks, protected from repeat skips after Undo.
- Concurrent scene marker requests, failed network response retry, compact scene-marker controls.

## Restored/fixed from v1.4.10
- Post-credit story scenes are preserved. An IntroDB `post_credits` field is not a `preview`.
- Adaptive scene polling avoids 80ms wake-ups throughout a movie while remaining responsive near marked ranges.
- Longer cache lifetime for verified scene markers reduces network overhead.

## Tests and limitations
- New tests cover post-credit classification and adaptive polling, in addition to prior tests for Undo, seeking and marker validation.
- Full Gradle build and physical-TV playback must be verified separately. No guarantee mature scenes without timestamps are skipped.
- `versionCode=46` makes the update version newer than v1.5.0 (45), but signing keys still must match to update an existing install.
