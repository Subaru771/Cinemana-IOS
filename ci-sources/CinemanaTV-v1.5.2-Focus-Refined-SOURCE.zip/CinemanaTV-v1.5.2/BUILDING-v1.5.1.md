# CinemanaTV v1.5.1 — build instructions

This ZIP is **source code**, not a prebuilt APK. The Gradle project declares
`versionName = "1.5.1"`, `versionCode = 45`, app ID `app.cinemanatv`.

## Windows

1. Extract the entire ZIP.
2. Install Java 17+ and Android SDK Platform 35. Set `ANDROID_HOME` if required.
3. Double-click `BUILD-DEBUG-APK.cmd` to run unit tests and build a debugging APK.
4. For the optimized test build, double-click `BUILD-APK.cmd`.

## Mac/Linux

```sh
chmod +x ./gradlew
./gradlew --no-daemon testDebugUnitTest assembleDebug
./gradlew --no-daemon assembleRelease
```

Output paths: `app/build/outputs/apk/debug/app-debug.apk` and
`app/build/outputs/apk/release/app-release.apk`. The release configuration
currently uses **local debug-key signing**, not production signing. Do not
assume you can update an installed build signed with a different key.

The source archive's integrity and manifest have been verified, but **a full
Android Gradle build has not yet been executed** in this environment.
Skipping explicit scenes requires reliable per-title timestamp metadata;
unknown scenes cannot be filtered just by enabling the toggle.
