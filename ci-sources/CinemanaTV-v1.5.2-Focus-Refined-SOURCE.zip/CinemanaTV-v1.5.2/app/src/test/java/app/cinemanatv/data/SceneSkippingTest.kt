package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test

class SceneSkippingTest {
    @Test fun parsesManualTimestampsWithoutGuessing() {
        assertEquals(725_000L, SceneSkipping.parseStamp("12:05"))
        assertEquals(4_325_000L, SceneSkipping.parseStamp("1:12:05"))
        assertNull(SceneSkipping.parseStamp("12:88"))
        assertNull(SceneSkipping.parseStamp("roughly 12 min"))
        assertNull(SceneSkipping.parseStamp(""))
    }

    @Test fun skipsOnlyInsideSavedRanges() {
        val marks = listOf(SceneRange(30_000L, 42_000L))
        assertNull(SceneSkipping.skipTarget(29_500L, marks, 120_000L))
        assertEquals(42_250L, SceneSkipping.skipTarget(29_800L, marks, 120_000L))
        assertEquals(42_250L, SceneSkipping.skipTarget(31_000L, marks, 120_000L))
        assertNull(SceneSkipping.skipTarget(42_000L, marks, 120_000L))
    }
    @Test fun noMarkerMeansNoSkip() {
        assertNull(SceneSkipping.skipTarget(42_000L, emptyList(), 120_000L))
        assertNull(SceneSkipping.skipTarget(42_000L, listOf(SceneRange(41_000L,42_500L)), 0L))
    }
    @Test fun rejectsInvalidRanges() {
        assertTrue(SceneSkipping.add(emptyList(), 50_000L, 40_000L).isEmpty())
        assertTrue(SceneSkipping.add(emptyList(), 1_000L, 1_500L).isEmpty())
        assertTrue(SceneSkipping.add(emptyList(), 0L, 2_000_000L).isEmpty())
    }
    @Test fun mergesOverlapsAndSorts() {
        assertEquals(listOf(SceneRange(10_000L, 25_000L)), SceneSkipping.normalize(listOf(
            SceneRange(20_000L, 25_000L), SceneRange(10_000L, 22_000L)
        )))
    }
    @Test fun skipStopsAtVideoEnd() {
        // A marker past the end of this cut is invalid; never skip blindly.
        assertNull(SceneSkipping.skipTarget(55_000L,
            listOf(SceneRange(50_000L, 62_000L)), 60_000L))
    }


    @Test fun undoCanIdentifyTheSpecificSceneWithoutSkippingAnotherRange() {
        val ranges = listOf(SceneRange(10_000L, 20_000L), SceneRange(40_000L, 50_000L))
        val first = SceneSkipping.activeRange(11_000L, ranges, 120_000L)
        assertEquals(ranges[0], first)
        assertEquals(20_250L, SceneSkipping.skipTarget(11_000L, ranges, 120_000L))
        val exempt = setOf(first)
        assertTrue(SceneSkipping.activeRange(11_000L, ranges, 120_000L) in exempt)
        assertFalse(SceneSkipping.activeRange(41_000L, ranges, 120_000L) in exempt)
        assertNull(SceneSkipping.activeRange(21_000L, ranges, 120_000L))
        assertNull(SceneSkipping.activeRange(119_800L, ranges, 120_000L))
    }

    @Test fun adaptivePollingPreservesFastDetectionNearScenesWithoutBusyPollingThroughoutTheMovie() {
        val first = SceneRange(90_000L, 100_000L)
        val second = SceneRange(190_000L, 220_000L)
        val marks = listOf(first, second)
        assertEquals(1_000L, SceneSkipping.pollDelayMs(0L, true, marks, emptySet()))
        assertEquals(700L, SceneSkipping.pollDelayMs(60_000L, true, marks, emptySet()))
        assertEquals(350L, SceneSkipping.pollDelayMs(75_000L, true, marks, emptySet()))
        assertEquals(120L, SceneSkipping.pollDelayMs(89_000L, true, marks, emptySet()))
        assertEquals(120L, SceneSkipping.pollDelayMs(95_000L, true, marks, emptySet()))
        assertEquals(1_000L, SceneSkipping.pollDelayMs(89_000L, false, marks, emptySet()))
        assertEquals(1_000L, SceneSkipping.pollDelayMs(300_000L, true, marks, emptySet()))
        // Undo exempts that range, so polling should look at the next real marker instead.
        assertEquals(1_000L, SceneSkipping.pollDelayMs(89_000L, true, marks, setOf(first)))
    }

    @Test fun sceneThatEndsExactlyAtTheRuntimeIsStillSkipped() {
        val last = listOf(SceneRange(50_000L, 60_000L))
        assertEquals(60_000L, SceneSkipping.skipTarget(52_000L, last, 60_000L))
    }
}
