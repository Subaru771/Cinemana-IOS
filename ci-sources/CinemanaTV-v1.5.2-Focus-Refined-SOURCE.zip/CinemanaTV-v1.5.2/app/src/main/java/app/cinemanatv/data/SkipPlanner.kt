package app.cinemanatv.data

/** What the viewer is offered right now. [targetMs] is already clamped to the runtime. */
data class SkipOffer(
    val key: String,
    val kind: String,
    val targetMs: Long,
    /** The segment runs to the end of the file (credits): the natural action is "next episode". */
    val toEnd: Boolean,
    val source: String,
    val startMs: Long,
) {
    /** Only intros and recaps are ever skipped without a button press, and only if the viewer opted in. */
    val autoEligible: Boolean get() = kind == "intro" || kind == "recap"
}

/** Pure decision logic for intro/recap/credits skipping, kept free of Android so it can be unit tested. */
object SkipPlanner {
    /** The button appears slightly before a segment starts so it is on screen when the intro begins. */
    const val LEAD_IN_MS = 2_000L
    private const val END_GUARD_MS = 1_500L

    /** Cinemana's own intro window (when the provider supplies one) uses the same marker model. */
    fun fromProvider(window: LongRange?): ExternalSceneMarker? =
        window?.let { ExternalSceneMarker("intro", it.first, it.last + 1, "Cinemana", 1.0) }

    fun offer(positionMs: Long, durationMs: Long, markers: List<ExternalSceneMarker>): SkipOffer? {
        if (positionMs < 0L || durationMs <= 0L) return null
        val hit = markers.filter { it.kind != "mature" }
            .sortedBy { it.startMs }
            .firstOrNull { m ->
                positionMs >= m.startMs - LEAD_IN_MS && positionMs < m.endMs - 700L &&
                    m.startMs < durationMs - 1_000L
            } ?: return null
        val end = hit.endMs.coerceAtMost(durationMs)
        val toEnd = end >= durationMs - END_GUARD_MS
        return SkipOffer(
            key = "${hit.kind}:${hit.startMs}", kind = hit.kind,
            targetMs = if (toEnd) durationMs else end,
            toEnd = toEnd, source = hit.source, startMs = hit.startMs,
        )
    }

    /** Auto-skip fires only once the segment has really begun (not during the lead-in) and only once per segment. */
    fun shouldAutoSkip(offer: SkipOffer, positionMs: Long, alreadyHandled: Set<String>): Boolean =
        offer.autoEligible && !offer.toEnd && offer.key !in alreadyHandled && positionMs >= offer.startMs - 250L
}
