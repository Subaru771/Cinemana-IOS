package app.cinemanatv.data

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.io.ByteArrayOutputStream

/** Shared semantics with Cinemana iOS. Times are milliseconds; no AI runs on the TV. */
data class ExternalSceneMarker(
    val kind: String, val startMs: Long, val endMs: Long,
    val source: String, val confidence: Double, val category: String = kind,
) {
    /** Where a skip lands. Credits/previews that run to the end of the file are valid (clamped to it). */
    fun destination(positionMs: Long, durationMs: Long): Long? =
        endMs.coerceAtMost(durationMs).takeIf { positionMs >= (startMs - 3000L).coerceAtLeast(0L) &&
            positionMs < endMs - 500L && startMs < durationMs - 1000L }

    fun clampedTo(durationMs: Long): ExternalSceneMarker =
        if (endMs > durationMs) copy(endMs = durationMs) else this

    /** Provider/community timestamps can be a second or two off; widen mature skips slightly. */
    fun padded(beforeMs: Long, afterMs: Long, durationMs: Long): ExternalSceneMarker =
        copy(startMs = (startMs - beforeMs).coerceAtLeast(0L), endMs = (endMs + afterMs).coerceAtMost(durationMs))
}

object ExternalSceneMarkers {
    /** External timestamps are rounded to whole seconds by their authors; err on the side of skipping a bit more. */
    const val MATURE_PAD_BEFORE_MS = 1_500L
    const val MATURE_PAD_AFTER_MS = 1_000L

    private val imdbPattern = Regex("tt[0-9]{7,10}", RegexOption.IGNORE_CASE)
    private val types = listOf("intro", "recap", "outro", "preview")
    private val matureReasons = setOf("nudity", "sex", "sex_scene", "sexual", "sexual-content",
        "sexual_content", "explicit", "erotic", "intimacy", "sexuality")

    fun imdbID(raw: String?): String? = raw?.let { imdbPattern.find(it)?.value?.lowercase(Locale.US) }

    private fun JsonObject.objectOrNull(key: String): JsonObject? =
        get(key)?.takeIf { it.isJsonObject }?.asJsonObject
    private fun JsonObject.stringOrNull(key: String): String? =
        runCatching { get(key)?.takeIf { it.isJsonPrimitive }?.asString }.getOrNull()
    private fun JsonObject.numberOrNull(key: String): Double? =
        runCatching { get(key)?.takeIf { it.isJsonPrimitive }?.asDouble }.getOrNull()

    fun validated(marker: ExternalSceneMarker, durationMs: Long): Boolean {
        val length = marker.endMs - marker.startMs
        val maxMs = when(marker.kind) {
            "intro", "recap" -> 300_000L
            "mature" -> 1_200_000L
            else -> 900_000L
        }
        // Credits and previews usually run to the very end of the file, so an end at (or a hair
        // past) the runtime is valid; a marker that starts beyond this cut is not.
        return durationMs >= 60_000L && marker.startMs >= 0 && length in 501L..maxMs &&
            marker.startMs < durationMs - 1_000L && marker.endMs <= durationMs + 3_000L &&
            marker.confidence in 0.0..1.0
    }

    fun skipDBURL(id: String?, season: Int, episode: Int, durationMs: Long): String? {
        val imdb = imdbID(id) ?: return null
        if (durationMs < 60_000L) return null
        return "https://api.skipdb.tv/api/segments?imdb_id=$imdb&duration=${(durationMs / 1000)}&adjust=conservative" +
            if (season > 0 && episode > 0) "&season=$season&episode=$episode" else ""
    }

    fun introDBURL(id: String?, season: Int, episode: Int): String? {
        val imdb = imdbID(id) ?: return null
        return "https://api.introdb.app/segments?imdb_id=$imdb" +
            if (season > 0 && episode > 0) "&season=$season&episode=$episode" else "&is_movie=true"
    }

    /** TheIntroDB v4: public endpoint, release-aware and supports multiple segments per type. */
    fun theIntroDBURL(id: String?, season: Int, episode: Int, durationMs: Long): String? {
        val imdb = imdbID(id) ?: return null
        if (durationMs < 60_000L) return null
        return "https://api.theintrodb.org/v4/media?imdb_id=$imdb&duration_ms=$durationMs" +
            if (season > 0 && episode > 0) "&season=$season&episode=$episode" else ""
    }

    /** Opt-in community source. Only fetch movie-specific metadata; no video data is sent. */
    fun cleanStreamURL(id: String?): String? {
        val imdb = imdbID(id) ?: return null
        return "https://cleanstream.elfhosted.com/api/filters/$imdb"
    }

    fun movieHavenURL(id: String?): String? {
        val imdb = imdbID(id) ?: return null
        return "https://raw.githubusercontent.com/arman-kh/MovieHavenDB/master/movies/$imdb.json"
    }

    fun skipDB(json: JsonElement?, durationMs: Long): List<ExternalSceneMarker> {
        val segments = runCatching { json?.asJsonObject?.objectOrNull("segments") }.getOrNull() ?: return emptyList()
        return types.mapNotNull { type ->
            val entry = segments.objectOrNull(type) ?: return@mapNotNull null
            val start = entry.numberOrNull("start_ms")?.toLong() ?: return@mapNotNull null
            val end = entry.numberOrNull("end_ms")?.toLong() ?: return@mapNotNull null
            val confidence = entry.numberOrNull("confidence") ?: return@mapNotNull null
            if (confidence < 0.70 || entry.stringOrNull("match") !in listOf("exact", "shifted")) return@mapNotNull null
            ExternalSceneMarker(type, start, end, "SkipDB (ODbL)", confidence)
                .takeIf { validated(it, durationMs) }?.clampedTo(durationMs)
        }
    }

    fun introDB(json: JsonElement?, durationMs: Long): List<ExternalSceneMarker> {
        val data = runCatching { json?.asJsonObject }.getOrNull() ?: return emptyList()
        // Preserve actual post-credit story scenes: they are never an intro, outro or preview.
        // This restores the safe behavior from v1.4.10; the service's explicit preview marker
        // is handled separately by SkipDB, and never inferred from post_credits.
        return listOf("intro", "recap", "outro").mapNotNull { type ->
            val entry = data.objectOrNull(type) ?: return@mapNotNull null
            val start = entry.numberOrNull("start_ms")?.toLong() ?: return@mapNotNull null
            val end = entry.numberOrNull("end_ms")?.toLong() ?: return@mapNotNull null
            val conf = entry.numberOrNull("confidence") ?: return@mapNotNull null
            if (conf < 0.80) return@mapNotNull null
            ExternalSceneMarker(type, start, end, "IntroDB", conf)
                .takeIf { validated(it, durationMs) }?.clampedTo(durationMs)
        }
    }

    /** v4 groups intro/recap/credits/preview into arrays. Null credit ends mean media end. */
    fun theIntroDB(json: JsonElement?, durationMs: Long): List<ExternalSceneMarker> {
        val body = runCatching { json?.asJsonObject }.getOrNull() ?: return emptyList()
        // An episode index or a list of versions is not a timestamp response.
        if (body.stringOrNull("kind") in setOf("versions", "episodes")) return emptyList()
        val result = mutableListOf<ExternalSceneMarker>()
        for ((apiType, kind) in listOf("intro" to "intro", "recap" to "recap",
            "credits" to "outro", "preview" to "preview")) {
            val entries = body.get(apiType)?.takeIf { it.isJsonArray }?.asJsonArray ?: continue
            for (value in entries) {
                val row = value.takeIf { it.isJsonObject }?.asJsonObject ?: continue
                val start = row.numberOrNull("start_ms")?.toLong() ?: if (kind in setOf("intro", "recap")) 0L else continue
                val end = row.numberOrNull("end_ms")?.toLong() ?: if (kind in setOf("outro", "preview")) durationMs else continue
                val confidence = row.numberOrNull("confidence") ?: 0.85
                if (confidence < 0.80) continue
                val segment = ExternalSceneMarker(kind, start, end, "TheIntroDB", confidence)
                if (validated(segment, durationMs)) result.add(segment.clampedTo(durationMs))
            }
        }
        return result.sortedBy { it.startMs }
    }

    /** Public CleanStream community filter format; reject unverified editions and weak votes. */
    fun cleanStream(json: JsonElement?, id: String?, durationMs: Long): List<ExternalSceneMarker> {
        val body = runCatching { json?.asJsonObject }.getOrNull() ?: return emptyList()
        if (imdbID(body.stringOrNull("imdbId")) != imdbID(id) || imdbID(id) == null) return emptyList()
        if (body.stringOrNull("type")?.lowercase(Locale.US) == "series") return emptyList()
        val releases = body.get("releases")?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        // Do not skip scenes from a different cut. A 5 s duration tolerance is conservative.
        val sameCut = releases.any { item ->
            runCatching { item.asJsonObject.numberOrNull("runtime") }.getOrNull()
                ?.let { kotlin.math.abs(it - durationMs.toDouble()) <= 5000.0 } == true
        }
        if (!sameCut) return emptyList()
        val entries = body.get("segments")?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        return entries.mapNotNull { value ->
            val row = value.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val kind = row.stringOrNull("category")?.lowercase(Locale.US) ?: return@mapNotNull null
            if (kind !in matureReasons) return@mapNotNull null
            val votes = row.objectOrNull("votes") ?: return@mapNotNull null
            val up = votes.numberOrNull("up")?.toInt() ?: return@mapNotNull null
            val down = votes.numberOrNull("down")?.toInt() ?: 0
            // Require positive community consensus; do not trust unreviewed submissions.
            if (up < 3 || down < 0 || up < down * 2) return@mapNotNull null
            val start = row.numberOrNull("startMs")?.toLong() ?: return@mapNotNull null
            val end = row.numberOrNull("endMs")?.toLong() ?: return@mapNotNull null
            ExternalSceneMarker("mature", start, end, "CleanStream (community)", 0.80, kind)
                .takeIf { validated(it, durationMs) }?.clampedTo(durationMs)
                ?.padded(MATURE_PAD_BEFORE_MS, MATURE_PAD_AFTER_MS, durationMs)
        }
    }

    /** Only explicit sexual scene entries with skip=true and a matching runtime. */
    fun movieHaven(json: JsonElement?, id: String?, durationMs: Long): List<ExternalSceneMarker> {
        val data = runCatching { json?.asJsonObject }.getOrNull() ?: return emptyList()
        if (imdbID(id) == null || imdbID(data.stringOrNull("imdb_id")) != imdbID(id)) return emptyList()
        val stored = data.numberOrNull("duration") ?: return emptyList()
        if (kotlin.math.abs(stored * 1000 - durationMs.toDouble()) > 5000.0) return emptyList()
        val scenes = data.get("scenes")?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
        return scenes.mapNotNull { value ->
            val row = value.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            val reason = row.stringOrNull("reason")?.lowercase(Locale.US)?.replace(' ', '_') ?: return@mapNotNull null
            if (reason !in matureReasons || row.get("skip")?.takeIf { it.isJsonPrimitive }?.asBoolean != true)
                return@mapNotNull null
            val start = row.numberOrNull("start") ?: return@mapNotNull null
            val end = row.numberOrNull("end") ?: return@mapNotNull null
            ExternalSceneMarker("mature", (start * 1000).toLong(), (end * 1000).toLong(),
                "MovieHavenDB (CC BY 4.0)", 0.80, reason).takeIf { validated(it, durationMs) }
                ?.clampedTo(durationMs)?.padded(MATURE_PAD_BEFORE_MS, MATURE_PAD_AFTER_MS, durationMs)
        }
    }

    fun merge(primary: List<ExternalSceneMarker>, fallback: List<ExternalSceneMarker>): List<ExternalSceneMarker> {
        val kinds = primary.mapTo(mutableSetOf()) { it.kind }
        return (primary + fallback.filter { kinds.add(it.kind) }).sortedBy { it.startMs }
    }
}

/** On-demand, bounded, cached and off-main-thread. No media bytes leave the device. */
object RemoteSceneMetadata {
    private data class Cached(val at: Long, val ttlMs: Long, val values: List<ExternalSceneMarker>)
    private val cache = LinkedHashMap<String, Cached>()

    private sealed interface Fetch {
        class Ok(val json: JsonElement?) : Fetch
        /** The service answered "nothing for this title" (404 etc.): a real, cacheable negative. */
        data object Missing : Fetch
        /** Timeout / DNS / 5xx: unknown. Must not be remembered as "no markers". */
        data object Failed : Fetch
    }

    private fun fetchJson(address: String): Fetch = try {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 4000
        connection.readTimeout = 4000
        connection.setRequestProperty("Accept", "application/json")
        try {
            val code = connection.responseCode
            when {
                code == 404 || code == 410 -> Fetch.Missing
                code !in 200..299 -> Fetch.Failed
                else -> connection.inputStream.use { input ->
                    val buffer = ByteArray(8192)
                    val output = ByteArrayOutputStream()
                    var tooLarge = false
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        if (output.size() + read > 256000) { tooLarge = true; break }
                        output.write(buffer, 0, read)
                    }
                    if (tooLarge) Fetch.Missing
                    else Fetch.Ok(JsonParser.parseString(String(output.toByteArray(), Charsets.UTF_8)))
                }
            }
        } finally { connection.disconnect() }
    } catch (_: Exception) { Fetch.Failed }

    private const val POSITIVE_TTL_MS = 21_600_000L
    private const val NO_DATA_TTL_MS = 600_000L
    private const val FAILURE_TTL_MS = 30_000L

    suspend fun load(imdbID: String?, season: Int, episode: Int, durationMs: Long,
                     community: Boolean, mature: Boolean): List<ExternalSceneMarker> = coroutineScope {
        val id = ExternalSceneMarkers.imdbID(imdbID) ?: return@coroutineScope emptyList()
        if (durationMs < 60_000L) return@coroutineScope emptyList()
        val isEpisode = season > 0 && episode > 0
        val key = "$id|$season|$episode|${durationMs/1000}|$community|$mature"
        synchronized(cache) {
            cache[key]?.takeIf { System.currentTimeMillis() - it.at < it.ttlMs }?.values
        }?.let { return@coroutineScope it }

        var failed = false
        // SkipDB and MovieHavenDB are independent: ask both at once instead of back to back.
        val skip = if (community) async(Dispatchers.IO) {
            ExternalSceneMarkers.skipDBURL(id, season, episode, durationMs)?.let { fetchJson(it) }
        } else null
        val haven = if (mature && !isEpisode) async(Dispatchers.IO) {
            ExternalSceneMarkers.movieHavenURL(id)?.let { fetchJson(it) }
        } else null
        val clean = if (mature && !isEpisode) async(Dispatchers.IO) {
            ExternalSceneMarkers.cleanStreamURL(id)?.let { fetchJson(it) }
        } else null

        var found = emptyList<ExternalSceneMarker>()
        val skipResult = skip?.await()
        if (skipResult is Fetch.Ok) found = ExternalSceneMarkers.skipDB(skipResult.json, durationMs)
        else if (skipResult is Fetch.Failed) failed = true

        // IntroDB is only a fallback: skip the extra request when SkipDB already has the essentials.
        if (community && (found.none { it.kind == "intro" } || found.none { it.kind == "outro" })) {
            val url = ExternalSceneMarkers.introDBURL(id, season, episode)
            if (url != null) {
                val fallback = withContext(Dispatchers.IO) { fetchJson(url) }
                if (fallback is Fetch.Ok) found = ExternalSceneMarkers.merge(found, ExternalSceneMarkers.introDB(fallback.json, durationMs))
                else if (fallback is Fetch.Failed) failed = true
            }
        }

        // Third independent intro database, only when existing sources lack the key markers.
        if (community && (found.none { it.kind == "intro" } || found.none { it.kind == "outro" })) {
            val url = ExternalSceneMarkers.theIntroDBURL(id, season, episode, durationMs)
            if (url != null) {
                val fallback = withContext(Dispatchers.IO) { fetchJson(url) }
                if (fallback is Fetch.Ok) found = ExternalSceneMarkers.merge(found, ExternalSceneMarkers.theIntroDB(fallback.json, durationMs))
                else if (fallback is Fetch.Failed) failed = true
            }
        }

        val havenResult = haven?.await()
        if (havenResult is Fetch.Ok) found = found + ExternalSceneMarkers.movieHaven(havenResult.json, id, durationMs)
        else if (havenResult is Fetch.Failed) failed = true
        val cleanResult = clean?.await()
        if (cleanResult is Fetch.Ok) found = found + ExternalSceneMarkers.cleanStream(cleanResult.json, id, durationMs)
        else if (cleanResult is Fetch.Failed) failed = true
        // Prefer the more conservative range if a source reports duplicate mature segments.
        found = found.distinctBy { Triple(it.kind, it.startMs, it.endMs) }

        synchronized(cache) {
            // A network failure is remembered only briefly, so a flaky first request doesn't
            // leave the title without skip buttons for the next hour.
            cache[key] = Cached(System.currentTimeMillis(), if (failed) FAILURE_TTL_MS else if (found.isEmpty()) NO_DATA_TTL_MS else POSITIVE_TTL_MS, found)
            while (cache.size > 40) cache.remove(cache.keys.first())
        }
        found
    }
}
