@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.ui

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import app.cinemanatv.data.QualityOption
import app.cinemanatv.util.AdaptiveOffline
import app.cinemanatv.util.NextEpisodePreloader
import app.cinemanatv.util.Capabilities
import app.cinemanatv.Services
import app.cinemanatv.data.SubtitleOption
import app.cinemanatv.data.userAgent
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Player engine stays independent of Compose: player lifetime = TV playback screen lifetime. */
internal class CinemaPlaybackEngine(context: Context) {
    private val appContext = context.applicationContext
    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .connectionPool(ConnectionPool(5, 5, TimeUnit.MINUTES))
        .build()
    private val dataSources = DefaultDataSource.Factory(
        context, OkHttpDataSource.Factory(http).setUserAgent(userAgent())
    )
    // Buffer tuning for streaming over home Wi-Fi/Ethernet:
    //  - start after ~1s of media (fast first frame), but after a stall wait for 4s so we
    //    don't enter a play/stall/play loop on a marginal link;
    //  - keep up to 90s ahead, bounded by an 80 MB byte cap so a 4K file can't exhaust the heap
    //    (time thresholds must NOT override the byte cap on low-memory TV boxes);
    //  - keep 20s behind the playhead so "back 10 seconds" is instant and needs no network.
    private val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(20_000, 90_000, 1_000, 4_000)
        .setTargetBufferBytes(80 * 1024 * 1024)
        .setPrioritizeTimeOverSizeThresholds(false)
        .setBackBuffer(20_000, true)
        .build()

    // Declaring the content as movie audio lets the platform pick the right routing
    // (HDMI / passthrough / surround) and audio focus behaviour.
    private val movieAudio = AudioAttributes.Builder()
        .setUsage(C.USAGE_MEDIA)
        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
        .build()

    private val bandwidth = DefaultBandwidthMeter.getSingletonInstance(context)

    val player: ExoPlayer = ExoPlayer.Builder(
        context, DefaultRenderersFactory(context).setEnableDecoderFallback(true)
    )
        // Retries are bounded; permanent HTTP refusals still surface to the UI.
        .setMediaSourceFactory(DefaultMediaSourceFactory(dataSources)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(3)))
        .setLoadControl(loadControl)
        .setAudioAttributes(movieAudio, true)
        // Holds a Wi-Fi lock while playing: stops the radio dozing between segments (a classic
        // cause of periodic stutter on TV boxes). Needs the WAKE_LOCK permission (declared).
        .setWakeMode(C.WAKE_MODE_NETWORK)
        .setSeekBackIncrementMs(10_000)
        .setSeekForwardIncrementMs(10_000)
        .build().apply {
            setHandleAudioBecomingNoisy(true)
            // Snap seeks to the nearest keyframe instead of decoding up to the exact frame.
            // Scrubbing a progressive MP4 becomes dramatically faster and smoother.
            setSeekParameters(SeekParameters.CLOSEST_SYNC)
        }

    /** Player's own running estimate of download speed, in Mbit/s (0 until measured). */
    fun bandwidthMbps(): Double = bandwidth.bitrateEstimate / 1_000_000.0

    fun droppedFrames(): Int {
        val counters = player.videoDecoderCounters ?: return 0
        counters.ensureUpdated()
        return counters.droppedBufferCount
    }

    fun open(id: String, quality: QualityOption, subtitles: List<SubtitleOption>, at: Long,
             play: Boolean, maxVideoHeight: Int) {
        val subConfigs = subtitles.map { sub ->
            MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub.url))
                .setMimeType(sub.mime)
                .setLabel(sub.label)
                .setId(sub.label)
                .build()
        }
        // For HLS/DASH the Media3 adaptive selector follows bandwidth automatically;
        // cap it to the device or viewer's maximum, never force a single rendition.
        // The UI resolves precedence: in-player manual selection > Preferred > Auto.
        // For adaptive playlists this is a ceiling, not a fixed bitrate guarantee.
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, maxVideoHeight.coerceAtLeast(1)).build()
        val media = MediaItem.Builder().setMediaId(id).setUri(quality.url)
            .setSubtitleConfigurations(subConfigs).build()
        val savedAdaptive = if (quality.url.startsWith("offline://")) AdaptiveOffline.completed(appContext, id) else null
        if (savedAdaptive != null) {
            val cachedMedia = savedAdaptive.buildUpon().setSubtitleConfigurations(subConfigs).build()
            val factory = DefaultMediaSourceFactory(AdaptiveOffline.playbackSource(appContext))
            player.setMediaSource(factory.createMediaSource(cachedMedia), at.coerceAtLeast(0L))
        } else if (quality.progressive &&
            (quality.url.startsWith("https://") || quality.url.startsWith("http://"))) {
            // The 512 KiB next-episode prebuffer is shared with actual progressive
            // playback. Leave adaptive playlist manifests/segments on the default
            // loader so their live/expiring URLs are not inadvertently cached.
            val factory = DefaultMediaSourceFactory(NextEpisodePreloader.dataSourceFactory(appContext))
                .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(3))
            player.setMediaSource(factory.createMediaSource(media), at.coerceAtLeast(0L))
        } else {
            player.setMediaItem(media, at.coerceAtLeast(0L))
        }
        player.prepare()
        player.playWhenReady = play
    }

    /**
     * Frame-accurate seek for skips. Our scrubbing default (CLOSEST_SYNC) may land on an EARLIER
     * keyframe, which for a skip means landing back inside the intro/scene we just left.
     * The default is restored right away; both calls are processed in order on the playback thread.
     */
    fun seekExact(positionMs: Long) {
        player.setSeekParameters(SeekParameters.EXACT)
        player.seekTo(positionMs.coerceAtLeast(0L))
        player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
    }

    /** Retains media item, tracks, position and playWhenReady after a transient loader failure. */
    fun retry() {
        if (player.currentMediaItem != null) player.prepare()
    }

    fun seek(delta: Long) {
        val duration = player.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
        player.seekTo((player.currentPosition + delta).coerceIn(0L, duration))
    }

    fun subtitles(tracks: Tracks, selected: String?) {
        val settings = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, selected == null)
        if (selected != null) {
            tracks.groups.firstNotNullOfOrNull { group ->
                if (group.type != C.TRACK_TYPE_TEXT) null else
                    (0 until group.length).firstOrNull { i ->
                        group.getTrackFormat(i).label == selected
                    }?.let { i -> group to i }
            }?.let { (group, i) ->
                settings.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, i))
            }
        }
        player.trackSelectionParameters = settings.build()
    }

    fun audio(tracks: Tracks, selected: String?) {
        val settings = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
        if (selected != null) {
            tracks.groups.firstNotNullOfOrNull { group ->
                if (group.type != C.TRACK_TYPE_AUDIO) null else
                    (0 until group.length).firstOrNull { i ->
                        group.getTrackFormat(i).let { it.label ?: it.language ?: "Audio ${i + 1}" } == selected
                    }?.let { i -> group to i }
            }?.let { (group, i) ->
                settings.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, i))
            }
        }
        player.trackSelectionParameters = settings.build()
    }

    fun close() {
        player.stop()
        player.release()
        http.dispatcher.cancelAll()
        http.connectionPool.evictAll()
    }
}
