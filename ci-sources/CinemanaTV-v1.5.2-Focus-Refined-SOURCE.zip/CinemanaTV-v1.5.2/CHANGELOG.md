## v1.5.2 — merged and stabilized (v1.5.0 + v1.4.10)

- Retain v1.5.0 faster Home/D-pad navigation, compact player HUD, OK-to-skip and Left-to-Undo remote behavior, exact seeks, auto intro/recap, media prefetch, and less redundant detail fetching.
- Restore v1.4.10 safety: IntroDB **post-credit story scenes are not converted to skippable previews**. Never guess a skip from a post-credits marker.
- Restore adaptive mature-marker polling (120ms near a marked scene, up to 1s elsewhere) instead of checking every 80ms throughout marked movies. Retains per-scene Undo exemptions and precise seeks.
- Retain network timeout recovery, parallel source lookups, and cache verified results for 6h. Missing markers retry in 10min; transient failure in 30s.
- Android versionCode increased to 46 (from 45). Updated Windows builder, CI names and full-test command.
- Added regression tests for post-credits preservation, polling and per-scene Undo behavior.
- No new mature-scene detection: skips still require explicit, compatible timestamps.

## v1.4.9 — Player refinement (beta)
- Added an 18-second remote-accessible Undo Scene Skip control.
- Undo exempts only the restored range during the current playback session, preventing immediate re-skips.
- Preserved manually marked ranges, source attribution, existing settings, and provider behavior.
- Mature scenes without exact timing are still not automatically detected.

## 1.4.8-beta.1 — shared timestamp sources
- Optional SkipDB intro, recap, outro and preview markers with IntroDB fallback.
- Per-episode IMDb ID + season/episode matching and conservative time windows; no guessed skips.
- Mature-scene skipping uses only explicit time-coded ranges; MovieHavenDB lookup is movie-only and sparse.
- Movie/series catalog remains visible; no heavy AI or video frame processing.
- External requests are bounded, cached, source-attributed; unknown markers do not skip.

## v1.4.7 — Search ranking and TV focus repair
- Settings sidebar follows remote-control focus immediately; adds visible focus outlines.
- Search prioritizes exact/full-title matches and lets users reveal broad provider suggestions.
- Scene range entry supports typed timestamps ahead of playback and warns when skip data is missing.
- Marked scene checker runs every 100ms and seeks slightly before start; no automatic mature-scene detection is claimed.
- Added title-ranking and timestamp regression tests. Account features remain out of scope.

# Changelog

## 1.5.0 — Skip fixes, speed and polish (source, not compiled here)

**Skipping**
- Skip Intro/Recap/Credits could not be reached with a remote: the button never held focus while the controls were hidden. Now **OK skips** while the controls are hidden, the button takes focus when the controls are up, and **◀ right after a skip undoes it**.
- Skips use a frame-accurate seek. The old keyframe-snapping seek could land back inside the intro/scene and re-trigger.
- Credits/previews that run to the end of the file were rejected outright; they are now accepted (clamped to the runtime) and "Skip Credits" becomes **Next Episode** when there is one.
- New optional **auto-skip for intros and recaps** (Settings → Playback, on by default; credits always need a press).
- Community skip timestamps are now **on by default** (turn off in Settings → Playback). Previously Skip Intro only worked for titles where the provider itself supplied a window.
- A failed network lookup was cached as "no markers" for an hour; failures now retry after 30 s. SkipDB and MovieHavenDB are queried in parallel, IntroDB only when needed.
- Mature scenes: skipped with an exact seek, widened by 1.5 s before / 1 s after external timestamps, and scenes that end at the very end of the file are handled. Idle polling stops when a title has no ranges.
- Undo and the skip button now expire on a timer (the Undo button could linger indefinitely when the controls were hidden).

**Speed / smoothness**
- Home recomputed every row, and re-parsed Continue Watching / My List / History JSON from disk, on every D-pad move. Rows are now memoized, focus no longer recomposes the page, and saved lists are cached in memory.
- Title details are fetched once per playback (was twice in parallel). Splash minimum shortened from 1 s to 0.65 s. Hero preview debounce 700 → 500 ms.
- Player no longer recomposes for the "Up next" check while the controls are hidden.

**UI**
- One bottom-right stack for Undo / Skip / Up next (no overlap, rides above the controls), new focus-lit Skip button with an OK/◀ hint.
- Focused poster titles brighten; episode cards show a "Resume" badge instead of a full-width fake progress bar; buttons truncate instead of wrapping.
- Added SkipPlanner unit tests; updated scene/marker tests.


## 1.4.7 — TV Settings redesign and explicit scene-marking controls
- Added a separate search action outside the navigation tabs.
- Replaced Settings UI with a TV-focused, two-pane focusable interface.
- Added separate Mature Content actions: Off, Skip marked scenes, Hide mature titles.
- Added persisted per-title scene start/end markers and an exact-range automatic skip loop.
- No automatic scene recognition: metadata must be supplied or user-marked.
- Preserved existing files, history, player and downloads. Added tests for scene range logic.
- Android compilation/device testing still required.


## 1.4.5 — Stability consolidation (source only)

- Bumped Android versionCode to 40, versionName to 1.4.5.
- Retained the uploaded 1.4.4 search dropdown, D-pad focus changes, expanded categories,
  embedded Arabic maturity labels, raw-detail certificate parsing and network-failure behavior.
- Restored the uncapped deduplicated maturity lookup queue (4 items per request batch),
  with serialized fetches, bounded timeouts, and outage back-off.
- Restored maturity metadata resolution for local Home/Continue Watching/My List items.
- Restored downloads through the unified maturity checks; hidden items are not deleted.
- Enforced verified metadata at detail/play navigation in non-Off modes.
- Updated Windows build names, verification log and GitHub Actions artifact naming.
- Kept all existing local data, players, downloads and app ID intact; no account features.

**Not verified:** Full Android compilation, installer signature compatibility and actual
TV playback. The included APK builder makes a local debug-signed *test* APK.

## v1.4.4
- Mature filter: a failed age-rating lookup no longer counts as "checked and fine" (titles stay hidden until the lookup succeeds); "More like this" on a title page is now filtered too; certificates are also read from extra fields (mpaa, age limit, is_adult…) and Arabic-only genre tags are recognised.
- Search: pressing Up on the top menu drops the search panel down; the page underneath no longer takes focus while it is open.
- Not yet built or tested on a TV.

## v1.4.3
- Search is now a panel that drops down from the top over the current page (Back or Close ▴ puts it away); the field is focused on open.
- Mature filter now actually filters: each title's age certificate and genre tags are looked up once, remembered on disk, and titles are hidden until checked. Applies to Home, Movies, Series, Search, History, My List and Downloads.
- Movies and Series tabs have more sections: Trending, New, Top Rated, Classic, Latest Releases and up to six genre rows built from the catalog.
- Removed: Cinema Hub promo popup, Telegram/QR code and its library, startup performance readout, historical docs, competitor audits and test-kit scripts.
- versionCode 38. Not yet built or tested on a TV.

## v1.4.2
- Mature content modes (Off, Hide mature, Family only), home row switches, list sorting, autoplay-next preference.
