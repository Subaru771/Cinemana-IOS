package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class ExternalSceneMarkersTest {
    private val duration = 2_700_000L

    @Test fun skipDbIntroAndCreditsRequireAccurateStreamMatch() {
        val json = JsonParser.parseString("""{
          "segments": {
            "intro":{"start_ms":27000,"end_ms":85000,"confidence":0.93,"match":"exact"},
            "outro":{"start_ms":2600000,"end_ms":2640000,"confidence":0.90,"match":"shifted"},
            "recap":{"start_ms":1000,"end_ms":11000,"confidence":0.99,"match":"agnostic"},
            "preview":null
          }
        }""")
        val found = ExternalSceneMarkers.skipDB(json, duration)
        assertEquals(setOf("intro", "outro"), found.map { it.kind }.toSet())
        assertEquals(85_000L, found[0].destination(30_000L, duration))
        assertNull(found[0].destination(90_000L, duration))
    }

    @Test fun introDbFallbackOnlyUsesConfidentMarkers() {
        val json = JsonParser.parseString("""{
          "intro":{"start_ms":1000,"end_ms":64000,"confidence":0.96},
          "recap":{"start_ms":4500,"end_ms":18000,"confidence":0.5},
          "post_credits":{"start_ms":2640000,"end_ms":2680000,"confidence":0.85}
        }""")
        // Post-credit scenes contain story content and must never become skip offers.
        assertEquals(setOf("intro"), ExternalSceneMarkers.introDB(json, duration).map { it.kind }.toSet())
    }

    @Test fun postCreditsAloneNeverProduceSkips() {
        val raw = JsonParser.parseString("""{
          "post_credits":{"start_ms":2620000,"end_ms":2680000,"confidence":0.99}
        }""")
        assertTrue(ExternalSceneMarkers.introDB(raw, duration).isEmpty())
    }

    @Test fun movieMatureScenesRequireMatchingEditionAndExplicitSkipFlag() {
        val json = JsonParser.parseString("""{
          "imdb_id":"tt0266543", "duration":2700,
          "scenes":[
            {"start":120.5,"end":154,"reason":"nudity","skip":true},
            {"start":180,"end":190,"reason":"frightening","skip":true},
            {"start":210,"end":225,"reason":"sexual","skip":false}
          ]
        }""")
        val result = ExternalSceneMarkers.movieHaven(json,"tt0266543",duration)
        assertEquals(1,result.size)
        // Authors round to whole seconds, so mature scenes are widened slightly (1.5 s before, 1 s after).
        assertEquals(119_000L,result.single().startMs)
        assertEquals(155_000L,result.single().endMs)
        assertTrue(ExternalSceneMarkers.movieHaven(json,"tt0266544",duration).isEmpty())
        assertTrue(ExternalSceneMarkers.movieHaven(json,"tt0266543",duration+30_000).isEmpty())
    }

    @Test fun episodeLookupsUseImdbAndSeasonNumber() {
        assertTrue(ExternalSceneMarkers.skipDBURL("https://imdb.com/title/tt0903747/",1,1,duration)!!.contains("episode=1"))
        assertTrue(ExternalSceneMarkers.introDBURL("tt0903747",1,2)!!.contains("season=1"))
        assertNull(ExternalSceneMarkers.skipDBURL("no imdb",1,1,duration))
    }

    @Test fun creditsThatRunToTheEndOfTheFileAreAccepted() {
        val json = JsonParser.parseString("""{
          "segments": { "outro":{"start_ms":2640000,"end_ms":2700400,"confidence":0.9,"match":"exact"} }
        }""")
        val outro = ExternalSceneMarkers.skipDB(json, duration).single()
        assertEquals(duration, outro.endMs) // clamped to the runtime
        assertEquals(duration, outro.destination(2_650_000L, duration))
    }

    @Test fun markersBeyondThisCutAreRejected() {
        val json = JsonParser.parseString("""{
          "segments": { "intro":{"start_ms":2800000,"end_ms":2850000,"confidence":0.9,"match":"exact"} }
        }""")
        assertTrue(ExternalSceneMarkers.skipDB(json, duration).isEmpty())
    }
}
