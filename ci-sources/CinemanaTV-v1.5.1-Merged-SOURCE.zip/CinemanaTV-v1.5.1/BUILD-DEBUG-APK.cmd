@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CinemanaTV v1.5.1 - Debug APK Builder (slower app, runs unit tests)

echo =============================================================
echo   CinemanaTV v1.5.1 - DEBUG build (for diagnosing problems)
echo =============================================================
where java >nul 2>&1
if errorlevel 1 (
  echo ERROR: JDK 17 or newer is required.
  pause
  exit /b 1
)
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_SDK_ROOT if defined ANDROID_HOME set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist "gradlew.bat" (
  echo ERROR: gradlew.bat is missing. Extract the whole ZIP first.
  pause
  exit /b 1
)
call gradlew.bat --no-daemon testDebugUnitTest assembleDebug
if errorlevel 1 (
  echo.
  echo BUILD FAILED - read the compiler or test messages above.
  pause
  exit /b 1
)
if not exist "output" mkdir "output"
copy /y "app\build\outputs\apk\debug\app-debug.apk" "output\CinemanaTV-Cinema-v1.5.1-debug.apk" >nul
if errorlevel 1 (
  echo ERROR: Could not copy the APK.
  pause
  exit /b 1
)
echo.
echo SUCCESS: output\CinemanaTV-Cinema-v1.5.1-debug.apk
echo NOTE: debug builds run noticeably slower than the release build from BUILD-APK.cmd.
echo.
pause
