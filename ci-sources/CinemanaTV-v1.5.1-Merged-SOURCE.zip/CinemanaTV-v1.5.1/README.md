# Cinemana TV v1.5.1 — merged playback and performance build

This release combines the strongest parts of **v1.5.0** (faster home, remote-first player, exact seek and skip/undo UI) and **v1.4.10** (conservative treatment of post-credits story scenes and lower-overhead marker polling).

## Build and installation

- On Windows with JDK 17+, Android SDK 35 and internet access for Gradle, run `RUN-FULL-TEST.cmd` to run regression tests and build a test-signed release APK. Use `BUILD-APK.cmd` to build without unit tests, or `BUILD-DEBUG-APK.cmd` for a debugging build.
- Output from `RUN-FULL-TEST.cmd`: `output/CinemanaTV-v1.5.1-test.apk`.
- `versionName = 1.5.1`, `versionCode = 46`; the app ID, storage, history, downloads and settings are unchanged.
- The APK signing key may not match an older install. Back up app data before removing older versions.
- Automatic mature scene skipping is only available with accurate saved or externally supplied ranges; no real-time video AI is used.

## Earlier project notes

# CinemanaTV v1.4.7 — Search & TV Focus Fixes

**Android TV / Google TV full source**. No accounts or sign-in required.

Changes:
- Search removed from the navigation tabs and moved to a separate fixed header action.
- Settings sidebar responds to **D-pad focus without pressing OK**; a visible ring and category marker indicate selection.
- Search now **prioritizes exact titles** and hides low-relevance matches under a **Show related results** action.
- Settings controls and search remain remote accessible and retain the v1.4.6 two-pane design.
- Mature content options: **Off**, **Skip marked scenes**, or **Hide mature titles**.
- External player handoff is disabled in Skip Scenes mode because it cannot enforce local markers.
- Skip marked scenes works only for *exact scene ranges*, entered **before viewing** using Player Settings → Scene markers → Start/End timestamps, or saved while watching. **There is no automatic explicit-scene detection or trusted online scene-timestamp database.** Unmarked scenes are not automatically skipped.
- Hide titles uses provider age certificates and adult tags. It may miss incorrectly labeled titles; it is not a certified child-protection solution.
- Existing downloads, watch history, player and saved data formats remain intact.

## Build

On Windows with Android SDK, a network connection for Gradle dependencies, and Java 17+:

1. Extract the ZIP.
2. Double-click `RUN-V1.4.7-FULL-TEST.cmd`.
3. The script runs Android unit tests and builds a test APK. If successful the output is `output/CinemanaTV-v1.4.7-test.apk`.
4. If it fails, send `output/CinemanaTV-v1.4.7-BUILD.log`.

APK **not included**. Builds use the local debug signing key even for the optimized test APK, so keep app data and signing compatibility in mind.

## TV test priorities

1. Settings → Mature Content, then press remote **Down** to Playback and Subtitles: the right-hand panel and highlighted sidebar row should change **without OK**.
2. Search for `the mentalist`: the exact title should come first, with irrelevant results behind **Show related results**.
3. Set **Skip marked scenes**: on an unmarked title the player must show **Scene skipping unavailable · no timestamps** (it must not falsely claim the video is safe).
4. In Player Settings → Scene markers enter `00:30` to `00:40`, save, start playback from ~00:28, and verify the player seeks past 00:40. Only test on a seekable stream.
5. Verify Hide Titles, downloads and app data remain intact. Check Back and DPAD navigation and setting persistence across restarts.

## Limitations

This environment does not have a complete Android Gradle build toolchain, so Android compilation and actual TV playback are not certified. Pure Kotlin scene-range logic can be verified independently. Historical test results in `docs/archive` refer to earlier versions.


## Community scene and chapter markers (experimental)

Cinemana can consult **SkipDB** for verified intro, recap, outro and preview
markers, with **IntroDB** as a fallback. Enable the community marker option
in Player settings first. The player only shows a skip button within a
matching range: it never jumps an arbitrary fixed number of seconds.

**Mature-scene skipping** is independent of intro markers. It requires
explicit, time-coded nudity/sexual-scene ranges from the content provider,
your saved local ranges (Android TV), or a compatible MovieHavenDB movie entry.
MovieHavenDB has very limited coverage; most series have no public verified
mature-scene markers. **No frame scanning occurs and no filtering is guaranteed.**
All movie and series titles remain visible. Different cuts may have different
scene positions; mismatched/unknown timestamps are not automatically applied.

External requests send IMDb ID, season/episode and (for SkipDB) runtime, but
not video frames or private watch history. Skipping is on-device and light on
CPU/battery. Sources: [SkipDB](https://skipdb.tv/) (ODbL 1.0, attribution
+ reciprocal data requirements), [IntroDB](https://introdb.app/) (API terms),
and [MovieHavenDB](https://github.com/arman-kh/MovieHavenDB) (CC BY 4.0).
Review each source's terms and permitted use before public redistribution.
